package eu.siacs.conversations.crypto.axolotl;

public class NoSessionsCreatedException extends Throwable{
}
