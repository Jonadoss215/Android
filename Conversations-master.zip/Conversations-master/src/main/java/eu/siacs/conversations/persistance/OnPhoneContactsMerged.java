package eu.siacs.conversations.persistance;

public interface OnPhoneContactsMerged {
	public void phoneContactsMerged();
}
