package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Elumalai on 7/21/2015.
 */
public class AdvertisementCategory extends Activity {

    ListView listView ;
    InputStream is = null;
    String category_id;
    String line = null;
    String result = null;
    List<String> list;

    ArrayList<HashMap<String, String>> list1 = new ArrayList<HashMap<String,String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advertisements_category);
        // Get ListView object from xml
        listView = (ListView) findViewById(R.id.advertisements_category);
        webserviceCall();
        System.out.println("list size  :"+ list.size());
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, list);

        // Assign adapter to ListView
        listView.setAdapter(adapter);
          System.out.println("catagory id :"+ category_id);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                String  itemValue    = (String) listView.getItemAtPosition(position);

                String cur_cat_id = "";
                String cur_cat_name = "";

                for(int k=0;k<list1.size();k++)
                {
                    if(itemValue==list1.get(k).get("category_name"))
                    {
                        cur_cat_id = list1.get(k).get("category_id");
                        cur_cat_name = list1.get(k).get("category_name");
                    }
                }
                Intent intent;
                intent = new Intent(getApplicationContext(), AdvertisementActivity.class);
                intent.putExtra("category",cur_cat_id);
                startActivity(intent);
            }
        });
        getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.faq, menu);
        return true;
    }

    public void webserviceCall() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            HttpClient httpClient = new DefaultHttpClient();
//            HttpPost httpPost = new HttpPost("http://palscom.com/ws/ads.php");
            HttpPost httpPost = new HttpPost(Config.ADVERTISEMENTS_URI);
            List<NameValuePair> list=new ArrayList<NameValuePair>();
            list.add(new BasicNameValuePair("type", "1"));
            httpPost.setEntity(new UrlEncodedFormEntity(list));
            HttpResponse httpResponse=  httpClient.execute(httpPost);
            HttpEntity entity = httpResponse.getEntity();
            is = entity.getContent();
        }
        catch (Exception e) {
            Log.e("Webservice 1", e.toString());
        }
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            while((line = reader.readLine()) != null) {

                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
        }
        catch (Exception e) {
            Log.e("Webservice 2", e.toString());
        }
        try {
            JSONArray ja = new JSONArray(result);
            JSONObject jo = null;
            list = new ArrayList<String>();

            for(int i=0; i<ja.length(); i++) {

                jo = ja.getJSONObject(i);
                list.add(jo.getString("category_name"));
                category_id = jo.getString("category_id");

                HashMap<String, String> map = new HashMap<String, String>();
                map.put("category_id", jo.getString("category_id"));
                map.put("category_name", jo.getString("category_name"));
                list1.add(map);
            }
        }catch (Exception e) {
            Log.e("Webservice 3", e.toString());
        }
    }
}