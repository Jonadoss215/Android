package com.orbmix.palscomm.xmpp.jingle.stanzas;

import com.orbmix.palscomm.xml.Element;

public class Reason extends Element {
	private Reason(String name) {
		super(name);
	}

	public Reason() {
		super("reason");
	}
}
