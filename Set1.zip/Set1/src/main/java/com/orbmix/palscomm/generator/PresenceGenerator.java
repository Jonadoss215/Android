package com.orbmix.palscomm.generator;

import android.util.Log;

import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.xml.Element;
import com.orbmix.palscomm.xmpp.stanzas.PresencePacket;

public class PresenceGenerator extends AbstractGenerator {

	public PresenceGenerator(XmppConnectionService service) {
		super(service);
	}

	private PresencePacket subscription(String type, Contact contact) {
		PresencePacket packet = new PresencePacket();
		packet.setAttribute("type", type);
		packet.setTo(contact.getJid());
		packet.setFrom(contact.getAccount().getJid().toBareJid());
		return packet;
	}

	public PresencePacket requestPresenceUpdatesFrom(Contact contact) {
		return subscription("subscribe", contact);
	}

	public PresencePacket stopPresenceUpdatesFrom(Contact contact) {
		return subscription("unsubscribe", contact);
	}

	public PresencePacket stopPresenceUpdatesTo(Contact contact) {
		return subscription("unsubscribed", contact);
	}

	public PresencePacket sendPresenceUpdatesTo(Contact contact) {
		return subscription("subscribed", contact);
	}

    public PresencePacket sendPalscomPresencePacket(Account account,String msg) {
        PresencePacket packet = new PresencePacket();
        packet.setFrom(account.getJid());
        String sig = account.getPgpSignature();
        if(msg.trim().equalsIgnoreCase("Available"))
        {
            packet.addChild("show").setContent("chat");
        }
        else if(msg.trim().equalsIgnoreCase("Away"))
        {
            packet.addChild("show").setContent("away");
        }
        else if(msg.trim().equalsIgnoreCase("Not Available"))
        {
            packet.addChild("show").setContent("xa");
        }
        else if(msg.trim().equalsIgnoreCase("Do Not Disturb"))
        {
            packet.addChild("show").setContent("dnd");
        }
        packet.addChild("status").setContent(msg);
        if (sig != null) {
            packet.addChild("x", "jabber:x:signed").setContent(sig);
        }
        String capHash = getCapHash();
        if (capHash != null) {
            Element cap = packet.addChild("c",
                    "http://jabber.org/protocol/caps");
            cap.setAttribute("hash", "sha-1");
            cap.setAttribute("node", "http://palscom.com");
            cap.setAttribute("ver", capHash);
        }
//        Log.i("customstatus", "sendPalscomPresencePacket() message ---"+msg+ "---  Returning packet ---"+packet);
        return packet;
    }

    public PresencePacket sendLastSeenSetting(Account account,Boolean lastseenSetting)
    {
        System.out.println("Sending las seen prop:"+lastseenSetting);
        PresencePacket packet = new PresencePacket();
        packet.setFrom(account.getJid());
        String sig = account.getPgpSignature();
        String lstseen = (lastseenSetting)? "1": "0";
        packet.addChild("showlastseen").setContent(lstseen);
        if (sig != null) {
            packet.addChild("status").setContent("online");
            packet.addChild("x", "jabber:x:signed").setContent(sig);
        }
        String capHash = getCapHash();
        if (capHash != null) {
            Element cap = packet.addChild("c",
                    "http://jabber.org/protocol/caps");
            cap.setAttribute("hash", "sha-1");
            cap.setAttribute("node", "http://palscom.com");
            cap.setAttribute("ver", capHash);
        }
        return packet;
    }
    public PresencePacket sendPresence(Account account) {
		PresencePacket packet = new PresencePacket();
		packet.setFrom(account.getJid());
		String sig = account.getPgpSignature();
		if (sig != null) {
			packet.addChild("status").setContent("online");
			packet.addChild("x", "jabber:x:signed").setContent(sig);
		}
		String capHash = getCapHash();
		if (capHash != null) {
			Element cap = packet.addChild("c",
					"http://jabber.org/protocol/caps");
			cap.setAttribute("hash", "sha-1");
			cap.setAttribute("node", "http://" +
                    "palscom.com");
			cap.setAttribute("ver", capHash);
		}
		return packet;
	}

	public PresencePacket sendOfflinePresence(Account account) {
		PresencePacket packet = new PresencePacket();
		packet.setFrom(account.getJid());
		packet.setAttribute("type","unavailable");
		return packet;
	}
}
