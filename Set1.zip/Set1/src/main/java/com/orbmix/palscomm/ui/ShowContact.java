package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.orbmix.palscomm.R;

/**
 * Created by Elumalai on 12/14/2015.
 */
public class ShowContact extends Activity {

    String email = null;
    String contactName = null;
    String contactNumber = null;
    String contactImage = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_contacts);
        Button sharebutton = (Button) findViewById(R.id.share_button);
            Bundle extras = getIntent().getExtras();
        if (extras != null) {
            contactName = extras.getString("name");
            contactNumber = extras.getString("number");
            email = extras.getString("email");
            contactImage = extras.getString("image");
        }
            TextView emailEntry = (TextView) findViewById(R.id.contact_email);
            TextView textView1 = (TextView) findViewById(R.id.contact_name);
            TextView textView = (TextView) findViewById(R.id.contact_no);
            ImageView imageview = (ImageView) findViewById(R.id.img_contact);

            if (contactNumber == null ) {
                textView.setText("");
            }else
                if(contactName == null) {
                    textView1.setText("");
                }else
                    if(email == null)
                       emailEntry.setText("");
             else {
                        Bitmap photos = StringToBitMap(contactImage);
//                      Log.i("contactdetails in show contacts", "Contact Name --" + contactName + "Contact Number -- " + contactNumber + "Email --" + email + "Photos ==" + photos + "----" + contactImage);
                        textView.setText(contactNumber);
                        textView1.setText(contactName);
                        emailEntry.setText(email);
                        imageview.setImageBitmap(photos);
                    }

        sharebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(
                        ContactsContract.Intents.SHOW_OR_CREATE_CONTACT,
                        Uri.parse("tel:" + contactNumber));
                intent.putExtra(ContactsContract.Intents.Insert.NAME, contactName);
                intent.putExtra(ContactsContract.Intents.Insert.EMAIL, email);
                intent.putExtra(ContactsContract.Intents.EXTRA_FORCE_CREATE, true);
                startActivity(intent);
            }
        });

    }

    public Bitmap StringToBitMap(String encodedString){
        try {
            byte [] encodeByte= Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap=BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
