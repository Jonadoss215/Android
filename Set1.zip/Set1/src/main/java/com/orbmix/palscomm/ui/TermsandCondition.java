package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.RegisterActivity;

/**
 * Created by Elumalai on 6/18/2015.
 */
public class TermsandCondition extends Activity {


    CheckBox Chk;
    Button BtnSubmit;
    static int value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Log.i("termandcondition", "onCreate() ");
        Toast.makeText(getApplicationContext(),"onCreate()",Toast.LENGTH_SHORT);
        setContentView(R.layout.terms_and_condition);

        Chk =(CheckBox) findViewById(R.id.chkFirst);
        BtnSubmit =(Button)findViewById(R.id.Submit);
        Chk.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v)
                {
                    if(Chk.isChecked()) {  value = 1; }
                    else  { value = 0; }
              }
             });
    BtnSubmit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if(value == 1) {
                Intent intent = new Intent(TermsandCondition.this, RegisterActivity.class);
                startActivity(intent);
                value = 0;
                finish();
            }
            else {
                Toast.makeText(TermsandCondition.this,"Please Accept The Licence AgreeMent" , Toast.LENGTH_SHORT).show();
            }
        }
    });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
      /*  Toast.makeText(getApplicationContext(),"click accept option box",Toast.LENGTH_SHORT).show();
        Log.i("termandcondition","onRestart()");*/
    }

    @Override
    protected void onStart() {
        super.onStart();
       /* Toast.makeText(TermsandCondition.this, "onStart() method", Toast.LENGTH_SHORT).show();
        Log.i("termandcondition", "onStart()");*/

    }
}
