package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;

public interface OnAdvancedStreamFeaturesLoaded {
	public void onAdvancedStreamFeaturesAvailable(final Account account);
}
