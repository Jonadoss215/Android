package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.orbmix.palscomm.R;

/**
 * Created by orbmixtech on 21/9/15.
 */
public class ProgressBarActivity extends Activity{

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.action_view_progress);
        Intent intent = new Intent(getBaseContext(), StartEventConversationActivity.class);
       // intent.putExtra("UID", preference.getString("userId", null));
        startActivity(intent);
    }
}
