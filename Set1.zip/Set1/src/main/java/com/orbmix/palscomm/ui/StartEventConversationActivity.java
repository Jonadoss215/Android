package com.orbmix.palscomm.ui;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.internal.widget.AdapterViewCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Bookmark;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.KnownConference;
import com.orbmix.palscomm.entities.ListItem;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.ui.adapter.KnownHostsAdapter;
import com.orbmix.palscomm.ui.adapter.ListItemAdapter;
import com.orbmix.palscomm.utils.ConnectionDetector;
import com.orbmix.palscomm.utils.HttpCall;
import com.orbmix.palscomm.utils.XmppUri;
import com.orbmix.palscomm.xmpp.OnUpdateBlocklist;
import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by orbmixtech on 2/9/15.
 */
public class StartEventConversationActivity extends XmppActivity implements XmppConnectionService.OnRosterUpdate, OnUpdateBlocklist, XmppConnectionService.OnConferenceOptionsPushed {

    public int participate_context_id;
    public int public_context_id;
    public int myevent_context_id;

    private ActionBar.Tab mParticipateTab;
    private ActionBar.Tab mPublicTab;
    private ActionBar.Tab mMyEventTab;

    private ViewPager mViewPager;


    private List<String> participatingEvent = new ArrayList<>();

    private MyListFragment mParticipateListFragment = new MyListFragment();
    private List<ListItem> Participate = new ArrayList<ListItem>();
    private ArrayAdapter<ListItem> mParticipateAdapter;

    private MyListFragment mMyEventListFragment = new MyListFragment();
    private List<ListItem> myeventlist = new ArrayList<ListItem>();
    private List<ListItem> myeventStaticlist = new ArrayList<ListItem>();
    private ArrayAdapter<ListItem> mMyEventAdapter;

    private List<ListItem> knownConferences = new ArrayList<ListItem>();
    private MyListFragment mConferenceRoomSearchFragment = new MyListFragment();
    private ArrayAdapter<ListItem> mConferenceRoomSearchAdapter;

    private List<String> mActivatedAccounts = new ArrayList<String>();
    private List<String> mKnownHosts;
    private List<String> mKnownConferenceHosts;

    private Invite mPendingInvite = null;
    private Menu mOptionsMenu;
    private EditText mSearchEditText;
    String conferenceAddress;

    public int MyeventCount = 0;

    ConnectionDetector cd;

    private MenuItem.OnActionExpandListener mOnActionExpandListener = new MenuItem.OnActionExpandListener() {

        @Override
        public boolean onMenuItemActionExpand(MenuItem item) {
            mSearchEditText.post(new Runnable() {

                @Override
                public void run() {
                    mSearchEditText.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(mSearchEditText,
                            InputMethodManager.SHOW_IMPLICIT);
                }
            });

            return true;
        }

        @Override
        public boolean onMenuItemActionCollapse(MenuItem item) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mSearchEditText.getWindowToken(),
                    InputMethodManager.HIDE_IMPLICIT_ONLY);
            mSearchEditText.setText("");
            filter(null);
            return true;
        }
    };
    private boolean mHideOfflineContacts = false;
    private ActionBar.TabListener mTabListener = new ActionBar.TabListener() {

        @Override
        public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
            return;
        }

        @Override
        public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
            mViewPager.setCurrentItem(tab.getPosition());
            onTabChanged();
        }

        @Override
        public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
            return;
        }
    };
    private ViewPager.SimpleOnPageChangeListener mOnPageChangeListener = new ViewPager.SimpleOnPageChangeListener() {
        @Override
        public void onPageSelected(int position) {
            if (getActionBar() != null) {
                getActionBar().setSelectedNavigationItem(position);
            }
            onTabChanged();
        }
    };
    private TextWatcher mSearchTextWatcher = new TextWatcher() {

        @Override
        public void afterTextChanged(Editable editable) {
            filter(editable.toString());
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before,
                                  int count) {
        }
    };
    private MenuItem mMenuSearchView;
    private ListItemAdapter.OnTagClickedListener mOnTagClickedListener = new ListItemAdapter.OnTagClickedListener() {
        @Override
        public void onTagClicked(String tag) {
            if (mMenuSearchView != null) {
                mMenuSearchView.expandActionView();
                mSearchEditText.setText("");
                mSearchEditText.append(tag);
                filter(tag);
            }
        }
    };
    private String mInitialJid;

    @Override
    public void onRosterUpdate() {
        this.refreshUi();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_conversation);
        mViewPager = (ViewPager) findViewById(R.id.start_conversation_view_pager);
        ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        mParticipateTab = actionBar.newTab().setText("Participating")
                .setTabListener(mTabListener);
        mMyEventTab = actionBar.newTab().setText("Public Events")
                .setTabListener(mTabListener);
        mPublicTab = actionBar.newTab().setText("My Events")
                .setTabListener(mTabListener);

        cd = new ConnectionDetector(getApplicationContext());
        actionBar.addTab(mParticipateTab);
        actionBar.addTab(mMyEventTab);
        actionBar.addTab(mPublicTab);

        mViewPager.setOnPageChangeListener(mOnPageChangeListener);
        mViewPager.setAdapter(new FragmentPagerAdapter(getFragmentManager()) {

            @Override
            public int getCount() {
                return 3;
            }

            @Override
            public Fragment getItem(int position) {
                if (position == 0) {
                    return mParticipateListFragment;
                } else if (position == 1) {
                    return mConferenceRoomSearchFragment;
                } else {
                    return mMyEventListFragment;

                }
            }
        });

        mParticipateAdapter = new ListItemAdapter(this, Participate);
        mParticipateListFragment.setListAdapter(mParticipateAdapter);
        mParticipateListFragment.setContextMenu(R.menu.participate_context);
        mParticipateListFragment
                .setOnListItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> arg0, View arg1,
                                            int position, long arg3) {
                        openConversationForBookmark(position);
                    }
                });

        mConferenceRoomSearchAdapter = new ListItemAdapter(this, knownConferences);
        mConferenceRoomSearchFragment.setListAdapter(mConferenceRoomSearchAdapter);
        mConferenceRoomSearchFragment.setContextMenu(R.menu.public_event_context);
        mConferenceRoomSearchFragment.setOnListItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
               conferenceAddress = ((TextView) view.findViewById(R.id.contact_jid)).getText().toString();
//                showJoinConferenceDialog(conferenceAddress);
                showParticipateEventDialog(conferenceAddress);
            }
        });

        mMyEventAdapter = new ListItemAdapter(this, myeventlist);
        mMyEventListFragment.setListAdapter(mMyEventAdapter);
        mMyEventListFragment.setContextMenu(R.menu.eventconfirance_context);
        mMyEventListFragment
                .setOnListItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> arg0, View arg1,
                                            int position, long arg3) {
                        openEventForBookmark(position);
                    }
                });
    }

    protected void openConversationForBookmark() {
        openConversationForBookmark(participate_context_id);
    }

    protected void openBCastForBookmark(int position) {
        System.out.println("Open Broad cast for bookmark");
        Bookmark bookmark = (Bookmark)knownConferences.get(position);
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(bookmark.getAccount(),
                        bookmark.getJid(), true);
        conversation.setBookmark(bookmark);
        if (!conversation.getMucOptions().online()) {
            xmppConnectionService.joinMuc(conversation);
        }
        if (!bookmark.autojoin()) {
            bookmark.setAutojoin(true);
            xmppConnectionService.pushBookmarks(bookmark.getAccount());
        }
        switchToConversation(conversation);
    }

    protected void openEventForBookmark(int position) {
        System.out.println("Open Event for bookmark");
        Bookmark bookmark = (Bookmark) myeventlist.get(position);
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(bookmark.getAccount(),
                        bookmark.getJid(), true);
        conversation.setBookmark(bookmark);
        if (!conversation.getMucOptions().online()) {
            xmppConnectionService.joinMuc(conversation);
        }
        if (!bookmark.autojoin()) {
            bookmark.setAutojoin(true);
            xmppConnectionService.pushBookmarks(bookmark.getAccount());
        }
        switchToConversation(conversation);
    }

    protected void openConversationForBookmark(int position) {
        System.out.println("Open Conversation for bookmark");
        Bookmark bookmark = (Bookmark) Participate.get(position);
        Jid jid = bookmark.getJid();
        if (jid == null) {
            Toast.makeText(this, R.string.invalid_jid, Toast.LENGTH_SHORT).show();
            return;
        }
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(bookmark.getAccount(),
                        bookmark.getJid(), true);
        conversation.setBookmark(bookmark);
        if (!conversation.getMucOptions().online()) {
            xmppConnectionService.joinMuc(conversation);
        }
        if (!bookmark.autojoin()) {
            bookmark.setAutojoin(true);
            xmppConnectionService.pushBookmarks(bookmark.getAccount());
        }
        System.out.println("Hey Boss. this is bookmark");
        switchToConversation(conversation);
    }

    protected void deleteEventGroup(){
        System.out.println("Delete Conference");
        int position = participate_context_id;
        final Bookmark bookmark = (Bookmark) Participate.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle(R.string.delete_bookmark_event);
        builder.setMessage(getString(R.string.remove_bookmark_text,
                bookmark.getDisplayName()));
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                bookmark.unregisterConversation();
                Account account = bookmark.getAccount();
                account.getBookmarks().remove(bookmark);
                xmppConnectionService.pushBookmarks(account);
                filter(mSearchEditText.getText().toString());
            }
        });
        builder.create().show();
    }

    /*
    *
    * Function opens the create group dialog.
    * Elumalai.
    *
    * */
    @SuppressLint("InflateParams")
    protected void showJoinConferenceDialog(final String prefilledJid) {
        System.out.println("Show join conference dialog");
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.join_conference);
        final View dialogView = getLayoutInflater().inflate(R.layout.join_conference_dialog, null);
        final Spinner spinner = (Spinner) dialogView.findViewById(R.id.account);
		/*final AutoCompleteTextView jid = (AutoCompleteTextView) dialogView.findViewById(R.id.jid);
		jid.setAdapter(new KnownHostsAdapter(this,android.R.layout.simple_list_item_1, mKnownConferenceHosts));*/

        final EditText jid = (EditText) dialogView.findViewById(R.id.jid);
        if (prefilledJid != null) {
            jid.append(prefilledJid);
        }
        populateAccountSpinner(spinner);

        final Checkable bookmarkCheckBox = (CheckBox) dialogView
                .findViewById(R.id.bookmark);
        builder.setView(dialogView);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.join, null);
        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(final View v) {
                        if (!xmppConnectionServiceBound) {
                            return;
                        }
                        final Jid accountJid;
                        try {
                            accountJid = Jid.fromString((String) spinner.getSelectedItem());
                            System.out.println("Jose:: Account JID:" + accountJid);
                        } catch (final InvalidJidException e) {
                            return;
                        }
                        final Jid conferenceJid;
                        try {
                            String id = jid.getText().toString().replaceAll("\\s+", "");
                            conferenceJid = Jid.fromString(id + "@" + getString(R.string.conference_name));
                            System.out.println("conference id::" + conferenceJid);
                            System.out.println("conference id::" + jid.getText().toString());

                        } catch (final InvalidJidException e) {
                            jid.setError(getString(R.string.invalid_jid));
                            return;
                        }
                        final Account account = xmppConnectionService
                                .findAccountByJid(accountJid);
                        if (account == null) {
                            dialog.dismiss();
                            return;
                        }
                        if (bookmarkCheckBox.isChecked()) {
                            if (account.hasBookmarkFor(conferenceJid)) {
                                jid.setError(getString(R.string.bookmark_already_exists));
                            } else {
                                final Bookmark bookmark = new Bookmark(account, conferenceJid.toBareJid());
                                bookmark.setAutojoin(true);
                                account.getBookmarks().add(bookmark);
                                xmppConnectionService
                                        .pushBookmarks(account);
                                final Conversation conversation = xmppConnectionService
                                        .findOrCreateConversation(account,
                                                conferenceJid, true);
                                conversation.setBookmark(bookmark);
                                System.out.println("conversation status:" + conversation.getMucOptions().online());
                                if (!conversation.getMucOptions().online()) {
                                    xmppConnectionService
                                            .joinMuc(conversation);
                                    Bundle options = new Bundle();
                                    options.putString("muc#roomconfig_membersonly", "1");
                                    options.putString("muc#roomconfig_whois", "moderators");
                                    options.putString("muc#roomconfig_persistentroom", "1");
                                    xmppConnectionService.pushSubjectToConference(conversation, jid.getText().toString());


                                    xmppConnectionService.pushConferenceConfiguration(conversation,
                                            options,
                                            StartEventConversationActivity.this);
                                }
                                dialog.dismiss();
                                // ------- below lines added by Jose. to add the user to the memebrs list.
                                String userslist = null;
                                try {
                                    userslist = URLEncoder.encode(accountJid.getLocalpart().toString(), "UTF-8") + "|" + URLEncoder.encode(accountJid.toBareJid().toString(), "UTF-8") + ",";
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }
                                String owner = "owner";
                                String param = "type=1&groupid=" + conversation.getContact().getJid().toBareJid() + "&userslist=" + userslist+ "&membertype=" +owner;
                                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                                StrictMode.setThreadPolicy(policy);
                                System.out.println("param::" + param);
//                                HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                                HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                                // --------

//                                switchToConversation(conversation);
                                launchgrpDetailsActivity(conversation);
                            }
                        } else {
                            final Conversation conversation = xmppConnectionService
                                    .findOrCreateConversation(account,
                                            conferenceJid, true);
                            if (!conversation.getMucOptions().online()) {
                                xmppConnectionService.joinMuc(conversation);
                            }
                            dialog.dismiss();
                            switchToConversation(conversation);
                        }
                    }
                });
    }

// Added by Elumalai for public Group to participate user
    protected void showParticipateEventDialog(final String prefilledJid) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.join_event);
        final View dialogView = getLayoutInflater().inflate(R.layout.join_event_dialog1, null);
        final Spinner spinner = (Spinner) dialogView.findViewById(R.id.account);
        final TextView jid = (TextView) dialogView.findViewById(R.id.jid);

        if (prefilledJid != null) {
            jid.append(prefilledJid);
        }
        populateAccountSpinner(spinner);

        final Checkable privateCheckBox = (CheckBox) dialogView
                .findViewById(R.id.event_type);
        builder.setView(dialogView);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.participate, null);

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(final View v) {
                        if (!xmppConnectionServiceBound) {
                            return;
                        }
                        final Jid accountJid;
                        try {
                            accountJid = Jid.fromString((String) spinner.getSelectedItem());
                        } catch (final InvalidJidException e) {
                            return;
                        }
                        final Jid conferenceJid;
                        try {
                            String id = jid.getText().toString().replaceAll("\\s+", "");
                            conferenceJid = Jid.fromString(id + "_ev_@" + getString(R.string.conference_name));


                        } catch (final InvalidJidException e) {
                            jid.setError(getString(R.string.invalid_jid));
                            return;
                        }
                        final Account account = xmppConnectionService
                                .findAccountByJid(accountJid);
                        if (account == null) {
                            dialog.dismiss();
                            return;
                        }

                        if (account.hasBookmarkFor(conferenceJid)) {
                            jid.setError(getString(R.string.bookmark_already_exists));
                        } else {
                            final Bookmark bookmark = new Bookmark(account, conferenceJid.toBareJid());
                            bookmark.setAutojoin(true);
                            account.getBookmarks().add(bookmark);
                            xmppConnectionService
                                    .pushBookmarks(account);
                            final Conversation conversation = xmppConnectionService
                                    .findOrCreateConversation(account,
                                            conferenceJid, true);
                            conversation.setBookmark(bookmark);
                            if (!conversation.getMucOptions().online()) {
                                xmppConnectionService
                                        .joinMuc(conversation);
                                Bundle options = new Bundle();
                             /*  if (privateCheckBox.isChecked()) {
                                    options.putString("muc#roomconfig_membersonly", "1");
                                    options.putString("muc#roomconfig_whois", "moderators");
                                } else {*/
                                options.putString("muc#roomconfig_membersonly", "0");
                                options.putString("muc#roomconfig_whois", "anyone");
//                               }

                                options.putString("muc#roomconfig_persistentroom", "1");
                                xmppConnectionService.pushSubjectToConference(conversation, jid.getText().toString());

//                                System.out.println("Bundle Options---"+options);
                                xmppConnectionService.pushConferenceConfiguration(conversation,
                                        options,
                                        StartEventConversationActivity.this);
                            }
                            dialog.dismiss();

                            // ------- below lines added by Jose. to add the user to the memebrs list.
                            String userslist = null;
                            try {
                                userslist = URLEncoder.encode(accountJid.getLocalpart().toString(), "UTF-8") + "|" + URLEncoder.encode(accountJid.toBareJid().toString(), "UTF-8") + ",";
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            String param = "type=1&groupid=" + conversation.getContact().getJid().toBareJid() + "&userslist=" + userslist;
                            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                            StrictMode.setThreadPolicy(policy);
                            System.out.println("param::" + param);
//                            HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                            HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                            // --------

//                            switchToConversation(conversation);
                            launchgrpDetailsActivity(conversation);
                        }

                    }
                });
    }


    // Added by Elumalai for create new Events
    protected void showJoinEventDialog(final String prefilledJid) {
        System.out.println("show join Event dialog create");
        // Added by Elumalai for limited Event Group (2)
        if (MyeventCount <= 2) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(R.string.join_event);
            final View dialogView = getLayoutInflater().inflate(R.layout.join_event_dialog, null);
            final Spinner spinner = (Spinner) dialogView.findViewById(R.id.account);
            final EditText jid = (EditText) dialogView.findViewById(R.id.jid);

            if (prefilledJid != null) {
                jid.append(prefilledJid);
            }
            populateAccountSpinner(spinner);

            final Checkable privateCheckBox = (CheckBox) dialogView
                    .findViewById(R.id.event_type);

            builder.setView(dialogView);
            builder.setNegativeButton(R.string.cancel, null);
            builder.setPositiveButton(R.string.create, null);
            final AlertDialog dialog = builder.create();
            dialog.show();
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                    new View.OnClickListener() {

                        @Override
                        public void onClick(final View v) {
                            if (!xmppConnectionServiceBound) {
                                return;
                            }
                            final Jid accountJid;
                            try {
                                accountJid = Jid.fromString((String) spinner.getSelectedItem());
                            } catch (final InvalidJidException e) {
                                return;
                            }
                            final Jid conferenceJid;
                            try {
                                String id = jid.getText().toString().replaceAll("\\s+", "");
                                if (id.isEmpty()) {
                                    conferenceJid = Jid.fromString(id + "@" + getString(R.string.conference_name));
                                } else {
                                    conferenceJid = Jid.fromString(id + "_ev_@" + getString(R.string.conference_name));
                                }

                            } catch (final InvalidJidException e) {
                                jid.setError(getString(R.string.invalid_jid));
                                return;
                            }
                            final Account account = xmppConnectionService
                                    .findAccountByJid(accountJid);
                            if (account == null) {
                                dialog.dismiss();
                                return;
                            }
                      /*  Log.i("EventGroups","conferenceJid -----"+conferenceJid);
                        Log.i("EventGroups", "account.hasBookmarkFor(conferenceJid) ----"+account.hasBookmarkFor(conferenceJid));
                        Log.i("EventGroup","account.getjid() ---"+account.getJid());*/
                            if (account.hasBookmarkFor(conferenceJid)) {
                                jid.setError(getString(R.string.bookmark_already_exists));
                            } else {
                                final Bookmark bookmark = new Bookmark(account, conferenceJid.toBareJid());
                                bookmark.setAutojoin(true);
                                account.getBookmarks().add(bookmark);
                                xmppConnectionService
                                        .pushBookmarks(account);
                                final Conversation conversation = xmppConnectionService
                                        .findOrCreateConversation(account,
                                                conferenceJid, true);
                                conversation.setBookmark(bookmark);
                                if (!conversation.getMucOptions().online()) {
                                    xmppConnectionService
                                            .joinMuc(conversation);
                                    Bundle options = new Bundle();
                                    if (privateCheckBox.isChecked()) {
                                        options.putString("muc#roomconfig_membersonly", "1");
                                        options.putString("muc#roomconfig_whois", "moderators");
                                    } else {
                                        options.putString("muc#roomconfig_membersonly", "0");
                                        options.putString("muc#roomconfig_whois", "anyone");
                                    }

                                    options.putString("muc#roomconfig_persistentroom", "1");
                                    xmppConnectionService.pushSubjectToConference(conversation, jid.getText().toString());

                                    System.out.println("Bundle Options---" + options);
                                    xmppConnectionService.pushConferenceConfiguration(conversation,
                                            options,
                                            StartEventConversationActivity.this);
                                }
                                dialog.dismiss();

                                // ------- below lines added by Jose. to add the user to the memebrs list.
                                String userslist = null;
                                try {
                                    userslist = URLEncoder.encode(accountJid.getLocalpart().toString(), "UTF-8") + "|" + URLEncoder.encode(accountJid.toBareJid().toString(), "UTF-8") + ",";
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }
                                String owner = "owner";
                                String param = "type=1&groupid=" + conversation.getContact().getJid().toBareJid() + "&userslist=" + userslist + "&membertype=" + owner;
                                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                                StrictMode.setThreadPolicy(policy);
                                System.out.println("event Group param::" + param);
//                            HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                                HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                                // --------
//                            switchToConversation(conversation);
                                launchgrpDetailsActivity(conversation);
                            }

                        }
                    });
        }else {
//            Log.i("MyeventCount","------------------"+MyeventCount);
            AlertDialog alertDialog = new AlertDialog.Builder(StartEventConversationActivity.this).create();
            alertDialog.setTitle("Limited Events only Allowed");
            alertDialog.setMessage("Alert message limited Groups");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
    }


    protected void launchgrpDetailsActivity(Conversation conv)
    {
        Intent intent = new Intent(StartEventConversationActivity.this,ConferenceDetailsActivity.class);
        intent.setAction(ConferenceDetailsActivity.ACTION_VIEW_MUC);
        intent.putExtra("uuid", conv.getUuid());
        /*intent.putExtra("grpnm",jid.getText().toString());
        intent.putExtra("accjid",(String) spinner.getSelectedItem());*/
        startActivityForResult(intent, 9999);
    }
    protected void switchToConversation(Contact contact) {
//        System.out.println("switch to Conversation");
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(contact.getAccount(),
                        contact.getJid(), false);
        switchToConversation(conversation);
    }

    private void populateAccountSpinner(Spinner spinner) {
        System.out.println("Populate Account Spinner");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, mActivatedAccounts);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.mOptionsMenu = menu;
        getMenuInflater().inflate(R.menu.startevent_conversation, menu);
        MenuItem menuCreateEvent = menu.findItem(R.id.action_join_event);
        MenuItem menuHideOffline = menu.findItem(R.id.action_hide_offline);
        MenuItem menuRefresh = menu.findItem(R.id.action_refresh);
        MenuItem menuShowblocklist = menu.findItem(R.id.action_show_block_list);
        MenuItem menuUpdates = menu.findItem(R.id.action_updates);
        MenuItem menuaccounts = menu.findItem(R.id.action_accounts);
        menuHideOffline.setChecked(this.mHideOfflineContacts);
        mMenuSearchView = menu.findItem(R.id.action_search);
        mMenuSearchView.setOnActionExpandListener(mOnActionExpandListener);
        View mSearchView = mMenuSearchView.getActionView();
        mSearchEditText = (EditText) mSearchView
                .findViewById(R.id.search_field);
        mSearchEditText.addTextChangedListener(mSearchTextWatcher);
        if (getActionBar().getSelectedNavigationIndex() == 0) {
            menuaccounts.setVisible(false);
            menuCreateEvent.setVisible(true);
            menuRefresh.setVisible(false);
            menuHideOffline.setVisible(false);
            menuShowblocklist.setVisible(false);
            menuUpdates.setVisible(false);
        } else if (getActionBar().getSelectedNavigationIndex() == 1) {
            menuCreateEvent.setVisible(true);
            menuaccounts.setVisible(false);
            menuRefresh.setVisible(false);
            menuHideOffline.setVisible(false);
            menuShowblocklist.setVisible(false);
            menuUpdates.setVisible(false);
        } else if (getActionBar().getSelectedNavigationIndex() == 2) {
            menuRefresh.setVisible(false);
            menuaccounts.setVisible(false);
            menuCreateEvent.setVisible(true);
            menuHideOffline.setVisible(false);
            menuShowblocklist.setVisible(false);
            menuUpdates.setVisible(false);
        } else {
            menuCreateEvent.setVisible(false);
            menuRefresh.setVisible(false);

            menuHideOffline.setVisible(false);
            menuShowblocklist.setVisible(false);
            menuUpdates.setVisible(false);
        }

        if (mInitialJid != null) {
            mMenuSearchView.expandActionView();
            mSearchEditText.append(mInitialJid);
            filter(mInitialJid);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_show_block_list:
                final Intent showBlocklistIntent = new Intent(this, BlocklistActivity.class);
                showBlocklistIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
                startActivity(showBlocklistIntent);
                break;
            // Added by Elumalai for advertisement
            case R.id.action_advertisement:
                if (getPreferences().getBoolean("advertisements_indicator", true)) {
                    Boolean isInternetPresent = false;

                    isInternetPresent = cd.isConnectingToInternet();
                    System.out.println("Jose. it is here.. " + isInternetPresent);
                    if (isInternetPresent) {
                        final Intent addIntent = new Intent(this, AdvertisementCategory.class);
                        startActivity(addIntent);
                    } else {
                        showAlertDialog(StartEventConversationActivity.this, "No Internet Connection",
                                "You don't have internet connection.", false);
                    }
                } else {
                    Toast.makeText(StartEventConversationActivity.this, "Enable the Advertisements settings to View Advertisements", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.action_updates:
                if (getPreferences().getBoolean("view_updates", true)) {
                    final Intent updatesIntent = new Intent(this, UpdatesActivity.class);
                    updatesIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
                    startActivity(updatesIntent);
                } else {
                    Toast.makeText(StartEventConversationActivity.this, "Enable the Updates from Privacy Settings to View Updates", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.action_join_event:
                showJoinEventDialog(null);
                break;
            case R.id.action_scan_qr_code:
                new IntentIntegrator(this).initiateScan();
                return true;
            case R.id.action_hide_offline:
                mHideOfflineContacts = !item.isChecked();
                getPreferences().edit().putBoolean("hide_offline", mHideOfflineContacts).commit();
                if (mSearchEditText != null) {
                    filter(mSearchEditText.getText().toString());
                }
                invalidateOptionsMenu();
                break;
            case R.id.action_refresh:
                System.out.println("Hey Jose. Do refresh here!");
                xmppConnectionService.refreshContacts();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAddConferenceServerDialog(String server) {
        System.out.println("Show add conference server dialog");
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Event conference server");
        final View dialogView = getLayoutInflater().inflate(R.layout.add_conference_server_dialog, null);
        final AutoCompleteTextView jid = (AutoCompleteTextView) dialogView.findViewById(R.id.jid);
        jid.setAdapter(new KnownHostsAdapter(this,android.R.layout.simple_list_item_1, mKnownConferenceHosts));
        builder.setView(dialogView);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.add, null);
        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(final View v) {
                        if (!xmppConnectionServiceBound) {
                            return;
                        }
                        try {
                            Jid serverJid = Jid.fromString(jid.getText().toString());
                            xmppConnectionService.searchForConferenceRoomsOnAlienServer(serverJid);
                        } catch (InvalidJidException e) {
                        }
                        dialog.dismiss();
                    }
                });
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        System.out.println("OnKeyUp");
        if (keyCode == KeyEvent.KEYCODE_SEARCH && !event.isLongPress()) {
            mOptionsMenu.findItem(R.id.action_search).expandActionView();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        System.out.println("On Activity Results");
        if ((requestCode & 0xFFFF) == IntentIntegrator.REQUEST_CODE) {
            IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
            if (scanResult != null && scanResult.getFormatName() != null) {
                String data = scanResult.getContents();
                Invite invite = new Invite(data);
                if (xmppConnectionServiceBound) {
                    invite.invite();
                } else if (invite.getJid() != null) {
                    this.mPendingInvite = invite;
                } else {
                    this.mPendingInvite = null;
                }
            }
        }
        super.onActivityResult(requestCode, requestCode, intent);
    }

    @Override
    protected void onBackendConnected() {
        System.out.println("On backend Connected");
        this.mActivatedAccounts.clear();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {
                this.mActivatedAccounts.add(account.getJid().toBareJid().toString());
            }
        }
        final Intent intent = getIntent();
        final ActionBar ab = getActionBar();
        if (intent != null && intent.getBooleanExtra("init", false) && ab != null) {
            ab.setDisplayShowHomeEnabled(false);
            ab.setDisplayHomeAsUpEnabled(false);
            ab.setHomeButtonEnabled(false);
        }
        this.mKnownHosts = xmppConnectionService.getKnownHosts();
        this.mKnownConferenceHosts = xmppConnectionService.getKnownConferenceHosts();
        if (this.mPendingInvite != null) {
//            mPendingInvite.invite();
            this.mPendingInvite = null;
        } else if (!handleIntent(getIntent())) {
            if (mSearchEditText != null) {
                filter(mSearchEditText.getText().toString());
            } else {
                filter(null);
            }
        }
        setIntent(null);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    Invite getInviteJellyBean(NdefRecord record) {
        return new Invite(record.toUri());
    }

    protected boolean handleIntent(Intent intent) {
        System.out.println("Handle Intent");
        if (intent == null || intent.getAction() == null) {
            return false;
        }
        switch (intent.getAction()) {
            case Intent.ACTION_SENDTO:
            case Intent.ACTION_VIEW:
                Log.d(Config.LOGTAG, "received uri=" + intent.getData());
                return new Invite(intent.getData()).invite();
            case NfcAdapter.ACTION_NDEF_DISCOVERED:
                for (Parcelable message : getIntent().getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)) {
                    if (message instanceof NdefMessage) {
                        Log.d(Config.LOGTAG, "received message=" + message);
                        for (NdefRecord record : ((NdefMessage) message).getRecords()) {
                            switch (record.getTnf()) {
                                case NdefRecord.TNF_WELL_KNOWN:
                                    if (Arrays.equals(record.getType(), NdefRecord.RTD_URI)) {
                                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                            return getInviteJellyBean(record).invite();
                                        } else {
                                            byte[] payload = record.getPayload();
                                            if (payload[0] == 0) {
                                                return new Invite(Uri.parse(new String(Arrays.copyOfRange(
                                                        payload, 1, payload.length)))).invite();
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
        }
        return false;
    }

    private boolean handleJid(Invite invite) {
        System.out.println("Handle Jid invite");
        List<Contact> contacts = xmppConnectionService.findContacts(invite.getJid());
        if (contacts.size() == 0) {
//            showCreateContactDialog(invite.getJid().toString(), invite.getFingerprint());
            return false;
        } else if (contacts.size() == 1) {
            Contact contact = contacts.get(0);
            if (invite.getFingerprint() != null) {
                if (contact.addOtrFingerprint(invite.getFingerprint())) {
                    Log.d(Config.LOGTAG, "added new fingerprint");
                    xmppConnectionService.syncRosterToDisk(contact.getAccount());
                }
            }
            switchToConversation(contact);
            return true;
        } else {
            if (mMenuSearchView != null) {
                mMenuSearchView.expandActionView();
                mSearchEditText.setText("");
                mSearchEditText.append(invite.getJid().toString());
                filter(invite.getJid().toString());
            } else {
                mInitialJid = invite.getJid().toString();
            }
            return true;
        }
    }

    protected void filter(String needle) {
        if (xmppConnectionServiceBound) {
            this.filterParticipate(needle);
            this.filterPublicEvents(needle);
            this.filterMyEventList(needle);
        }
    }


    protected void filterParticipate(String needle) {
        this.Participate.clear();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {

                for (Bookmark bookmark : account.getBookmarks()) {
                    if (bookmark.match(needle) && bookmark.getJid() != null) {
                        try {

                            int intIndex = bookmark.getJid().toString().indexOf("_ev_");

                            if(intIndex == - 1){
                            }else{
                                this.Participate.add(bookmark);
                                participatingEvent.add(bookmark.getJid().getLocalpart().toString());
                            }
                        }
                        catch(Exception e)
                        {
                            System.out.println("filterConferences Exception"+e.getMessage().toString());
                        }
                    }
                }
            }
        }
        Collections.sort(this.Participate);
        mParticipateAdapter.notifyDataSetChanged();
    }

    String publicEvent;

// SaranRaj code is here!
    protected void filterPublicEvents(String needle) {
        if(needle == null) return;

        this.knownConferences.clear();
        for (Account account : xmppConnectionService.getAccounts()) {
            for (String conferenceHost : xmppConnectionService.getKnownConferenceHosts()) {
                try {
                    List<String> conferenceNames = xmppConnectionService.getConferenceNames(account.getJid(), Jid.fromString(conferenceHost));
                    conferenceNames.removeAll(participatingEvent);
                    for (String PublicEvents : conferenceNames) {
                        if (needle == null || needle.isEmpty() ||
                                PublicEvents.toLowerCase().contains(needle.toLowerCase()) ||
                                conferenceHost.toLowerCase().contains(needle.toLowerCase())) {
                            if (PublicEvents.contains("_ev_")) {
                                publicEvent = PublicEvents.replace("_ev_", "");
                                this.knownConferences.add(new KnownConference(Jid.fromParts(publicEvent, conferenceHost, "")));
                            }
                        }
                    }

                } catch (InvalidJidException e) {
                    e.printStackTrace();
                }
            }
        }
        Collections.sort(this.knownConferences);
        mConferenceRoomSearchAdapter.notifyDataSetChanged();
    }

    protected void filterMyEventList(String needle) {
            if (this.myeventlist.size() <= 0) {
                this.myeventlist.clear();
                for (Account account : xmppConnectionService.getAccounts()) {
                    if (account.getStatus() != Account.State.DISABLED) {

                        for (Bookmark bookmark : account.getBookmarks()) {
                            if (bookmark.match(needle) && bookmark.getJid() != null) try {
                                int intIndex = bookmark.getJid().toString().indexOf("_ev_");
                                if (intIndex == -1) {
//                                    System.out.println("Hello not found");
                                } else {
                                    String param = "";
                                    String eventOwnerId = "", totUsers = "";
                                    param = "type=4&groupid=" + bookmark.getConversation().getContact().getJid().toBareJid();

                                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                                    StrictMode.setThreadPolicy(policy);
                                    String returnval;

//                                    returnval = HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                                    returnval = HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                                    final String[] wsdetails = returnval.split("\\|");
                                    eventOwnerId = wsdetails[0];
                                    totUsers = wsdetails[1];

                                    String ss = bookmark.getAccount().getJid().toBareJid().toString();
                                    if (eventOwnerId.equals(ss)) {
                                        // end
                                        if (intIndex == -1) {
                                        } else {
                                            this.myeventlist.add(bookmark);
                                            this.myeventStaticlist.add(bookmark);
                                            MyeventCount = myeventlist.size();
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                System.out.println("filterConferences Exception" + e.getMessage().toString());
                            }
                        }
                    }
                }
                Collections.sort(this.myeventlist);
                mMyEventAdapter.notifyDataSetChanged();
            } else {
                this.myeventlist.clear();
                for (int j = 0; j < this.myeventStaticlist.size(); j++) {
                    if (needle != null) {
                        if (this.myeventStaticlist.get(j).getDisplayName().toString().contains(needle)) {
                            System.out.println(this.myeventStaticlist.get(j).getDisplayName().toString());
                            System.out.println(this.myeventStaticlist.get(j));
                            this.myeventlist.add(this.myeventStaticlist.get(j));
                        }
                    }
                }
                Collections.sort(this.myeventlist);
                mMyEventAdapter.notifyDataSetChanged();
            }
    }

    private void onTabChanged() {
        invalidateOptionsMenu();
    }

    @Override
    public void OnUpdateBlocklist(final Status status) {
        refreshUi();
    }

    @Override
    protected void refreshUiReal() {
        if (mSearchEditText != null) {
            filter(mSearchEditText.getText().toString());
        }
    }

    public static class MyListFragment extends ListFragment {
        private AdapterView.OnItemClickListener mOnItemClickListener;
        private int mResContextMenuevevt;

        public void setContextMenu(final int res) {
            this.mResContextMenuevevt = res;
        }

        @Override
        public void onListItemClick(final ListView l, final View v, final int position, final long id) {
            if (mOnItemClickListener != null) {
                mOnItemClickListener.onItemClick(l, v, position, id);
            }
        }

        public void setOnListItemClickListener(AdapterView.OnItemClickListener l) {
            this.mOnItemClickListener = l;
        }

        @Override
        public void onViewCreated(final View view, final Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);
            registerForContextMenu(getListView());
            getListView().setFastScrollEnabled(false);
        }

      /*  @Override
        public void onCreateContextMenu(final ContextMenu menu, final View v,
                                        final ContextMenu.ContextMenuInfo menuInfo) {
            super.onCreateContextMenu(menu, v, menuInfo);
            final StartEventConversationActivity activity = (StartEventConversationActivity) getActivity();
            activity.getMenuInflater().inflate(mResContextMenuevevt, menu);
            final AdapterView.AdapterContextMenuInfo acmie = (AdapterView.AdapterContextMenuInfo) menuInfo;

            if (mResContextMenuevevt == R.menu.public_event_context) {
                activity.public_context_id = acmie.position;
                } else if (mResContextMenuevevt == R.menu.eventconfirance_context) {
                activity.myevent_context_id = acmie.position;
            } else *//*if (mResContextMenu == R.menu.participate_context) {*//*
                    activity.participate_context_id = acmie.position;
//                }
            }*/

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            super.onCreateContextMenu(menu, v, menuInfo);
            final StartEventConversationActivity activity = (StartEventConversationActivity) getActivity();
            activity.getMenuInflater().inflate(mResContextMenuevevt, menu);
            final AdapterView.AdapterContextMenuInfo acmi = (AdapterView.AdapterContextMenuInfo) menuInfo;
            if (mResContextMenuevevt == R.menu.public_event_context) {
                activity.public_context_id = acmi.position;
            } else if (mResContextMenuevevt == R.menu.eventconfirance_context) {
                activity.myevent_context_id = acmi.position;
            } else {
                activity.participate_context_id = acmi.position;
            }
        }

        @Override
        public boolean onContextItemSelected(MenuItem item) {
            StartEventConversationActivity activity = (StartEventConversationActivity) getActivity();
            switch (item.getItemId()) {
                // this code was commanded by Elumalai for deleting events Groups
                /*case R.id.context_delete_eventgroup:
                    activity.deleteEventGroup();
                    break;*/
            }
            return true;
        }
    }

            /*    @Override
        public boolean onContextItemSelected(final MenuItem item) {
            StartEventConversationActivity activity = (StartEventConversationActivity) getActivity();
            Log.i("startEventConversationActivity", "item.getItemId() ---" + item.getItemId());
            switch (item.getItemId()) {
                case R.id.context_delete_eventgroup:
                    activity.deleteEventGroup();
                    break;
                case R.id.public_event_participate:
//                    showParticipateEventDialog(conferenceAddress);
                    Toast.makeText(getActivity(),"Don't Longpress here!",Toast.LENGTH_LONG).show();
            }
            return true;
        }
    }*/

    private class Invite extends XmppUri {

        public Invite(final Uri uri) {
            super(uri);
        }

        public Invite(final String uri) {
            super(uri);
        }

        boolean invite() {
            if (jid != null) {
                if (muc) {
//                    showJoinConferenceDialog(jid);
                    showJoinEventDialog(jid);
                } else {
                    return handleJid(this);
                }
            }
            return false;
        }
    }

    @Override
    public void onPushSucceeded() {
        //System.out.printlnntln("Push success");
    }

    @Override
    public void onPushFailed() {
        //System.out.printlnintln("Push fail");
    }

    public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(message);

        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        // Showing Alert Message
        alertDialog.show();
    }
}