package com.orbmix.palscomm.utils;

import com.orbmix.palscomm.Config;

public final class Xmlns {
	public static final String BLOCKING = "urn:xmpp:blocking";
	public static final String FAVORITEE = "urn:xmpp:favorite";
	public static final String ROSTER = "jabber:iq:roster";
	public static final String REGISTER = "jabber:iq:register";
	public static final String BYTE_STREAMS = "http://jabber.org/protocol/bytestreams";
//	public static final String HTTP_UPLOAD = Config.LEGACY_NAMESPACE_HTTP_UPLOAD ? "eu:siacs:conversations:http:upload" : "urn:xmpp:http:upload";
	public static final String HTTP_UPLOAD = Config.LEGACY_NAMESPACE_HTTP_UPLOAD ? " com:orbmix:palscomm:http:upload" : "urn:xmpp:http:upload";


}
