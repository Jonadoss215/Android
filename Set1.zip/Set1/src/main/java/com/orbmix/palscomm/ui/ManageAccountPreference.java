package com.orbmix.palscomm.ui;

import android.content.Context;
import android.content.Intent;
import android.preference.Preference;
import android.util.AttributeSet;

import com.orbmix.palscomm.services.XmppConnectionService;

/**
 * Created by Elumalai on 10/9/2015.
 */
public class ManageAccountPreference extends Preference {
    private XmppConnectionService xmppConnectionService;
    public ManageAccountPreference(final Context context, final AttributeSet attrs, final int defStyle) {
        super(context, attrs, defStyle);
        // setSummary();
    }

    public ManageAccountPreference(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        // setSummary();
    }

    @Override
    protected void onClick() {
        super.onClick();
        final Intent intent = new Intent(getContext(), ManageAccountActivity.class);
        getContext().startActivity(intent);
       /* Intent intent = new Intent(getContext(),
                PublishProfilePictureActivity.class);
        System.out.println("Elumalai profile perference ::" +);
        intent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
        getContext().startActivity(intent);*/
    }
}
