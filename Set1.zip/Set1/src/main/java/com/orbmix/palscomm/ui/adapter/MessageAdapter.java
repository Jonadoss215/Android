package com.orbmix.palscomm.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.Downloadable;
import com.orbmix.palscomm.entities.DownloadableFile;
import com.orbmix.palscomm.entities.Message;
import com.orbmix.palscomm.entities.Message.ImageParams;
import com.orbmix.palscomm.ui.ConversationActivity;
import com.orbmix.palscomm.ui.ShowContact;
import com.orbmix.palscomm.utils.GeoHelper;
import com.orbmix.palscomm.utils.UIHelper;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;


public class MessageAdapter extends ArrayAdapter<Message> {

	private static final int SENT = 0;
	private static final int RECEIVED = 1;
	private static final int STATUS = 2;
	private static final int NULL = 3;
	private static final int TYPE_MUC_NOTIFICATION = 4;
	Boolean isEventGrp = false;
	private ConversationActivity activity;
	private Context context;
	String messagidelikecount;
	int tempmessageid = 1;

	private DisplayMetrics metrics;

	private OnContactPictureClicked mOnContactPictureClickedListener;
	private OnContactPictureLongClicked mOnContactPictureLongClickedListener;

	// Added by Elumalai for Event Comments
	private OnEventCommentClicked monECommentsClickedListener;

	private OnLongClickListener openContextMenu = new OnLongClickListener() {

		@Override
		public boolean onLongClick(View v) {
			v.showContextMenu();
			return true;
		}
	};

	public MessageAdapter(ConversationActivity activity, List<Message> messages) {
		super(activity, 0, messages);
		this.activity = activity;
		metrics = getContext().getResources().getDisplayMetrics();
	}

	public void setOnContactPictureClicked(OnContactPictureClicked listener) {
		this.mOnContactPictureClickedListener = listener;
	}

	// Added by Elumalai for Event Comments
	public void setOnEventCommentClicked (OnEventCommentClicked listener){
		this.monECommentsClickedListener = listener;
	}

	public void setOnContactPictureLongClicked(
			OnContactPictureLongClicked listener) {
		this.mOnContactPictureLongClickedListener = listener;
	}

	@Override
	public int getViewTypeCount() {
		return 4;
	}

	@Override
	public int getItemViewType(int position) {
		if (getItem(position).wasMergedIntoPrevious()) {
			return NULL;
		} else if (getItem(position).getType() == Message.TYPE_STATUS) {
			return STATUS;

		} else if(getItem(position).getStatus() == Message.TYPE_MUC_NOTIFICATION)
		{
			//return TYPE_MUC_NOTIFICATION;
			return SENT;
		}
		else if (getItem(position).getStatus() <= Message.STATUS_RECEIVED && !isEventGrp) {
			return RECEIVED;
		} else {
			return SENT;
		}
	}

	private void displayStatus(ViewHolder viewHolder, Message message) {
		String filesize = null;
		String info = null;
		boolean error = false;
		if (viewHolder.indicatorReceived != null || isEventGrp) {
			viewHolder.indicatorReceived.setVisibility(View.GONE);
		}
		boolean multiReceived = message.getConversation().getMode() == Conversation.MODE_MULTI
				&& message.getMergedStatus() <= Message.STATUS_RECEIVED;
		if (message.getType() == Message.TYPE_IMAGE || message.getType() == Message.TYPE_FILE || message.getDownloadable() != null) {
			ImageParams params = message.getImageParams();
			if (params.size > (1.5 * 1024 * 1024)) {
				filesize = params.size / (1024 * 1024)+ " MiB";
			} else if (params.size > 0) {
				filesize = params.size / 1024 + " KiB";
			}
			if (message.getDownloadable() != null && message.getDownloadable().getStatus() == Downloadable.STATUS_FAILED) {
				error = true;
			}
		}
//		Log.i("message status","message.getMergedStatus() --"+message.getMergedStatus());
		switch (message.getMergedStatus()) {
			case Message.STATUS_WAITING:
				info = getContext().getString(R.string.waiting);
				break;
			case Message.STATUS_UNSEND:
				Downloadable d = message.getDownloadable();
				if (d!=null) {
					info = getContext().getString(R.string.sending_file,d.getProgress());
				} else {
					if(message.getFileProgress() != -1)
						info = getContext().getString(R.string.sending_file,message.getFileProgress());
					else
						info = getContext().getString(R.string.sending);
				}
				break;
			case Message.STATUS_OFFERED:
				info = getContext().getString(R.string.offering);
				break;
			case Message.STATUS_SEND_RECEIVED:
				if (activity.indicateReceived() && !isEventGrp) {
					viewHolder.indicatorReceived.setVisibility(View.VISIBLE);
				}
				break;
			case Message.STATUS_SEND_DISPLAYED:
				if (activity.indicateReceived() && !isEventGrp) {
					viewHolder.indicatorReceived.setVisibility(View.VISIBLE);
				}
				break;
			case Message.STATUS_SEND_FAILED:
				info = getContext().getString(R.string.send_failed);
				error = true;
				break;
			default:
				if (multiReceived && !isEventGrp) {
					info = UIHelper.getMessageDisplayName(message);
				}
				break;
		}
		if (error) {
			viewHolder.time.setTextColor(activity.getWarningTextColor());
		} else {
			viewHolder.time.setTextColor(activity.getSecondaryTextColor());
		}
		if (message.getEncryption() == Message.ENCRYPTION_NONE) {
			viewHolder.indicator.setVisibility(View.GONE);
		} else {
			viewHolder.indicator.setVisibility(View.VISIBLE);
		}

		String formatedTime = UIHelper.readableTimeDifferenceFull(getContext(),
				message.getMergedTimeSent());

		if (message.getStatus() <= Message.STATUS_RECEIVED) {
			if ((filesize != null) && (info != null)) {
				viewHolder.time.setText(filesize + " \u00B7 " + info);
			} else if ((filesize == null) && (info != null)) {
				viewHolder.time.setText(formatedTime + " \u00B7 " + info);
			} else if ((filesize != null) && (info == null)) {
				viewHolder.time.setText(formatedTime + " \u00B7 " + filesize);
			} else {
				viewHolder.time.setText(formatedTime);
			}
		} else {
			if ((filesize != null) && (info != null)) {
				viewHolder.time.setText(filesize + " \u00B7 " + info);
			} else if ((filesize == null) && (info != null)) {
				if (error) {
					viewHolder.time.setText(info + " \u00B7 " + formatedTime);
				} else {
					viewHolder.time.setText(info);
				}
			} else if ((filesize != null) && (info == null)) {
				viewHolder.time.setText(filesize + " \u00B7 " + formatedTime);
			} else {
				viewHolder.time.setText(formatedTime);
			}
		}
	}

	private void displayInfoMessage(ViewHolder viewHolder, String text) {
		if (viewHolder.download_button != null) {
			viewHolder.download_button.setVisibility(View.GONE);
		}
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.GONE);
		viewHolder.messageBody.setVisibility(View.VISIBLE);
		viewHolder.messageBody.setText(text);
		viewHolder.messageBody.setTextColor(activity.getSecondaryTextColor());
		viewHolder.messageBody.setTypeface(null, Typeface.ITALIC);
		viewHolder.messageBody.setTextIsSelectable(false);
	}

	private void displayDecryptionFailed(ViewHolder viewHolder) {
		if (viewHolder.download_button != null) {
			viewHolder.download_button.setVisibility(View.GONE);
		}
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.messageBody.setVisibility(View.VISIBLE);
		viewHolder.messageBody.setText(getContext().getString(
				R.string.decryption_failed));
		viewHolder.messageBody.setTextColor(activity.getWarningTextColor());
		viewHolder.messageBody.setTypeface(null, Typeface.NORMAL);
		viewHolder.messageBody.setTextIsSelectable(false);
	}

	private void displayTextMessage(final ViewHolder viewHolder, final Message message) {
		if (viewHolder.download_button != null) {
			viewHolder.download_button.setVisibility(View.GONE);
		}
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.GONE);
		viewHolder.playbutton.setVisibility(View.GONE);
		viewHolder.messageBody.setVisibility(View.VISIBLE);

		if (message.getBody() != null) {
			final String nick = UIHelper.getMessageDisplayName(message);
			final String formattedBody = message.getMergedBody().replaceAll("^" + Message.ME_COMMAND,
					nick + " ");
			if (message.getType() != Message.TYPE_PRIVATE) {
				if (message.hasMeCommand()) {
					final Spannable span = new SpannableString(formattedBody);
					span.setSpan(new StyleSpan(Typeface.BOLD_ITALIC), 0, nick.length(),
							Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					viewHolder.messageBody.setText(span);
				} else {
					viewHolder.messageBody.setText(message.getMergedBody());
				}
			} else {
				String privateMarker;
				if (message.getStatus() <= Message.STATUS_RECEIVED) {
					privateMarker = activity
							.getString(R.string.private_message);
				} else {
					final String to;
					if (message.getCounterpart() != null) {
						to = message.getCounterpart().getResourcepart();
					} else {
						to = "";
					}
					privateMarker = activity.getString(R.string.private_message_to, to);
				}
				final Spannable span = new SpannableString(privateMarker + " "
						+ formattedBody);
				span.setSpan(new ForegroundColorSpan(activity
						.getSecondaryTextColor()), 0, privateMarker
						.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				span.setSpan(new StyleSpan(Typeface.BOLD), 0,
						privateMarker.length(),
						Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				if (message.hasMeCommand()) {
					span.setSpan(new StyleSpan(Typeface.BOLD_ITALIC), privateMarker.length() + 1,
							privateMarker.length() + 1 + nick.length(),
							Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
				viewHolder.messageBody.setText(span);
//					Log.i("messagebody", "set text --" + span);
			}
		} else {
			viewHolder.messageBody.setText("");
		}
//		System.out.println("messagebody Hey Jose: it is in MessageAdapter.java:" + viewHolder.messageBody.getText().toString());
		viewHolder.messageBody.setTextColor(activity.getPrimaryTextColor());
		viewHolder.messageBody.setTypeface(null, Typeface.NORMAL);
		viewHolder.messageBody.setTextIsSelectable(true);
//		}
	}
	// Changes made by Elumalai for video thumbnail
	private void displayDownloadableMessage(ViewHolder viewHolder,
											final Message message, String text) {
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.VISIBLE);
		viewHolder.playbutton.setVisibility(View.VISIBLE);
		viewHolder.messageBody.setVisibility(View.GONE);
		viewHolder.download_button.setVisibility(View.GONE);
		DownloadableFile file = activity.xmppConnectionService.getFileBackend().getFile(message);
		String filepath1 = String.valueOf(file);
		/*Log.i("displayDownloadableMessage", "file.getMimeType() ---"+file.getMimeType());
		Log.i("displayDownloadableMessage", "file.getClass() ---"+file.getClass());
		Log.i("displayDownloadableMessage", "file.length() ---"+file.length());
		Log.i("displayDownloadableMessage", "file.getExpectedSize() ---"+file.getExpectedSize());
		Log.i("displayDownloadableMessage", "file.getSha1Sum() ---"+file.getSha1Sum());
		Log.i("displayDownloadableMessage", "file.getSize() ---"+file.getSize());
		Log.i("displayDownloadableMessage", "file.getTotalSpace() ---"+file.getTotalSpace());*/
		try {
			Log.i("displayDownloadableMessage", "file.getCanonicalFile() ---"+file.getCanonicalFile());
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(file.getMimeType().contains("audio")){
			viewHolder.video.setImageResource(R.drawable.audio);
		}else if (file.getMimeType().contains("video")){
			Bitmap bmThumbnail;
			bmThumbnail = ThumbnailUtils.createVideoThumbnail(filepath1, MediaStore.Video.Thumbnails.MINI_KIND);
			Log.i("displayDownloadableMessage", "Bitmap values -- "+bmThumbnail   );
			if (bmThumbnail == null) {
				viewHolder.video.setImageResource(R.drawable.video_play);
//				viewHolder.download_button.setVisibility(View.VISIBLE);
//				viewHolder.download_button.setText(text);
			} else {
				viewHolder.video.setImageBitmap(bmThumbnail);
			}
		} else {
			viewHolder.video.setVisibility(View.GONE);
			viewHolder.playbutton.setVisibility(View.GONE);
			viewHolder.download_button.setVisibility(View.VISIBLE);
			viewHolder.download_button.setText(text);
		}
		viewHolder.video.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startDownloadable(message);
			}
		});
		viewHolder.video.setOnLongClickListener(openContextMenu);
		viewHolder.download_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startDownloadable(message);
			}
		});
		viewHolder.download_button.setOnLongClickListener(openContextMenu);
	}

	// Changes made by Elumalai for video thumbnail
	private void displayOpenableMessage(ViewHolder viewHolder,final Message message) {
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.VISIBLE);
		viewHolder.playbutton.setVisibility(View.VISIBLE);
		viewHolder.messageBody.setVisibility(View.GONE);
		viewHolder.download_button.setVisibility(View.GONE);
		DownloadableFile file = activity.xmppConnectionService.getFileBackend().getFile(message);
		String filepath1 = String.valueOf(file);
		Log.i("displayOpenableMessage", "file.getMimeType() ---" + file.getMimeType());
		if(file.getMimeType().contains("audio")){
			viewHolder.video.setImageResource(R.drawable.audio);
		}else if (file.getMimeType().contains("video")){
			Bitmap bmThumbnail;
			bmThumbnail = ThumbnailUtils.createVideoThumbnail(filepath1, MediaStore.Video.Thumbnails.MINI_KIND);
			Log.i("displayOpenableMessage", "Bitmap values --"+bmThumbnail    );
			if (bmThumbnail == null) {
				viewHolder.video.setImageResource(R.drawable.video_play);
			} else {
				viewHolder.video.setImageBitmap(bmThumbnail);
			}
		}else {
			viewHolder.video.setVisibility(View.GONE);
			viewHolder.playbutton.setVisibility(View.GONE);
			viewHolder.download_button.setVisibility(View.VISIBLE);
			viewHolder.download_button.setText(activity.getString(R.string.open_x_file, UIHelper.getFileDescriptionString(activity, message)));
		}
//		viewHolder.download_button.setText(activity.getString(R.string.open_x_file, UIHelper.getFileDescriptionString(activity, message)));
		viewHolder.video.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				openDownloadable(message);
			}
		});
		viewHolder.video.setOnLongClickListener(openContextMenu);
		viewHolder.download_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				openDownloadable(message);
			}
		});
		viewHolder.download_button.setOnLongClickListener(openContextMenu);

	}

	// Added by Elumalai for Sharing location
	private void displayLocationMessage(ViewHolder viewHolder, final Message message) {
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.playbutton.setVisibility(View.GONE);
		viewHolder.messageBody.setVisibility(View.GONE);
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.GONE);
		viewHolder.download_button.setVisibility(View.VISIBLE);
		viewHolder.download_button.setText(R.string.show_location);
		viewHolder.download_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showLocation(message);
			}
		});
		viewHolder.download_button.setOnLongClickListener(openContextMenu);
	}

	// Added by Elumalai for Sharing Contact
	private void displayContactMessage(ViewHolder viewHolder, final Message message){
		viewHolder.image.setVisibility(View.GONE);
		viewHolder.playbutton.setVisibility(View.GONE);
		viewHolder.messageBody.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.GONE);
		viewHolder.download_button.setVisibility(View.GONE);
		viewHolder.contactname.setVisibility(View.VISIBLE);
		viewHolder.contactimg.setVisibility(View.VISIBLE);
		String finalName = null;
		String finalNumber = null;
		String finalEmail = null;
		String finalImage = null;
		Bitmap photos = null;
		String contactdetails = message.getBody().toString();
		String CD = contactdetails.substring(8);
		String[] tokens = CD.split(",");
		int tokenCount = tokens.length;
		for (int j = 0; j < tokenCount; j++) {
			final String token = tokens[j];
		}
		if(tokenCount == 2) {
			finalName = tokens[0];
			finalNumber = tokens[1];
		}else if(tokenCount == 3) {
			finalName = tokens[0];
			finalNumber = tokens[1];
			finalEmail = tokens[2];
		}else {
			finalName = tokens[0];
			finalNumber = tokens[1];
			finalEmail = tokens[2];
			finalImage = tokens[3];
		}

		final String finalName1 = finalName;
		final String finalNumber1 = finalNumber;
		final String finalEmail1 = finalEmail;
		final String finalImage1 = finalImage;
		if (finalImage1 == null){
			viewHolder.contactimg.setImageResource(R.drawable.contact_icon);
		}else {
			photos = StringToBitMap(finalImage1);
		}
		viewHolder.contactname.setText(finalName);
		viewHolder.contactimg.setImageBitmap(photos);

//		Log.i("condetacdetails 111", "Name --"+finalName1+ "Number --"+finalNumber1+ "Email --"+finalEmail1 +"contact Photos --"+finalImage1 +"--------------"+photos);

		viewHolder.contactname.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent showcontact = new Intent();
				showcontact = new Intent(getContext(), ShowContact.class);
				showcontact.putExtra("name", finalName1);
				showcontact.putExtra("number", finalNumber1);
				showcontact.putExtra("email", finalEmail1);
				showcontact.putExtra("image",finalImage1);
				getContext().startActivity(showcontact);
			}
		});
		viewHolder.contactname.setOnLongClickListener(openContextMenu);
	}

	public Bitmap StringToBitMap(String encodedString){
		try {
			byte [] encodeByte= Base64.decode(encodedString, Base64.DEFAULT);
			Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
			return bitmap;
		} catch(Exception e) {
			e.getMessage();
			return null;
		}
	}
	private void displayImageMessage(ViewHolder viewHolder,
									 final Message message) {
		if (viewHolder.download_button != null) {
			viewHolder.download_button.setVisibility(View.GONE);
		}
		viewHolder.contactname.setVisibility(View.GONE);
		viewHolder.contactimg.setVisibility(View.GONE);
		viewHolder.messageBody.setVisibility(View.GONE);
		viewHolder.playbutton.setVisibility(View.GONE);
		viewHolder.video.setVisibility(View.GONE);
		viewHolder.image.setVisibility(View.VISIBLE);
		ImageParams params = message.getImageParams();
		double target = metrics.density * 288;
		int scalledW;
		int scalledH;
		if (params.width <= params.height) {
			scalledW = (int) (params.width / ((double) params.height / target));
			scalledH = (int) target;
		} else {
			scalledW = (int) target;
			scalledH = (int) (params.height / ((double) params.width / target));
		}
		viewHolder.image.setLayoutParams(new LinearLayout.LayoutParams(
				scalledW, scalledH));
		activity.loadBitmap(message, viewHolder.image);
		viewHolder.image.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(activity.xmppConnectionService
						.getFileBackend().getJingleFileUri(message), "image/*");
				getContext().startActivity(intent);
			}
		});
		viewHolder.image.setOnLongClickListener(openContextMenu);
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {

		final Message message = getItem(position);
		final Conversation conversation = message.getConversation();
		final Account account = conversation.getAccount();

		isEventGrp = conversation.getJid().toBareJid().toString().contains("_ev_");
		final int type = getItemViewType(position);

		ViewHolder viewHolder;
		if (view == null) {
			viewHolder = new ViewHolder();
			switch (type) {
				case NULL:
					view = activity.getLayoutInflater().inflate(R.layout.message_null, parent, false);
					break;
				case SENT:
					if (isEventGrp) {
						view = activity.getLayoutInflater().inflate(R.layout.message_event, parent, false);
						viewHolder.message_box = (LinearLayout) view
								.findViewById(R.id.message_box);
						viewHolder.download_button = (Button) view
								.findViewById(R.id.download_button);
						viewHolder.indicator = (ImageView) view
								.findViewById(R.id.security_indicator);
						viewHolder.image = (ImageView) view
								.findViewById(R.id.message_image);
						viewHolder.video = (ImageView) view
								.findViewById(R.id.message_video);
						viewHolder.playbutton = (ImageView) view
								.findViewById(R.id.playbutton);
						viewHolder.contactimg = (ImageView) view
								.findViewById(R.id.contact_img);
						viewHolder.contactname = (TextView) view
								.findViewById(R.id.contact_name);
						viewHolder.messageBody = (TextView) view
								.findViewById(R.id.message_body);
						viewHolder.time = (TextView) view
								.findViewById(R.id.message_time);
						viewHolder.membername = (TextView) view
								.findViewById(R.id.messager_name);
						viewHolder.indicatorReceived = (ImageView) view
								.findViewById(R.id.indicator_received);
						viewHolder.Ecomments = (TextView) view
								.findViewById(R.id.message_Comments);
						viewHolder.Elike = (TextView) view
								.findViewById(R.id.like);
						viewHolder.Comment_Count = (TextView) view
								.findViewById(R.id.comment_count);
						viewHolder.Like_Count = (TextView) view
								.findViewById(R.id.like_count);
						viewHolder.Elike.setText(getContext().getString(R.string.event_like));
						viewHolder.Ecomments.setText(getContext().getString(R.string.event_comments));
						viewHolder.Like_Count.setText("0");
						viewHolder.Comment_Count.setText("0");
					} else {
						view = activity.getLayoutInflater().inflate(
								R.layout.message_sent, parent, false);
						viewHolder.message_box = (LinearLayout) view
								.findViewById(R.id.message_box);
						viewHolder.contact_picture = (ImageView) view
								.findViewById(R.id.message_photo);
						viewHolder.download_button = (Button) view
								.findViewById(R.id.download_button);
						viewHolder.indicator = (ImageView) view
								.findViewById(R.id.security_indicator);
						viewHolder.image = (ImageView) view
								.findViewById(R.id.message_image);
						viewHolder.video = (ImageView) view
								.findViewById(R.id.message_video);
						viewHolder.playbutton = (ImageView) view
								.findViewById(R.id.playbutton);
						viewHolder.contactimg = (ImageView) view
								.findViewById(R.id.contact_img);
						viewHolder.contactname = (TextView) view
								.findViewById(R.id.contact_name);
						viewHolder.messageBody = (TextView) view
								.findViewById(R.id.message_body);
						viewHolder.time = (TextView) view
								.findViewById(R.id.message_time);
						viewHolder.indicatorReceived = (ImageView) view
								.findViewById(R.id.indicator_received);
					}
					break;
				case RECEIVED:
					view = activity.getLayoutInflater().inflate(
							R.layout.message_received, parent, false);
					viewHolder.message_box = (LinearLayout) view
							.findViewById(R.id.message_box);
					viewHolder.contact_picture = (ImageView) view
							.findViewById(R.id.message_photo);
					viewHolder.download_button = (Button) view
							.findViewById(R.id.download_button);
					viewHolder.indicator = (ImageView) view
							.findViewById(R.id.security_indicator);
					viewHolder.image = (ImageView) view
							.findViewById(R.id.message_image);
					viewHolder.video = (ImageView) view
							.findViewById(R.id.message_video);
					viewHolder.playbutton = (ImageView) view
							.findViewById(R.id.playbutton);
					viewHolder.contactimg = (ImageView) view
							.findViewById(R.id.contact_img);
					viewHolder.contactname = (TextView) view
							.findViewById(R.id.contact_name);
					viewHolder.messageBody = (TextView) view
							.findViewById(R.id.message_body);
					viewHolder.time = (TextView) view
							.findViewById(R.id.message_time);
					viewHolder.indicatorReceived = (ImageView) view
							.findViewById(R.id.indicator_received);
					break;
				case TYPE_MUC_NOTIFICATION:
					view = activity.getLayoutInflater().inflate(R.layout.message_null, parent, false);
					break;

				case STATUS:
					view = activity.getLayoutInflater().inflate(R.layout.message_status, parent, false);
					viewHolder.contact_picture = (ImageView) view.findViewById(R.id.message_photo);
					viewHolder.status_message = (TextView) view.findViewById(R.id.status_message);
					break;
				default:
					viewHolder = null;
					break;
			}
			if (view != null)
				view.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) view.getTag();
			if (viewHolder == null) {
				return view;
			}
		}

		if (type == STATUS) {
			if (conversation.getMode() == Conversation.MODE_SINGLE) {
				viewHolder.contact_picture.setImageBitmap(activity
						.avatarService().get(conversation.getContact(),
								activity.getPixel(32)));
				viewHolder.contact_picture.setAlpha(0.5f);
				viewHolder.status_message.setText(message.getBody());
			}
			return view;
		} else if (type == NULL) {
			if (viewHolder.message_box != null) {
				Log.e(Config.LOGTAG, "detected type=NULL but with wrong cached view");
				view = activity.getLayoutInflater().inflate(R.layout.message_null, parent, false);
				view.setTag(new ViewHolder());
			}
			if (position == getCount() - 1) {
				view.getLayoutParams().height = 1;
			} else {
				view.getLayoutParams().height = 0;

			}
			view.setLayoutParams(view.getLayoutParams());
			Log.i("----- Null Pointer Exception -----", "View at Null ---- View : " + view);
			return view;
		} else if (message.wasMergedIntoPrevious()) {
			Log.e(Config.LOGTAG, "detected wasMergedIntoPrevious with wrong type");
			Log.i("----- Null Pointer Exception -----", "View at message.wasMergedIntoPrevious() ---- View : " + view);
			return view;
		} else if (viewHolder.messageBody == null || viewHolder.image == null) {
			if(viewHolder.messageBody == null) {
				Log.i("----- Null Pointer Exception -----", "View at viewHolder.messageBody ---- View : " + view);
			} else if(viewHolder.image == null) {
				Log.i("----- Null Pointer Exception -----", "View at viewHolder.image ---- View : " + view);
			}
			return view; //avoiding weird platform bugs
		} else if (type == RECEIVED) {
			Contact contact = message.getContact();
			if (contact != null) {
				viewHolder.contact_picture.setImageBitmap(activity.avatarService().get(contact, activity.getPixel(48)));
			} else if (conversation.getMode() == Conversation.MODE_MULTI) {
				viewHolder.contact_picture.setImageBitmap(activity.avatarService().get(
						UIHelper.getMessageDisplayName(message),
						activity.getPixel(48)));
			}
		} else if (type == SENT && !isEventGrp) {
			viewHolder.contact_picture.setImageBitmap(activity.avatarService().get(account, activity.getPixel(48)));
		} else if (type == SENT && isEventGrp) {
			viewHolder.membername.setText(UIHelper.getMessageDisplayName(message));

		} else if (type == TYPE_MUC_NOTIFICATION) {
			viewHolder.messageBody.setText(message.getMergedBody());
			Log.i("----- Null Pointer Exception -----", "View at TYPE_MUC_NOTIFICATION ---- View : " + view);
			return view;
		}

		if (!isEventGrp) {
			viewHolder.contact_picture
					.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							if (MessageAdapter.this.mOnContactPictureClickedListener != null) {
								MessageAdapter.this.mOnContactPictureClickedListener
										.onContactPictureClicked(message);
							}

						}
					});
			viewHolder.contact_picture
					.setOnLongClickListener(new OnLongClickListener() {

						@Override
						public boolean onLongClick(View v) {
							if (MessageAdapter.this.mOnContactPictureLongClickedListener != null) {
								MessageAdapter.this.mOnContactPictureLongClickedListener
										.onContactPictureLongClicked(message);
								return true;
							} else {
								return false;
							}
						}
					});

		}
		if (isEventGrp) {
			viewHolder.Ecomments.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					MessageAdapter.this.monECommentsClickedListener.OnEventCommentClicked(message);
				}
			});

			final ViewHolder finalViewHolder = viewHolder;
			viewHolder.Elike.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					String typeadd = "5";
					String messageid = message.getUuid();
					String liketype = "0";
					String createdby = message.getConversation().getAccount().getJid().getLocalpart();
					String cteatedon = UIHelper.readableTimeDifferenceFull(getContext(),
							message.getMergedTimeSent());
					Log.i("likecount", "message.getUuid() --" + message.getUuid() + "--- temp message id --" + tempmessageid);
					if (finalViewHolder != null && tempmessageid == 1 ) {
						AsyncTask<String, Integer, String> data = new ExecuteTask(finalViewHolder).execute(typeadd, messageid, liketype, createdby, cteatedon);
						tempmessageid++;
					}else {
						Log.i("likecount", "message.getUuid() --"+message.getUuid() + "--- temp message id --"+tempmessageid);
						Log.i("likecount", "messageid --"+messageid + "--- messagidelikecount --"+messagidelikecount);
						if ( messageid == messagidelikecount) {
							Toast.makeText(getContext(), "only once",Toast.LENGTH_LONG).show();
							finalViewHolder.Elike.setCursorVisible(false);
							finalViewHolder.Elike.setBackgroundColor(0xFFFF0000);
						}
					}
				}
			});
		}
		final Downloadable downloadable = message.getDownloadable();
		if (null != downloadable)
			System.out.println("Inside Message adapter::Jose::" + downloadable.getStatus());
		if (downloadable != null && downloadable.getStatus() != Downloadable.STATUS_UPLOADING) {
			if (downloadable.getStatus() == Downloadable.STATUS_OFFER) {
				displayDownloadableMessage(viewHolder, message, activity.getString(R.string.download_x_file, UIHelper.getFileDescriptionString(activity, message)));
			} else if (downloadable.getStatus() == Downloadable.STATUS_OFFER_CHECK_FILESIZE) {
				displayDownloadableMessage(viewHolder, message, activity.getString(R.string.check_image_filesize));
			} else {
				displayInfoMessage(viewHolder, UIHelper.getMessagePreview(activity, message).first);
			}
		} else if (message.getType() == Message.TYPE_IMAGE && message.getEncryption() != Message.ENCRYPTION_PGP && message.getEncryption() != Message.ENCRYPTION_DECRYPTION_FAILED) {
			displayImageMessage(viewHolder, message);
		} else if (message.getType() == Message.TYPE_FILE && message.getEncryption() != Message.ENCRYPTION_PGP && message.getEncryption() != Message.ENCRYPTION_DECRYPTION_FAILED) {
			if (message.getImageParams().width > 0) {
				displayImageMessage(viewHolder, message);
			} else {
				displayOpenableMessage(viewHolder, message);
			}
		} else if (message.getEncryption() == Message.ENCRYPTION_PGP) {
			if (activity.hasPgp()) {
				displayInfoMessage(viewHolder, activity.getString(R.string.encrypted_message));
			} else {
				displayInfoMessage(viewHolder,
						activity.getString(R.string.install_openkeychain));
				if (viewHolder != null) {
					viewHolder.message_box
							.setOnClickListener(new OnClickListener() {

								@Override
								public void onClick(View v) {
									activity.showInstallPgpDialog();
								}
							});
				}
			}
		} else if (message.getEncryption() == Message.ENCRYPTION_DECRYPTION_FAILED) {
			displayDecryptionFailed(viewHolder);
		} else {
			if (GeoHelper.isGeoUri(message.getBody())) {
				displayLocationMessage(viewHolder, message);
			} else if (message.getBody().toString().contains("contact:")) {
				displayContactMessage(viewHolder, message);
			} else {
				displayTextMessage(viewHolder, message);
			}
		}
		displayStatus(viewHolder, message);

		if (isEventGrp) {
			String typefetch = "4";
			String messageid = message.getUuid();
			//webserviceCall(viewHolder, message, typefetch);
			if (viewHolder != null) {
				ExecuteTask data1 = new ExecuteTask(viewHolder);
				data1.execute(typefetch, messageid, "", "", "");

			}
		}

		return view;
	}

	public void startDownloadable(Message message) {
		Downloadable downloadable = message.getDownloadable();
		if (downloadable != null) {
			if (!downloadable.start()) {
				Toast.makeText(activity, R.string.not_connected_try_again,
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	public void openDownloadable(Message message) {
		DownloadableFile file = activity.xmppConnectionService.getFileBackend().getFile(message);
		/*if (!file.exists()) {
			Toast.makeText(activity,R.string.file_deleted,Toast.LENGTH_SHORT).show();
			return;
		}*/
		Intent openIntent = new Intent(Intent.ACTION_VIEW);
		openIntent.setDataAndType(Uri.fromFile(file), file.getMimeType());
		PackageManager manager = activity.getPackageManager();
		List<ResolveInfo> infos = manager.queryIntentActivities(openIntent, 0);
		if (infos.size() > 0) {
			getContext().startActivity(openIntent);
		} else {
			Toast.makeText(activity,R.string.no_application_found_to_open_file,Toast.LENGTH_SHORT).show();
		}
	}

	public void showLocation(Message message) {
		for(Intent intent : GeoHelper.createGeoIntentsFromMessage(message)) {
			if (intent.resolveActivity(getContext().getPackageManager()) != null) {
				getContext().startActivity(intent);
				return;
			}
		}
		Toast.makeText(activity,R.string.no_application_found_to_display_location,Toast.LENGTH_SHORT).show();
	}

	public interface OnContactPictureClicked {
		public void onContactPictureClicked(Message message);
	}

	public interface OnContactPictureLongClicked {
		public void onContactPictureLongClicked(Message message);
	}
	// Added by Elumalai for Event Comments
	public interface OnEventCommentClicked {
		public void OnEventCommentClicked(Message message);
	}

	class ExecuteTask extends AsyncTask<String, Integer, String>
	{
		private  final  WeakReference<ViewHolder> viewHolderWeakReference;

		public ExecuteTask(ViewHolder viewHolder){
			viewHolderWeakReference = new WeakReference<ViewHolder>(viewHolder);
		}

		@Override
		protected String doInBackground(String... params) {
			String res= null;
			res = PostData(params);

			return res;
		}

		@Override
		protected void onPostExecute(String result) {

			String comments_count = null;
			String likes_count = null;

			try {
				JSONArray jsonArray = new JSONArray(result);
				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject jsonObject = jsonArray.getJSONObject(i);
					messagidelikecount = jsonObject.optString("event_msg_id").toString();
					comments_count = jsonObject.optString("comments_count").toString();
					likes_count = jsonObject.optString("likes_count").toString();
					String unlikes_count = jsonObject.optString("unlikes_count").toString();
				}

				if(this.viewHolderWeakReference != null){
					ViewHolder viewHolder = viewHolderWeakReference.get();

					if(viewHolder != null){
						viewHolder.Comment_Count.setText(comments_count);
						viewHolder.Like_Count.setText(likes_count);
					}
				}
			}
			catch (JSONException e) {e.printStackTrace();}

		}
		//viewHolder.progressBar.setVisibility(View.GONE);
	}

	public String PostData(String[] values) {
		String s="";
		try
		{
			HttpClient httpClient=new DefaultHttpClient();
			HttpPost httpPost=new HttpPost("http://palscom.com/ws/comments.php");

			List<NameValuePair> list=new ArrayList<NameValuePair>();
			list.add(new BasicNameValuePair("type", values[0]));
			list.add(new BasicNameValuePair("event_msg_id", values[1]));
			list.add(new BasicNameValuePair("like_type",  values[2]));
			list.add(new BasicNameValuePair("created_by",  values[3]));
			list.add(new BasicNameValuePair("created_on",  values[4]));
			httpPost.setEntity(new UrlEncodedFormEntity(list));

			HttpResponse httpResponse=  httpClient.execute(httpPost);

			HttpEntity httpEntity=httpResponse.getEntity();
			s= readResponse(httpResponse);
		}
		catch(Exception exception)  {}
//        System.out.println("Elumalai post data:>>>>>6 ex" +s);
		return s;
	}

	public String readResponse(HttpResponse res) {
		InputStream is=null;
		String return_text="";

		try {
			is=res.getEntity().getContent();
			BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(is));
			String line="";
			StringBuffer sb=new StringBuffer();
			while ((line=bufferedReader.readLine())!=null)
			{
				sb.append(line);
			}
			return_text=sb.toString();
		} catch (Exception e)
		{

		}
//        System.out.println("Elumalai readresponse:>>>>> " +return_text);
		return return_text;

	}

	private static class ViewHolder {

		protected LinearLayout message_box;
		protected Button download_button;
		protected ImageView image;
		protected ImageView playbutton;
		protected ImageView indicator;
		protected ImageView indicatorReceived;
		protected TextView time;
		protected TextView messageBody;
		protected ImageView contact_picture;
		protected TextView status_message;
		protected TextView membername;
		protected TextView Ecomments;
		protected TextView Elike;
		protected TextView Comment_Count;
		protected ImageView contactimg;
		protected TextView contactname;
		protected TextView Like_Count;
		private ImageView video;
	}
}