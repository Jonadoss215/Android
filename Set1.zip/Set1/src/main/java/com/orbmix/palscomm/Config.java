package com.orbmix.palscomm;

import android.graphics.Bitmap;
import android.util.Log;

import com.orbmix.palscomm.xmpp.chatstate.ChatState;

public final class Config {

	public static final String LOGTAG = "palscomm";

	public static final boolean LEGACY_NAMESPACE_HTTP_UPLOAD = false;
	public static final boolean DISABLE_HTTP_UPLOAD = false;
	public static final boolean FORCE_ORBOT = false; // always use TOR
	public static final boolean FORCE_ENCRYPTION = false; //disables ability to send unencrypted 1-on-1

	public static final boolean REPORT_WRONG_FILESIZE_IN_OTR_JINGLE = true;
	public static final boolean ENCRYPT_ON_HTTP_UPLOADED = false;
	public static final int PING_MAX_INTERVAL = 300;
	public static final int PING_MIN_INTERVAL = 30;
	public static final int PING_TIMEOUT = 10;
	public static final int SOCKET_TIMEOUT = 15;
	public static final int CONNECT_TIMEOUT = 90;
	public static final int CARBON_GRACE_PERIOD = 60;
	public static final int MINI_GRACE_PERIOD = 750;

	public static final int AVATAR_SIZE = 192;
	public static final Bitmap.CompressFormat AVATAR_FORMAT = Bitmap.CompressFormat.WEBP;

	public static final int MESSAGE_MERGE_WINDOW = 2;

	public static final int PAGE_SIZE = 50;
	public static final int MAX_NUM_PAGES = 3;

	public static final int PROGRESS_UI_UPDATE_INTERVAL = 750;
	public static final int REFRESH_UI_INTERVAL = 500;

	public static final boolean NO_PROXY_LOOKUP = false; //useful to debug ibb
	public static final boolean DISABLE_STRING_PREP = false; // setting to true might increase startup performance
	public static final boolean EXTENDED_SM_LOGGING = true; // log stanza counts
	public static final boolean RESET_ATTEMPT_COUNT_ON_NETWORK_CHANGE = true; //setting to true might increase power consumption

	public static final long MILLISECONDS_IN_DAY = 24 * 60 * 60 * 1000;
	public static final long MAM_MAX_CATCHUP =  MILLISECONDS_IN_DAY / 2;
	public static final int MAM_MAX_MESSAGES = 500;

	public static final boolean X509_VERIFICATION = false; //use x509 certificates to verify OMEMO keys
	public static final String APP_MEDIA_FOLDER = "Palscomm";

	public static final ChatState DEFAULT_CHATSTATE = ChatState.ACTIVE;
	public static final int TYPING_TIMEOUT = 8;

	// CHANGE THIS TO YOUR URL
	//Added by Elumalai for webservices URLs
	/*public static final String UPLOAD_GRP_AVATAR_SERVER_URI = "http://palscom.com/ws/upldgrpavatarC.php";
	public static final String HTTP_UPLOAD_ENDPOINT = "http://palscom.com/ws/upload1.php";
	public static final String USER_REGISTRATION_URI = "http://198.12.158.187/ws/userregistration.php";
	public static final String ROSTER_URI = "http://198.12.158.187/ws/roster1.php";
	public static final String ADVERTISEMENTS_URI = "http://palscom.com/ws/ads.php";
	public static final String ADVERTISEMENTS_CATEGORIES_URI = "http://palscom.com/pals/index.php/ads-categorie/";
	public static final String GROUP_MEMBERS_URI = "http://198.12.158.187/ws/roster1.php";
	public static final String COMMENTS_URI = "http://palscom.com/ws/comments.php";*/


	//Added by Elumalai for webservices URLs   198.12.158.187
	public static final String SERVER_NAME = "palscom.com";
	public static final String UPLOAD_GRP_AVATAR_SERVER_URI = "http://"+SERVER_NAME+"/ws/upldgrpavatarC.php";
	public static final String HTTP_UPLOAD_ENDPOINT = "http://"+SERVER_NAME+"/ws/upload1.php";
	public static final String USER_REGISTRATION_URI = "http://"+SERVER_NAME+"/ws/userregistration.php";
	public static final String ROSTER_URI = "http://"+SERVER_NAME+"/ws/roster1.php";
	public static final String ADVERTISEMENTS_URI = "http://"+SERVER_NAME+"/ws/ads.php";
	public static final String ADVERTISEMENTS_CATEGORIES_URI = "http://"+SERVER_NAME+"/pals/index.php/ads-categorie/";
	public static final String GROUP_MEMBERS_URI = "http://"+SERVER_NAME+"/ws/groupmembers.php";
	public static final String COMMENTS_URI = "http://"+SERVER_NAME+"/ws/comments.php";
	public static final String AVATAR_URI = "http://"+SERVER_NAME+"/ws/groupavatars/";
	public static final String MEDIA_URI = "http://"+SERVER_NAME+"/media/";


	public static final String ENABLED_CIPHERS[] = {
		"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
		"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA384",
		"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA256",
		"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
		"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA",
		"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA",

		"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256",
		"TLS_DHE_RSA_WITH_AES_128_GCM_SHA384",
		"TLS_DHE_RSA_WITH_AES_256_GCM_SHA256",
		"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384",

		"TLS_DHE_RSA_WITH_CAMELLIA_256_SHA",

		// Fallback.
		"TLS_RSA_WITH_AES_128_GCM_SHA256",
		"TLS_RSA_WITH_AES_128_GCM_SHA384",
		"TLS_RSA_WITH_AES_256_GCM_SHA256",
		"TLS_RSA_WITH_AES_256_GCM_SHA384",
		"TLS_RSA_WITH_AES_128_CBC_SHA256",
		"TLS_RSA_WITH_AES_128_CBC_SHA384",
		"TLS_RSA_WITH_AES_256_CBC_SHA256",
		"TLS_RSA_WITH_AES_256_CBC_SHA384",
		"TLS_RSA_WITH_AES_128_CBC_SHA",
		"TLS_RSA_WITH_AES_256_CBC_SHA",
	};

	public static final String WEAK_CIPHER_PATTERNS[] = {
		"_NULL_",
		"_EXPORT_",
		"_anon_",
		"_RC4_",
		"_DES_",
		"_MD5",
	};

	private Config() {

	}
}
