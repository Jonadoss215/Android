package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;

public interface OnBindListener {
	public void onBind(Account account);
}
