package com.orbmix.palscomm.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Blockable;
import com.orbmix.palscomm.entities.Favorite;
import com.orbmix.palscomm.services.XmppConnectionService;

/**
 * Created by Elumalai on 12/30/2015.
 */
public class FavoriteContactDialog {
    public static void show(final Context context,
                            final XmppConnectionService xmppConnectionService,
                            final Favorite favorite) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        final boolean isFavorite = favorite.isFavorite();
        builder.setNegativeButton(R.string.cancel, null);

        if (favorite.getJid().isDomainJid() || favorite.getAccount().isBlocked(favorite.getJid().toDomainJid())) {
            builder.setTitle(isFavorite ? R.string.action_unfavorite_domain : R.string.action_favorite_domain);
            builder.setMessage(context.getResources().getString(isFavorite ? R.string.unfavorite_domain_text : R.string.favorite_domain_text,
                    favorite.getName()));
        } else {

            builder.setTitle(isFavorite ? R.string.action_unfavorite_contact : R.string.action_favorite_contact);
            builder.setMessage(context.getResources().getString(isFavorite ? R.string.unfavorite_contact_text : R.string.favorite_contact_text,
                    favorite.getName()));
        }
        builder.setPositiveButton(isFavorite ? R.string.unfavorite : R.string.favorite, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                if (isFavorite) {
                    xmppConnectionService.sendUnFavoriteRequest(favorite);
                } else {
                    xmppConnectionService.sendFavoriteRequest(favorite);
                }
            }
        });
        builder.create().show();
    }
}
