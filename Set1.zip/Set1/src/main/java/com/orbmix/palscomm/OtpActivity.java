package com.orbmix.palscomm;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.orbmix.palscomm.services.WebServices;
import com.orbmix.palscomm.ui.EditAccountActivity;
import com.orbmix.palscomm.utils.ConnectionDetector;
import com.orbmix.palscomm.utils.HttpCall;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.InputType;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class OtpActivity extends Activity {

    public Button btnSubmit;
    public TextView lblOTP;
    public EditText txtOTP;
    public TextView lblInfo;
    public TextView lblResend;
    public String uid,user,country,countrycode;
    public Boolean newregistration;
    Context cont;
    // flag for Internet connection status
    Boolean isInternetPresent = false;
    // Connection detector class
    ConnectionDetector cd;

    // Added by Elumalai for webservices
    WebServices webservices = new WebServices();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_otp);
		cont = this;
		
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
		    uid = extras.getString("UID");
		    newregistration = extras.getBoolean("New");
            user = extras.getString("user");
            country = extras.getString("country");
            countrycode = extras.getString("countrycode");

		}

        Log.i("otpActivity", "UID --"+uid);
        Log.i("otpActivity", "New Register --"+newregistration);
        Log.i("otpActivity", "User --"+user);
        Log.i("otpActivity", "Country --"+country);
        Log.i("otpActivity", "Country Cody --"+countrycode);
		//RelativeLayout myLayout = new RelativeLayout(this);
		LinearLayout myLayout = new LinearLayout(cont);
        myLayout.setPadding(10,10,10,10);
		myLayout.setOrientation(LinearLayout.VERTICAL);
		cd = new ConnectionDetector(getApplicationContext());
		
        //** Button **//
        btnSubmit = new Button(cont);
        //btnSubmit.setText("Submit");
        //btnSubmit.setTextAppearance(cont, getTitleColor());
		btnSubmit.setBackgroundResource(R.drawable.rounded_button);
//        btnSubmit.setPadding(0,40,0,0);
        btnSubmit.setText("SUBMIT");
        btnSubmit.setTextColor(Color.WHITE);
        btnSubmit.setPadding(10,10,10,20);
        // ** txtOTP *//
        lblOTP = new TextView(cont);
        lblOTP.setText("Enter the OTP:");
        lblOTP.setPadding(10,10,10,20);
        
        txtOTP = new EditText(cont);
        txtOTP.setHint("OTP");
        txtOTP.setInputType(InputType.TYPE_CLASS_NUMBER);
        txtOTP.setPadding(20,10,10,5);


        lblInfo = new TextView(cont);
        lblInfo.setText("Please enter the verification code received by SMS. If you did not receive the verification code, please try the following.");
        lblInfo.setPadding(10, 20, 10, 20);


        lblResend = new TextView(cont);
        //lblResend.setText("Resend One Time Password");
        lblResend.setGravity(Gravity.CENTER_HORIZONTAL);
        lblResend.setPadding(10,20,0,50);
        SpannableString spanString = new SpannableString("Resend One Time Password");
        spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), 0);
        spanString.setSpan(new StyleSpan(Typeface.BOLD), 0, spanString.length(), 0);


        lblResend.setText(spanString);
        lblResend.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String content;
                System.out.println("Hello::" + uid.trim());
                try {
                    countrycode = countrycode.substring(1);
                    content = "user="+URLEncoder.encode(user, "UTF-8")+"&type="+URLEncoder.encode("1");
                    content = content + "&countrycode="+"+"+URLEncoder.encode(countrycode, "UTF-8");
                    content = content + "&country="+URLEncoder.encode(country, "UTF-8");
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    lblResend.setEnabled(false);
                    Log.i("otpActivity", "webservices call parameter :" + content);
                    String serviceReturn = HttpCall.webService(Config.USER_REGISTRATION_URI, content);
                    Log.i("otpActivity", "sebservices call retuen values in OTP :"+serviceReturn);
                    lblResend.setEnabled(true);
                }
                catch(Exception e)
                {
                   e.printStackTrace();
                }

                //"user="+URLEncoder.encode(uid.trim(), "UTF-8")+"&type="+URLEncoder.encode("2"); 2087
            }
        });

        myLayout.addView(lblOTP);
        myLayout.addView(txtOTP);
        myLayout.addView(lblInfo);
        myLayout.addView(lblResend);
        myLayout.addView(btnSubmit);

        // Button click Listener 
        addListenerOnButton();
        
      setContentView(myLayout);
      //connectToBackend();
	}
	
	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.otp, menu);
		return true;
	}

	private void addListenerOnButton() {
		 
        btnSubmit.setOnClickListener(new OnClickListener() {
 
            @Override
            public void onClick(View v) {
            	if(txtOTP.getText().toString().trim().isEmpty())
            	{
            		txtOTP.setError("Enter OTP");
            		txtOTP.requestFocus();
            		return;
            	}
            	
            	String content = null;
            	try {
//                 String Uid = uid.trim().substring(1);
//                    Log.i("otpActivity", "uid.substring(1)  :" + Uid);
                    content = "user="+URLEncoder.encode(uid, "UTF-8")+"&type="+URLEncoder.encode("2");
					content = content +"&passcode="+ URLEncoder.encode(txtOTP.getText().toString().trim(), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			    StrictMode.setThreadPolicy(policy); 
			    isInternetPresent = cd.isConnectingToInternet();
			    String serviceReturn = "";
                Log.i("otpActivity", "parameter  :"+content);
                if(isInternetPresent)
			    {
//                    serviceReturn = webservices.userRegistrationURL(content);
                     serviceReturn = HttpCall.webService(Config.USER_REGISTRATION_URI,content);
                    Log.i("otpActivity", "service Return values  :"+serviceReturn);
			    }
			    else
			    {
			    	// Internet connection is not present
	                   // Ask user to connect to Internet
	                   showAlertDialog(OtpActivity.this, "No Internet Connection",
	                           "You don't have internet connection.", false);
			    }
                //System.out.println("serviceReturn::"+serviceReturn);
            	
                if(serviceReturn.equalsIgnoreCase("userStatus2"))
                {
                	Toast.makeText(OtpActivity.this,
                            "OTP Success" ,
                            Toast.LENGTH_LONG).show();
                	Intent intent = new Intent(getBaseContext(), EditAccountActivity.class);
//                    Log.i("otoActiity", "UID  :"+uid);
                	intent.putExtra("UID", uid);
                	intent.putExtra("New", newregistration);
                	startActivity(intent);
                	OtpActivity.this.finish();
                }
               
                else
                {
                	txtOTP.setError("Invalid OTP");
            		txtOTP.requestFocus();
            		
            		return;
                }
                /*Toast.makeText(RegisterActivity.this,
                        "On Button Click : " + 
                        "\n" + String.valueOf(spinner1.getSelectedItem()) ,
                        Toast.LENGTH_LONG).show();*/
            }
 
        });
 
    }
	/**
     * Function to display simple Alert Dialog
     * @param context - application context
     * @param title - alert dialog title
     * @param message - alert message
     * @param status - success/failure (used to set icon)
     * */
    public void showAlertDialog(Context context, String title, String message, Boolean status)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
 
        // Setting Dialog Title
        alertDialog.setTitle(title);
 
        // Setting Dialog Message
        alertDialog.setMessage(message);
         
        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
 

        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        // Showing Alert Message
        alertDialog.show();
    }
}
