package com.orbmix.palscomm.ui.adapter;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Bookmark;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.Downloadable;
import com.orbmix.palscomm.entities.Message;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.ui.ConversationActivity;
import com.orbmix.palscomm.ui.XmppActivity;
import com.orbmix.palscomm.utils.UIHelper;

import org.osmdroid.ResourceProxy;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;

public class ConversationAdapter extends ArrayAdapter<Conversation> {

	private XmppActivity activity;

    public XmppConnectionService xmppConnectionService;
	public ConversationAdapter(XmppActivity activity,
			List<Conversation> conversations) {
		super(activity, 0, conversations);
		this.activity = activity;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		if (view == null) {
            //return ;
//            System.out.println("Jose.. I think it is here . null.");
            LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.conversation_list_row,parent, false);
		}
		/*System.out.println("Hey Jose: Inside ConversationAdapter getview function position.:"+position);
		System.out.println("Hey Jose: Inside ConversationAdapter getview function:getViewType:"+getItemViewType(position));
		System.out.println("Hey Jose: Inside ConversationAdapter getview function:getViewTypeCount:"+getViewTypeCount());*/
		Conversation conversation = getItem(position);
		if (this.activity instanceof ConversationActivity) {
			ConversationActivity activity = (ConversationActivity) this.activity;
			if (!activity.isConversationsOverviewHideable()) {
				if (conversation == activity.getSelectedConversation()) {
					view.setBackgroundColor(activity
							.getSecondaryBackgroundColor());
				} else {
					view.setBackgroundColor(Color.TRANSPARENT);
				}
			} else {
				view.setBackgroundColor(Color.TRANSPARENT);
			}
		}

		TextView mTimestamp = (TextView) view.findViewById(R.id.conversation_lastupdate);
		TextView unreadCount = (TextView) view.findViewById(R.id.conversation_unreadcount);

		if(conversation.unreadCount() > 0)
		{
			unreadCount.setText(""+conversation.unreadCount());
			unreadCount.setVisibility(View.VISIBLE);
			mTimestamp.setTextColor(Color.parseColor("#04c378"));
		}
		else
		{
			unreadCount.setVisibility(View.GONE);
			mTimestamp.setTextColor(Color.parseColor("#8a000000"));
		}

		//System.out.println("Hello Jose:The unread count::"+conversation.unreadCount() );
		TextView convName = (TextView) view.findViewById(R.id.conversation_name);
		if (conversation.getMode() == Conversation.MODE_SINGLE || activity.useSubjectToIdentifyConference()) {
			convName.setText(conversation.getName().toString().replace("_bc_", "").replace("_ev_",""));
		}
		else {
			convName.setText(conversation.getJid().toBareJid().getLocalpart().toString());
		}

        //below code added by Jose for adding groups in the bookmark by default.
        if(conversation.getMode() == Conversation.MODE_MULTI)
        {
            Account account = conversation.getAccount();
            if (!account.hasBookmarkFor(conversation.getJid().toBareJid()))
            {
                Bookmark bookmark = new Bookmark(account, conversation.getJid().toBareJid());
                bookmark.setAutojoin(true);
                account.getBookmarks().add(bookmark);
                //xmppConnectionService.pushBookmarks(account);
                conversation.setBookmark(bookmark);
            }
        }

		TextView mLastMessage = (TextView) view.findViewById(R.id.conversation_lastmsg);
		ImageView imagePreview = (ImageView) view.findViewById(R.id.conversation_lastimage);

		Message message = conversation.getLatestMessage();

		if (!conversation.isRead()) {
			convName.setTypeface(null, Typeface.BOLD);
		} else {
			convName.setTypeface(null, Typeface.NORMAL);
		}

		if (message.getImageParams().width > 0
				&& (message.getDownloadable() == null
				|| message.getDownloadable().getStatus() != Downloadable.STATUS_DELETED)) {
			mLastMessage.setVisibility(View.GONE);
			imagePreview.setVisibility(View.VISIBLE);
			activity.loadBitmap(message, imagePreview);
		} else {
			Pair<String,Boolean> preview = UIHelper.getMessagePreview(activity,message);
			mLastMessage.setVisibility(View.VISIBLE);
			imagePreview.setVisibility(View.GONE);
			mLastMessage.setText(preview.first);
			if (preview.second) {
				if (conversation.isRead()) {
					mLastMessage.setTypeface(null, Typeface.ITALIC);
				} else {
					mLastMessage.setTypeface(null,Typeface.BOLD_ITALIC);
				}
			} else {
				if (conversation.isRead()) {
					mLastMessage.setTypeface(null,Typeface.NORMAL);
				} else {
					mLastMessage.setTypeface(null,Typeface.BOLD);
				}
			}


		}

		Boolean isEventGroup = conversation.getJid().toBareJid().toString().contains("_ev_");
		Boolean isbcGroup = conversation.getJid().toBareJid().toString().contains("_bc_");

		mTimestamp.setText(UIHelper.readableTimeDifference(activity,conversation.getLatestMessage().getTimeSent()));
		Bitmap profilebm= null;
		ImageView profilePicture = (ImageView) view.findViewById(R.id.conversation_image);
		profilebm = activity.avatarService().get(conversation,activity.getPixel(48),true);
		if(profilebm != null){
				profilePicture.setImageBitmap(profilebm);
			}	else {
			if (conversation.getMode() == conversation.MODE_MULTI && isbcGroup){
				Drawable myDrawable = activity.getResources().getDrawable(R.drawable.bc_group);
				profilePicture.setImageDrawable(myDrawable);
			}else if (conversation.getMode() == conversation.MODE_MULTI && isEventGroup){
				Drawable myDrawable = activity.getResources().getDrawable(R.drawable.event_group);
				profilePicture.setImageDrawable(myDrawable);
			}else if (conversation.getMode() == conversation.MODE_MULTI){
				Drawable myDrawable = activity.getResources().getDrawable(R.drawable.group);
				profilePicture.setImageDrawable(myDrawable);
			}else {
				Drawable myDrawable = activity.getResources().getDrawable(R.drawable.user_default);
				profilePicture.setImageDrawable(myDrawable);
			}
			loadAvatar(conversation, profilePicture);
		}
		return view;
	}

	class BitmapWorkerTask extends AsyncTask<Conversation, Void, Bitmap> {
		private final WeakReference<ImageView> imageViewReference;
		private Conversation conversation = null;

		public BitmapWorkerTask(ImageView imageView) {
			imageViewReference = new WeakReference<>(imageView);
		}

		@Override
		protected Bitmap doInBackground(Conversation... params) {
			return activity.avatarService().get(params[0], activity.getPixel(56));
		}

		@Override
		protected void onPostExecute(Bitmap bitmap) {
			if (bitmap != null) {
				final ImageView imageView = imageViewReference.get();
				if (imageView != null) {
					imageView.setImageBitmap(null);
					imageView.setImageBitmap(bitmap);
					imageView.setBackgroundColor(0x00000000);
				}
			}
		}
	}


	public void loadAvatar(Conversation conversation, ImageView imageView) {
		Bitmap bm = null;
		if (cancelPotentialWork(conversation, imageView)) {
			bm = activity.avatarService().get(conversation, activity.getPixel(48), true);
			if (bm != null) {
				imageView.setImageBitmap(bm);
			}
		}
	}

	/*public void loadAvatar(Conversation conversation, ImageView imageView) {
		Bitmap bm = null;
			bm = activity.avatarService().get(conversation,activity.getPixel(48),true);
		if (bm != null) {
			imageView.setImageBitmap(null);
			imageView.setImageBitmap(bm);
			imageView.setBackgroundColor(0x00000000);
		} else if (cancelPotentialWork(conversation, imageView)) {
			UIHelper.paintImageView(conversation.getName(), imageView, activity.getPixel(48));
//			imageView.setBackgroundColor(UIHelper.getColorForName(conversation.getName()));
			imageView.setImageDrawable(null);
			final BitmapWorkerTask task = new BitmapWorkerTask(imageView);
			final AsyncDrawable asyncDrawable = new AsyncDrawable(activity.getResources(), null, task);
//			imageView.setImageDrawable(asyncDrawable);
			try {
				task.execute(conversation);
			} catch (final RejectedExecutionException ignored) {
			}
		}
	}*/

	public static boolean cancelPotentialWork(Conversation conversation, ImageView imageView) {
		final BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);

		if (bitmapWorkerTask != null) {
			final Conversation oldConversation = bitmapWorkerTask.conversation;
			if (oldConversation == null || conversation != oldConversation) {
				bitmapWorkerTask.cancel(true);
			} else {
				return false;
			}
		}
		return true;
	}

	private static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
		if (imageView != null) {
 			final Drawable drawable = imageView.getDrawable();
			if (drawable instanceof AsyncDrawable) {
				final AsyncDrawable asyncDrawable = (AsyncDrawable) drawable;
				return asyncDrawable.getBitmapWorkerTask();
			}
		}
		return null;
	}

	static class AsyncDrawable extends BitmapDrawable {
		private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

		public AsyncDrawable(Resources res, Bitmap bitmap, BitmapWorkerTask bitmapWorkerTask) {
			super(res, bitmap);
			bitmapWorkerTaskReference = new WeakReference<>(bitmapWorkerTask);
		}

		public BitmapWorkerTask getBitmapWorkerTask() {
			return bitmapWorkerTaskReference.get();
		}
	}
}