/*
package com.orbmix.palscomm.entities;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;


public class EventComments extends AbstractEntity {

	public static final String TABLENAME = "comments";

	public static final String MERGE_SEPARATOR = "\u200B\n\n";



	public static final String EVENT_MSG_ID = "messageUuid";
	public static final String COMMENTS_ID = "commentsId";
	public static final String BODY = "body";
	public static final String TIME_SENT = "timeSent";
	public static final String STATUS = "status";
	public static final String SERVER_MSG_ID = "serverMsgId";

	public boolean markable = false;
	protected String conversationUuid;
	protected Jid counterpart;
	protected Jid trueCounterpart;
	protected String body;
	protected String encryptedBody;
	protected long timeSent;
	protected int encryption;
	protected int status;
	protected int type;
	protected String relativeFilePath;
	protected boolean read = true;
	protected String remoteMsgId = null;
	protected String serverMsgId = null;
	protected Conversation conversation = null;
	protected Downloadable downloadable = null;
	private EventComments mNextMessage = null;
	private EventComments mPreviousMessage = null;
	private int fileProgress = -1;
	private Uri broadcastFileUri = null;

	private EventComments() {

	}

	public EventComments(Conversation conversation, String body, int encryption) {
		this(conversation, body, encryption, STATUS_UNSEND);
	}

	public EventComments(Conversation conversation, String body, int encryption, int status) {
		this(java.util.UUID.randomUUID().toString(),
				conversation.getUuid(),
				conversation.getJid() == null ? null : conversation.getJid().toBareJid(),
				null,
				body,
				System.currentTimeMillis(),
				encryption,
				status,
				TYPE_TEXT,
				null,
				null,
				null);
		this.conversation = conversation;
	}


	private EventComments(final String uuid, final String conversationUUid, final Jid counterpart,
						  final Jid trueCounterpart, final String body, final long timeSent,
						  final int encryption, final int status, final int type, final String remoteMsgId,
						  final String relativeFilePath, final String serverMsgId) {
		this.uuid = uuid;
		this.conversationUuid = conversationUUid;
		this.counterpart = counterpart;
		this.trueCounterpart = trueCounterpart;
		this.body = body;
		this.timeSent = timeSent;
		this.encryption = encryption;
		this.status = status;
		this.type = type;
		this.remoteMsgId = remoteMsgId;
		this.relativeFilePath = relativeFilePath;
		this.serverMsgId = serverMsgId;
	}

	public void setBroadcastFileUri(Uri fileURI)
	{
		this.broadcastFileUri = fileURI;
	}
	public Uri getBroadcastFileUri()
	{
		return this.broadcastFileUri;
	}

	public int getFileProgress(){
		return this.fileProgress;
	}
	public void setFileProgress(int progress){
		this.fileProgress = progress;
	}
	public static EventComments fromCursor(Cursor cursor) {
		Jid jid;
		try {
			String value = cursor.getString(cursor.getColumnIndex(COUNTERPART));
			if (value != null) {
				jid = Jid.fromString(value, true);
			} else {
				jid = null;
			}
		} catch (InvalidJidException e) {
			jid = null;
		}
		Jid trueCounterpart;
		try {
			String value = cursor.getString(cursor.getColumnIndex(TRUE_COUNTERPART));
			if (value != null) {
				trueCounterpart = Jid.fromString(value, true);
			} else {
				trueCounterpart = null;
			}
		} catch (InvalidJidException e) {
			trueCounterpart = null;
		}
		return new EventComments(cursor.getString(cursor.getColumnIndex(UUID)),
				cursor.getString(cursor.getColumnIndex(CONVERSATION)),
				jid,
				trueCounterpart,
				cursor.getString(cursor.getColumnIndex(BODY)),
				cursor.getLong(cursor.getColumnIndex(TIME_SENT)),
				cursor.getInt(cursor.getColumnIndex(ENCRYPTION)),
				cursor.getInt(cursor.getColumnIndex(STATUS)),
				cursor.getInt(cursor.getColumnIndex(TYPE)),
				cursor.getString(cursor.getColumnIndex(REMOTE_MSG_ID)),
				cursor.getString(cursor.getColumnIndex(RELATIVE_FILE_PATH)),
				cursor.getString(cursor.getColumnIndex(SERVER_MSG_ID)));
	}




	@Override
	public ContentValues getContentValues() {
		ContentValues values = new ContentValues();
		values.put(UUID, uuid);
		values.put(CONVERSATION, conversationUuid);
		if (counterpart == null) {
			values.putNull(COUNTERPART);
		} else {
			values.put(COUNTERPART, counterpart.toString());
		}
		if (trueCounterpart == null) {
			values.putNull(TRUE_COUNTERPART);
		} else {
			values.put(TRUE_COUNTERPART, trueCounterpart.toString());
		}
		values.put(BODY, body);
		values.put(TIME_SENT, timeSent);
		values.put(ENCRYPTION, encryption);
		values.put(STATUS, status);
		values.put(TYPE, type);
		values.put(REMOTE_MSG_ID, remoteMsgId);
		values.put(RELATIVE_FILE_PATH, relativeFilePath);
		values.put(SERVER_MSG_ID, serverMsgId);
		return values;
	}


}*/