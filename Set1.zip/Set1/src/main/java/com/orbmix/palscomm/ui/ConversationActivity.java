package com.orbmix.palscomm.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.widget.SlidingPaneLayout;
import android.support.v4.widget.SlidingPaneLayout.PanelSlideListener;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.activity.ShareLocationActivity;
import com.orbmix.palscomm.entities.Blockable;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.Message;
import com.orbmix.palscomm.services.XmppConnectionService.OnAccountUpdate;
import com.orbmix.palscomm.services.XmppConnectionService.OnConversationUpdate;
import com.orbmix.palscomm.services.XmppConnectionService.OnRosterUpdate;
import com.orbmix.palscomm.ui.adapter.ConversationAdapter;
import com.orbmix.palscomm.utils.ConnectionDetector;
import com.orbmix.palscomm.utils.ExceptionHelper;
import com.orbmix.palscomm.xmpp.OnUpdateBlocklist;

import net.java.otr4j.session.SessionStatus;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import de.timroes.android.listview.EnhancedListView;

public class ConversationActivity extends XmppActivity
	implements OnAccountUpdate, OnConversationUpdate, OnRosterUpdate, OnUpdateBlocklist {

	public static final String ACTION_DOWNLOAD = "com.orbmix.palscomm.action.DOWNLOAD";

	public static final String VIEW_CONVERSATION = "viewConversation";
	public static final String CONVERSATION = "conversationUuid";
	public static final String MESSAGE = "messageUuid";
	public static final String TEXT = "text";
	public static final String NICK = "nick";

	public static final int REQUEST_SEND_MESSAGE = 0x0201;
	public static final int REQUEST_DECRYPT_PGP = 0x0202;
	public static final int REQUEST_ENCRYPT_MESSAGE = 0x0207;
	public static final int ATTACHMENT_CHOICE_CHOOSE_IMAGE = 0x0301;
	public static final int ATTACHMENT_CHOICE_TAKE_PHOTO = 0x0302;
	public static final int ATTACHMENT_CHOICE_CHOOSE_FILE = 0x0303;
	public static final int ATTACHMENT_CHOICE_RECORD_VOICE = 0x0304;
	public static final int ATTACHMENT_CHOICE_LOCATION = 0x0305;
	public static final int ATTACHMENT_SHARE_CONTACT = 0x0306;
	private static final String STATE_OPEN_CONVERSATION = "state_open_conversation";
	private static final String STATE_PANEL_OPEN = "state_panel_open";
	private static final String STATE_PENDING_URI = "state_pending_uri";

	private static final int REQUEST_CODE_PICK_CONTACTS = 147852;

	private String mOpenConverstaion = null;
	private boolean mPanelOpen = true;
    private boolean mConfirmAttchment = false;
	final private List<Uri> mPendingImageUris = new ArrayList<>();
	final private List<Uri> mPendingFileUris = new ArrayList<>();
	private Uri mPendingGeoUri = null;
	private Uri mPendingContactUris = null;

	private View mContentView;

	private List<Conversation> conversationList = new ArrayList<>();

	private Conversation swipedConversation = null;
	private Conversation mSelectedConversation = null;
	private EnhancedListView listView;
	private ConversationFragment mConversationFragment;

	private ArrayAdapter<Conversation> listAdapter;

	private Toast prepareFileToast;

	private boolean mActivityPaused = false;
	private boolean mRedirected = true;

	public Conversation getSelectedConversation() {
		return this.mSelectedConversation;
	}

	public void setSelectedConversation(Conversation conversation) {
		this.mSelectedConversation = conversation;
	}

	public void showConversationsOverview() {
		if (mContentView instanceof SlidingPaneLayout) {
			SlidingPaneLayout mSlidingPaneLayout = (SlidingPaneLayout) mContentView;
			mSlidingPaneLayout.openPane();
		}
	}

	@Override
	protected String getShareableUri() {
		Conversation conversation = getSelectedConversation();
		if (conversation != null) {
			return conversation.getAccount().getShareableUri();
		} else {
			return "";
		}
	}

	public void hideConversationsOverview() {
		if (mContentView instanceof SlidingPaneLayout) {
			SlidingPaneLayout mSlidingPaneLayout = (SlidingPaneLayout) mContentView;
			mSlidingPaneLayout.closePane();

			mConversationFragment.mRevealView.setVisibility(View.INVISIBLE);
			mConversationFragment.hidden = true;
		}
	}

	public boolean isConversationsOverviewHideable() {
		if (mContentView instanceof SlidingPaneLayout) {
			SlidingPaneLayout mSlidingPaneLayout = (SlidingPaneLayout) mContentView;
			return mSlidingPaneLayout.isSlideable();
		} else {
			return false;
		}
	}

	public boolean isConversationsOverviewVisable() {
		if (mContentView instanceof SlidingPaneLayout) {
			SlidingPaneLayout mSlidingPaneLayout = (SlidingPaneLayout) mContentView;
			return mSlidingPaneLayout.isOpen();
		} else {
			return true;
		}
	}

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState != null) {
			mOpenConverstaion = savedInstanceState.getString(STATE_OPEN_CONVERSATION, null);
			mPanelOpen = savedInstanceState.getBoolean(STATE_PANEL_OPEN, true);
			String pending = savedInstanceState.getString(STATE_PENDING_URI, null);
			if (pending != null) {
				mPendingImageUris.clear();
				mPendingImageUris.add(Uri.parse(pending));
			}
		}

		setContentView(R.layout.fragment_conversations_overview);

		this.mConversationFragment = new ConversationFragment();

		FragmentTransaction transaction = getFragmentManager().beginTransaction();
		transaction.replace(R.id.selected_conversation, this.mConversationFragment, "conversation");
		transaction.commit();

		listView = (EnhancedListView) findViewById(R.id.list);
        this.listAdapter = new ConversationAdapter(this, conversationList);
        listView.setAdapter(this.listAdapter);

		if (getActionBar() != null) {
			getActionBar().setDisplayHomeAsUpEnabled(false);
			getActionBar().setHomeButtonEnabled(false);
		}

		listView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View clickedView,
                                    int position, long arg3) {
				/*Log.i("conversationActivity", "setonitemclickListener() ---position --"+position+ "---arg0---"+arg0+"---arg3"+
				arg3+"---clickedview---"+clickedView);*/
                if(!isConversationsOverviewVisable())
                    return;
//                System.out.println("Hello Jose:::onCreate ConversationActivity" + conversationList.get(position).getContact().getJid().toBareJid().toString());
                try {
                    if (conversationList.get(position).getContact().getJid().toBareJid().toString().contains("NEW_")) {
                        System.out.println("Hell");
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", conversationList.get(position).getContact().getJid().toBareJid().toString().split("@")[0], null)));
                    } else {
                        hideConversationsOverview();
                        if (getSelectedConversation() != conversationList.get(position)) {
                            if (conversationList.get(position).getContact().getJid().toBareJid().toString().contains("_ev_")) {
                                mConversationFragment.changeLayoutforEvents();
                            } else {
                                mConversationFragment.resizeLayoutforOthers();
                            }
                            setSelectedConversation(conversationList.get(position));
                            ConversationActivity.this.mConversationFragment.reInit(getSelectedConversation());
                        }


                        openConversation();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

		listView.setDismissCallback(new EnhancedListView.OnDismissCallback() {

			@Override
			public EnhancedListView.Undoable onDismiss(final EnhancedListView enhancedListView, final int position) {

//				Log.i("conversationActivity", "setDismissCallback() ---enhancedlistview --"+enhancedListView+ "---position---"+position);

				final int index = listView.getFirstVisiblePosition();
				View v = listView.getChildAt(0);
				final int top = (v == null) ? 0 : (v.getTop() - listView.getPaddingTop());

                try {
                    swipedConversation = listAdapter.getItem(position);
                } catch (IndexOutOfBoundsException e) {
                    return null;
                }
				//swipedConversation = listAdapter.getItem(position);
				listAdapter.remove(swipedConversation);
				swipedConversation.markRead();
				xmppConnectionService.getNotificationService().clear(swipedConversation);

				final boolean formerlySelected = (getSelectedConversation() == swipedConversation);
				if (position == 0 && listAdapter.getCount() == 0) {
					endConversation(swipedConversation, false, true);
					return null;
				} else if (formerlySelected) {
					setSelectedConversation(listAdapter.getItem(0));
					ConversationActivity.this.mConversationFragment
							.reInit(getSelectedConversation());
				}

				return new EnhancedListView.Undoable() {

					@Override
					public void undo() {
						listAdapter.insert(swipedConversation, position);
						if (formerlySelected) {
							setSelectedConversation(swipedConversation);
							ConversationActivity.this.mConversationFragment
									.reInit(getSelectedConversation());
						}
						swipedConversation = null;

						listView.setSelectionFromTop(index + (listView.getChildCount() < position ? 1 : 0), top);
					}

					@Override
					public void discard() {
						if (!swipedConversation.isRead()
								&& swipedConversation.getMode() == Conversation.MODE_SINGLE) {
							swipedConversation = null;
							return;
						}
						endConversation(swipedConversation, false, false);
						swipedConversation = null;
					}

					@Override
					public String getTitle() {
						if (swipedConversation.getMode() == Conversation.MODE_MULTI) {
							return getResources().getString(R.string.title_undo_swipe_out_muc);
						} else {
							return getResources().getString(R.string.title_undo_swipe_out_conversation);
						}
					}
				};
			}
		});
		listView.enableSwipeToDismiss();
		listView.setSwipingLayout(R.id.swipeable_item);
		listView.setUndoStyle(EnhancedListView.UndoStyle.SINGLE_POPUP);
		listView.setUndoHideDelay(5000);
		listView.setRequireTouchBeforeDismiss(false);

		mContentView = findViewById(R.id.content_view_spl);
		if (mContentView == null) {
			mContentView = findViewById(R.id.content_view_ll);
		}
		if (mContentView instanceof SlidingPaneLayout) {
			SlidingPaneLayout mSlidingPaneLayout = (SlidingPaneLayout) mContentView;
			mSlidingPaneLayout.setParallaxDistance(150);
			mSlidingPaneLayout
				.setShadowResource(R.drawable.es_slidingpane_shadow);
			mSlidingPaneLayout.setSliderFadeColor(0);
			mSlidingPaneLayout.setPanelSlideListener(new PanelSlideListener() {

				@Override
				public void onPanelOpened(View arg0) {
					updateActionBarTitle();
					invalidateOptionsMenu();
					hideKeyboard();
					if (xmppConnectionServiceBound) {
						xmppConnectionService.getNotificationService()
							.setOpenConversation(null);
					}
					closeContextMenu();
				}

				@Override
				public void onPanelClosed(View arg0) {
					listView.discardUndo();
					openConversation();
				}

				@Override
				public void onPanelSlide(View arg0, float arg1) {
					// TODO Auto-generated method stub

				}
			});
		}
	}

	public int getPixel(int dp) {
		DisplayMetrics metrics = getResources().getDisplayMetrics();
		return ((int) (dp * metrics.density));
    }



    @Override
	public void switchToConversation(Conversation conversation) {
//		Log.i("conversationActivity","switchToConversation");
		setSelectedConversation(conversation);
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				ConversationActivity.this.mConversationFragment.reInit(getSelectedConversation());
				openConversation();
			}
		});
	}

	private void updateActionBarTitle() {
		updateActionBarTitle(isConversationsOverviewHideable() && !isConversationsOverviewVisable());
	}

	private void updateActionBarTitle(boolean titleShouldBeName) {
		final ActionBar ab = getActionBar();
		final Conversation conversation = getSelectedConversation();
		if (ab != null) {
			if (titleShouldBeName && conversation != null) {
				ab.setDisplayHomeAsUpEnabled(true);
				ab.setHomeButtonEnabled(true);
				if (conversation.getMode() == Conversation.MODE_SINGLE || useSubjectToIdentifyConference()) {
					ab.setTitle(conversation.getName().toString().replace("_bc_", "").replace("_ev_",""));
				} else {
					ab.setTitle(conversation.getJid().toBareJid().toString());
				}
			} else {
				ab.setDisplayHomeAsUpEnabled(false);
				ab.setHomeButtonEnabled(false);
				ab.setTitle(R.string.app_name);
			}
		}
	}

	private void openConversation() {
		this.updateActionBarTitle();
		this.invalidateOptionsMenu();
		if (xmppConnectionServiceBound) {
			final Conversation conversation = getSelectedConversation();
			xmppConnectionService.getNotificationService().setOpenConversation(conversation);
			sendReadMarkerIfNecessary(conversation);
		}
//        Log.i("NUll", "here null pointer exception when contact list start conversation");
		listAdapter.notifyDataSetChanged();
	}

	public void sendReadMarkerIfNecessary(final Conversation conversation) {
		if (!mActivityPaused && conversation != null) {
			if (!conversation.isRead()) {
				xmppConnectionService.sendReadMarker(conversation);
			} else {
				xmppConnectionService.markRead(conversation);
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.conversations, menu);

		final MenuItem menuSecure = menu.findItem(R.id.action_security);
		final MenuItem menuArchive = menu.findItem(R.id.action_archive);
		final MenuItem menuMucDetails = menu.findItem(R.id.action_muc_details);
		final MenuItem menuContactDetails = menu.findItem(R.id.action_contact_details);
		final MenuItem menuAttach = menu.findItem(R.id.action_attach_file);
		final MenuItem menuClearHistory = menu.findItem(R.id.action_clear_history);
		final MenuItem menuAdd = menu.findItem(R.id.action_add);
		final MenuItem menuInviteContact = menu.findItem(R.id.action_invite);
		final MenuItem menuMute = menu.findItem(R.id.action_mute);
		final MenuItem menuUnmute = menu.findItem(R.id.action_unmute);
		final MenuItem menublocklist = menu.findItem(R.id.action_show_block_list);
		final MenuItem manuAds = menu.findItem(R.id.action_advertisement);
        final MenuItem menumanageaccount = menu.findItem(R.id.action_accounts);
        final MenuItem menuupdate = menu.findItem(R.id.action_updates);
		final MenuItem menuEventgroup = menu.findItem(R.id.action_eventgroups);

		if (isConversationsOverviewVisable() && isConversationsOverviewHideable()) {
			menuArchive.setVisible(false);
			menuMucDetails.setVisible(false);
			menuContactDetails.setVisible(false);
			menuSecure.setVisible(false);
			menuInviteContact.setVisible(false);
			menuAttach.setVisible(false);
			menuClearHistory.setVisible(false);
			menuMute.setVisible(false);
			menuUnmute.setVisible(false);
		} else {
			menuAdd.setVisible(!isConversationsOverviewHideable());
			if (this.getSelectedConversation() != null) {
				if (this.getSelectedConversation().getLatestMessage()
						.getEncryption() != Message.ENCRYPTION_NONE) {
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
						menuSecure.setIcon(R.drawable.ic_lock_white_24dp);
					} else {
						menuSecure.setIcon(R.drawable.ic_action_secure);
					}
				}
				// Added by Elumalai for Broadcast menu
				if (this.getSelectedConversation().getMode() == Conversation.MODE_MULTI
                && this.getSelectedConversation().getJid().toBareJid().toString().contains("_bc_")){
                    menuContactDetails.setVisible(false);
                    menuMucDetails.setVisible(true);
                    menuupdate.setVisible(true);
                    menublocklist.setVisible(false);
                    manuAds.setVisible(false);
                    menumanageaccount.setVisible(false);
                    menuupdate.setVisible(false);
                    menuMute.setVisible(false);
                    menuEventgroup.setVisible(true);
				} else if(this.getSelectedConversation().getMode() == Conversation.MODE_MULTI ) {
                    menuContactDetails.setVisible(false);
                    menuMucDetails.setVisible(true);
                    menuupdate.setVisible(true);
                    menublocklist.setVisible(false);
                    manuAds.setVisible(false);
                    menumanageaccount.setVisible(false);
                    menuupdate.setVisible(false);
                    menuAttach.setVisible(true);
                    menuEventgroup.setVisible(false);
                    menuInviteContact.setVisible(getSelectedConversation().getMucOptions().canInvite());
                }else {

					menuMucDetails.setVisible(false);
				}
				if (this.getSelectedConversation().isMuted()) {
					menuMute.setVisible(false);
				} else {
					menuUnmute.setVisible(false);
				}
				// Added By Elumalai for single conversation menu
				if (this.getSelectedConversation().getMode() == Conversation.MODE_SINGLE){
                    menumanageaccount.setVisible(false);
					menuContactDetails.setVisible(true);
					manuAds.setVisible(false);
                    menuInviteContact.setVisible(false);
                    menublocklist.setVisible(true);
					menuEventgroup.setVisible(false);
                    menuupdate.setVisible(false);
					menuAdd.setVisible(false);
				}
			}
		}


		//setMenuBackground();
		return true;
	}

	private void selectPresenceToAttachFile(final int attachmentChoice, final int encryption) {
		final OnPresenceSelected callback = new OnPresenceSelected() {

			@Override
			public void onPresenceSelected() {
				Intent intent = new Intent();
				Intent sharelocation = new Intent();
				Intent sharecontact = new Intent();

				boolean chooser = false;
				String fallbackPackageId = null;
				switch (attachmentChoice) {
					case ATTACHMENT_CHOICE_CHOOSE_IMAGE:
						intent.setAction(Intent.ACTION_GET_CONTENT);
						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
							intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
						}
						intent.setType("image/*");
						chooser = true;
						break;
					case ATTACHMENT_CHOICE_TAKE_PHOTO:
						Uri uri = xmppConnectionService.getFileBackend().getTakePhotoUri();
						intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
						intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
						mPendingImageUris.clear();
						mPendingImageUris.add(uri);
						break;
					case ATTACHMENT_CHOICE_CHOOSE_FILE:
						chooser = true;
						intent.setType("*/*");
						intent.addCategory(Intent.CATEGORY_OPENABLE);
						intent.setAction(Intent.ACTION_GET_CONTENT);
						break;
					case ATTACHMENT_CHOICE_RECORD_VOICE:
						intent.setAction(MediaStore.Audio.Media.RECORD_SOUND_ACTION);
						fallbackPackageId = "eu.siacs.conversations.voicerecorder";
						break;
					// Changes made by Elumalai for Sharing Location
					case ATTACHMENT_CHOICE_LOCATION:
//						intent.setAction("eu.siacs.conversations.location.request");
						sharelocation = new Intent(getBaseContext(), ShareLocationActivity.class);
						fallbackPackageId = "sharelocation";
						break;
					//Added by Elumalai for Sharing Contacts
					case ATTACHMENT_SHARE_CONTACT:
						sharecontact = new Intent(getBaseContext(), ShareContact.class);
						fallbackPackageId = "sharecontact";
						break;
				}
				if (intent.resolveActivity(getPackageManager()) != null) {
					if (chooser) {
						intent.setAction(Intent.ACTION_GET_CONTENT);
						startActivityForResult(
								Intent.createChooser(intent, getString(R.string.perform_action_with)),
								attachmentChoice);
					} else {
                        if(fallbackPackageId == "sharelocation"){
							startActivityForResult(sharelocation, attachmentChoice);
						}else  if(fallbackPackageId == "sharecontact"){
							startActivityForResult(sharecontact, REQUEST_CODE_PICK_CONTACTS);
						}else {
							startActivityForResult(intent, attachmentChoice);
						}
					}
				} else if (fallbackPackageId != null ) {
					if(fallbackPackageId == "sharelocation") {
						startActivityForResult(sharelocation, attachmentChoice);
					}else {
						startActivityForResult(sharecontact, REQUEST_CODE_PICK_CONTACTS);
					}
				}
			}
		};
		if (attachmentChoice == ATTACHMENT_CHOICE_LOCATION && encryption != Message.ENCRYPTION_OTR) {
			getSelectedConversation().setNextCounterpart(null);
			callback.onPresenceSelected();
		} else {
			selectPresence(getSelectedConversation(), callback);
		}
	}

	private Intent getInstallApkIntent(final String packageId) {
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("market://details?id="+packageId));
		if (intent.resolveActivity(getPackageManager()) != null) {
			return intent;
		} else {
			intent.setData(Uri.parse("http://play.google.com/store/apps/details?id=" + packageId));
			return intent;
		}
	}

	public void attachFile(final int attachmentChoice) {
		switch (attachmentChoice) {
			case ATTACHMENT_CHOICE_LOCATION:
				getPreferences().edit().putString("recently_used_quick_action","location").apply();
				break;
			case ATTACHMENT_CHOICE_RECORD_VOICE:
				getPreferences().edit().putString("recently_used_quick_action","voice").apply();
				break;
			case ATTACHMENT_CHOICE_TAKE_PHOTO:
				getPreferences().edit().putString("recently_used_quick_action","photo").apply();
				break;
            case ATTACHMENT_CHOICE_CHOOSE_IMAGE:
                getPreferences().edit().putString("recently_used_quick_action","picture").apply();
                break;
			case ATTACHMENT_SHARE_CONTACT:
				getPreferences().edit().putString("recently_used_quick_action","contact").apply();
				break;
		}
		final Conversation conversation = getSelectedConversation();
		final int encryption = conversation.getNextEncryption(forceEncryption());
		if (encryption == Message.ENCRYPTION_PGP) {
			if (hasPgp()) {
				if (conversation.getContact().getPgpKeyId() != 0) {
					xmppConnectionService.getPgpEngine().hasKey(
							conversation.getContact(),
							new UiCallback<Contact>() {

								@Override
								public void userInputRequried(PendingIntent pi,
										Contact contact) {
									ConversationActivity.this.runIntent(pi,attachmentChoice);
								}

								@Override
								public void success(Contact contact) {
									selectPresenceToAttachFile(attachmentChoice,encryption);
								}

								@Override
								public void error(int error, Contact contact) {
									displayErrorDialog(error);
								}
							});
				} else {
					final ConversationFragment fragment = (ConversationFragment) getFragmentManager()
						.findFragmentByTag("conversation");
					if (fragment != null) {
						fragment.showNoPGPKeyDialog(false,
								new OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										conversation
											.setNextEncryption(Message.ENCRYPTION_NONE);
										xmppConnectionService.databaseBackend
											.updateConversation(conversation);
										selectPresenceToAttachFile(attachmentChoice,Message.ENCRYPTION_NONE);
									}
								});
					}
				}
			} else {
				showInstallPgpDialog();
			}
		} else {
			selectPresenceToAttachFile(attachmentChoice, encryption);
		}
	}

	@Override
	public boolean onOptionsItemSelected(final MenuItem item) {
		if (item.getItemId() == android.R.id.home) {
			showConversationsOverview();
			return true;
		} else if (item.getItemId() == R.id.action_add) {
			startActivity(new Intent(this, StartConversationActivity.class));
			return true;
		} else if (getSelectedConversation() != null) {
			switch (item.getItemId()) {
				case R.id.action_attach_file:
					ConversationActivity.this.mConversationFragment.showAttachmentDialog();
					//attachFileDialog();
					break;
				case R.id.action_archive:
					this.endConversation(getSelectedConversation());
					break;
				//block list menu is added by Elumalai
				case R.id.action_show_block_list:
					final Intent showBlocklistIntent = new Intent(this, BlocklistActivity.class);
					showBlocklistIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
					startActivity(showBlocklistIntent);
					break;

                // Added by Elumalai for advertisement
                case R.id.action_advertisement:
                    if (getPreferences().getBoolean("advertisements_indicator", true)) {
						ConnectionDetector cd;
						cd = new ConnectionDetector(getApplicationContext());
						if(cd.isConnectingToInternet()) {
							final Intent addIntent = new Intent(this, AdvertisementCategory.class);
							startActivity(addIntent);
						}
                        else {
                            showAlertDialog(ConversationActivity.this, "No Internet Connection",
                                    "You don't have internet connection.", false);
                        }
                    }
                    else{
                        Toast.makeText(ConversationActivity.this,"Enable the Advertisements settings to View Advertisements" , Toast.LENGTH_LONG).show();
                    }
                    break;
                case R.id.action_updates:
                    if (getPreferences().getBoolean("view_updates", true)) {
                        final Intent updatesIntent = new Intent(this, UpdatesActivity.class);
                        updatesIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
                        startActivity(updatesIntent);
                    }
                    else{
                        Toast.makeText(ConversationActivity.this,"Enable the Updates from Privacy Settings to View Updates" , Toast.LENGTH_LONG).show();
                    }
                    break;
				case R.id.action_contact_details:
					Log.i("contactdetails","case contact details");
					switchToContactDetails(getSelectedConversation().getContact());
					break;
				case R.id.action_muc_details:
					Intent intent = new Intent(this,
							ConferenceDetailsActivity.class);
					intent.setAction(ConferenceDetailsActivity.ACTION_VIEW_MUC);
					intent.putExtra("uuid", getSelectedConversation().getUuid());
                    startActivityForResult(intent,9999);
					break;
				case R.id.action_invite:
					inviteToConversation(getSelectedConversation());
					break;
				case R.id.action_security:
					selectEncryptionDialog(getSelectedConversation());
					break;
				case R.id.action_clear_history:
					clearHistoryDialog(getSelectedConversation());
					break;
				case R.id.action_mute:
					muteConversationDialog(getSelectedConversation());
					break;
				case R.id.action_unmute:
					unmuteConversation(getSelectedConversation());
					break;
				case R.id.action_block:
					BlockContactDialog.show(this, xmppConnectionService, getSelectedConversation());
					break;
				case R.id.action_unblock:
					BlockContactDialog.show(this, xmppConnectionService, getSelectedConversation());
					break;
				// Added by Elumalai for Event Group busy icon
				case R.id.action_eventgroups:
                    item.setActionView(new ProgressBar(this));
                    item.getActionView().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            final Intent intent1 = new Intent(getBaseContext(), StartEventConversationActivity.class);
							startActivity(intent1);
                        }
                    }, 1000);
                    return true;
                default:
                    break;
			}
			return super.onOptionsItemSelected(item);
		} else {
			return super.onOptionsItemSelected(item);
		}
	}

	public void endConversation(Conversation conversation) {
		endConversation(conversation, true, true);
	}

	public void endConversation(Conversation conversation, boolean showOverview, boolean reinit) {
		if (showOverview) {
			showConversationsOverview();
		}
		xmppConnectionService.archiveConversation(conversation);
		if (reinit) {
			if (conversationList.size() > 0) {
				setSelectedConversation(conversationList.get(0));
				this.mConversationFragment.reInit(getSelectedConversation());
			} else {
				setSelectedConversation(null);
			}
		}
	}

	@SuppressLint("InflateParams")
	protected void clearHistoryDialog(final Conversation conversation) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(getString(R.string.clear_conversation_history));
		View dialogView = getLayoutInflater().inflate(
				R.layout.dialog_clear_history, null);
		final CheckBox endConversationCheckBox = (CheckBox) dialogView
			.findViewById(R.id.end_conversation_checkbox);
		builder.setView(dialogView);
		builder.setNegativeButton(getString(R.string.cancel), null);
		builder.setPositiveButton(getString(R.string.delete_messages),
				new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						ConversationActivity.this.xmppConnectionService.clearConversationHistory(conversation);
						if (endConversationCheckBox.isChecked()) {
							endConversation(conversation);
						} else {
							updateConversationList();
							ConversationActivity.this.mConversationFragment.updateMessages();
						}
					}
				});
		builder.create().show();
	}

	/*protected boolean showAttachmentDialog(){

		// attachment icon click event
		// finding X and Y co-ordinates
		int cx = (mRevealView.getLeft() + mRevealView.getRight());
		int cy = (mRevealView.getTop());

		// to find  radius when icon is tapped for showing layout
		int startradius = 0;
		int endradius = Math.max(mRevealView.getWidth(), mRevealView.getHeight());


		// performing circular reveal when icon will be tapped
		Animator animator = ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, startradius, endradius);
		animator.setInterpolator(new AccelerateDecelerateInterpolator());
		animator.setDuration(400);

		//reverse animation
		// to find radius when icon is tapped again for hiding layout


		//  starting radius will be the radius or the extent to which circular reveal animation is to be shown
		int reverse_startradius = Math.max(mRevealView.getWidth(), mRevealView.getHeight());
		//endradius will be zero
		int reverse_endradius = 0;


		// performing circular reveal for reverse animation
		Animator animate = ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, reverse_startradius, reverse_endradius);


		if (hidden) {

			// to show the layout when icon is tapped
			mRevealView.setVisibility(View.VISIBLE);
			animator.start();
			hidden = false;
		} else {

			mRevealView.setVisibility(View.VISIBLE);

			// to hide layout on animation end
			animate.addListener(new AnimatorListenerAdapter() {

				@Override
				public void onAnimationEnd(Animator animation) {
					super.onAnimationEnd(animation);
					mRevealView.setVisibility(View.INVISIBLE);
					hidden = true;
				}
			});
			animate.start();
		}

		return true;
	}*/


	public void attachFileDialog() {
		View menuAttachFile = findViewById(R.id.action_attach_file);
		if (menuAttachFile == null) {
			return;
		}
		PopupMenu attachFilePopup = new PopupMenu(this, menuAttachFile);
		attachFilePopup.inflate(R.menu.attachment_choices);
		if (new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION).resolveActivity(getPackageManager()) == null) {
			attachFilePopup.getMenu().findItem(R.id.attach_record_voice).setVisible(false);
		}
	/*	if (new Intent("eu.siacs.conversations.location.request").resolveActivity(getPackageManager()) == null) {
			attachFilePopup.getMenu().findItem(R.id.attach_location).setVisible(true);
		}*/
//		Log.i("locationsharing", "RECORD_SOUND_ACTION package Name :" + new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION).resolveActivity(getPackageManager()));
		attachFilePopup.setOnMenuItemClickListener(new OnMenuItemClickListener() {

			@Override
			public boolean onMenuItemClick(MenuItem item) {

				switch (item.getItemId()) {
					case R.id.attach_choose_picture:
						attachFile(ATTACHMENT_CHOICE_CHOOSE_IMAGE);
						break;
					case R.id.attach_take_picture:
						attachFile(ATTACHMENT_CHOICE_TAKE_PHOTO);
						break;
					case R.id.attach_choose_file:
						attachFile(ATTACHMENT_CHOICE_CHOOSE_FILE);
						break;
					case R.id.attach_record_voice:
						attachFile(ATTACHMENT_CHOICE_RECORD_VOICE);
						break;
					case R.id.attach_location:
						attachFile(ATTACHMENT_CHOICE_LOCATION);
						break;
					// Added by Elumalai for Sharing Contacts
					case R.id.attach_share_contect:
						attachFile(ATTACHMENT_SHARE_CONTACT);
						break;
				}
				return false;
			}
		});
		attachFilePopup.show();
	}

	public void verifyOtrSessionDialog(final Conversation conversation, View view) {
		if (!conversation.hasValidOtrSession() || conversation.getOtrSession().getSessionStatus() != SessionStatus.ENCRYPTED) {
			Toast.makeText(this, R.string.otr_session_not_started, Toast.LENGTH_LONG).show();
			return;
		}
		if (view == null) {
			return;
		}
		PopupMenu popup = new PopupMenu(this, view);
		popup.inflate(R.menu.verification_choices);
		popup.setOnMenuItemClickListener(new OnMenuItemClickListener() {
			@Override
			public boolean onMenuItemClick(MenuItem menuItem) {
				Intent intent = new Intent(ConversationActivity.this, VerifyOTRActivity.class);
				intent.setAction(VerifyOTRActivity.ACTION_VERIFY_CONTACT);
				intent.putExtra("contact", conversation.getContact().getJid().toBareJid().toString());
				intent.putExtra("account", conversation.getAccount().getJid().toBareJid().toString());
				switch (menuItem.getItemId()) {
					case R.id.scan_fingerprint:
						intent.putExtra("mode", VerifyOTRActivity.MODE_SCAN_FINGERPRINT);
						break;
					case R.id.ask_question:
						intent.putExtra("mode", VerifyOTRActivity.MODE_ASK_QUESTION);
						break;
					case R.id.manual_verification:
						intent.putExtra("mode", VerifyOTRActivity.MODE_MANUAL_VERIFICATION);
						break;
				}
				startActivity(intent);
				return true;
			}
		});
		popup.show();
	}

	protected void selectEncryptionDialog(final Conversation conversation) {
		View menuItemView = findViewById(R.id.action_security);
		if (menuItemView == null) {
			return;
		}
		PopupMenu popup = new PopupMenu(this, menuItemView);
		final ConversationFragment fragment = (ConversationFragment) getFragmentManager()
			.findFragmentByTag("conversation");
		if (fragment != null) {
			popup.setOnMenuItemClickListener(new OnMenuItemClickListener() {

				@Override
				public boolean onMenuItemClick(MenuItem item) {
					switch (item.getItemId()) {
						case R.id.encryption_choice_none:
							conversation.setNextEncryption(Message.ENCRYPTION_NONE);
							item.setChecked(true);
							break;
						case R.id.encryption_choice_otr:
							conversation.setNextEncryption(Message.ENCRYPTION_OTR);
							item.setChecked(true);
							break;
						case R.id.encryption_choice_pgp:
							if (hasPgp()) {
								if (conversation.getAccount().getKeys()
										.has("pgp_signature")) {
									conversation
										.setNextEncryption(Message.ENCRYPTION_PGP);
									item.setChecked(true);
								} else {
									announcePgp(conversation.getAccount(),
											conversation);
								}
							} else {
								showInstallPgpDialog();
							}
							break;
						default:
							conversation.setNextEncryption(Message.ENCRYPTION_NONE);
							break;
					}
					xmppConnectionService.databaseBackend
						.updateConversation(conversation);
					fragment.updateChatMsgHint();
					return true;
				}
			});
			popup.inflate(R.menu.encryption_choices);
			MenuItem otr = popup.getMenu().findItem(R.id.encryption_choice_otr);
			MenuItem none = popup.getMenu().findItem(
					R.id.encryption_choice_none);
			if (conversation.getMode() == Conversation.MODE_MULTI) {
				otr.setEnabled(false);
			} else {
				if (forceEncryption()) {
					none.setVisible(false);
				}
			}
			switch (conversation.getNextEncryption(forceEncryption())) {
				case Message.ENCRYPTION_NONE:
					none.setChecked(true);
					break;
				case Message.ENCRYPTION_OTR:
					otr.setChecked(true);
					break;
				case Message.ENCRYPTION_PGP:
					popup.getMenu().findItem(R.id.encryption_choice_pgp)
						.setChecked(true);
					break;
				default:
					popup.getMenu().findItem(R.id.encryption_choice_none)
						.setChecked(true);
					break;
			}
			popup.show();
		}
	}

	protected void muteConversationDialog(final Conversation conversation) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(R.string.disable_notifications);
		final int[] durations = getResources().getIntArray(
				R.array.mute_options_durations);
		builder.setItems(R.array.mute_options_descriptions,
				new OnClickListener() {

					@Override
					public void onClick(final DialogInterface dialog, final int which) {
						final long till;
						if (durations[which] == -1) {
							till = Long.MAX_VALUE;
						} else {
							till = System.currentTimeMillis() + (durations[which] * 1000);
						}
						conversation.setMutedTill(till);
						ConversationActivity.this.xmppConnectionService.databaseBackend
								.updateConversation(conversation);
						updateConversationList();
						ConversationActivity.this.mConversationFragment.updateMessages();
						invalidateOptionsMenu();
					}
				});
		builder.create().show();
	}

	public void unmuteConversation(final Conversation conversation) {
		conversation.setMutedTill(0);
		this.xmppConnectionService.databaseBackend.updateConversation(conversation);
		updateConversationList();
		ConversationActivity.this.mConversationFragment.updateMessages();
		invalidateOptionsMenu();
	}

	@Override
	public void onBackPressed() {
		if (!isConversationsOverviewVisable()) {
			mConversationFragment.mRevealView.setVisibility(View.INVISIBLE);
			mConversationFragment.hidden = true;
			showConversationsOverview();
		} else {
			moveTaskToBack(true);
		}
	}

	@Override
	protected void onNewIntent(final Intent intent) {
		if (xmppConnectionServiceBound) {
			if (intent != null && VIEW_CONVERSATION.equals(intent.getType())) {
				handleViewConversationIntent(intent);
			}
		} else {
			setIntent(intent);
		}
	}

	@Override
	public void onStart() {
		super.onStart();
        System.out.println("Onstart called.");
		this.mRedirected = false;
		if (this.xmppConnectionServiceBound) {
			this.onBackendConnected();
		}
		if (conversationList.size() >= 1) {
			this.onConversationUpdate();
		}
	}

	@Override
	public void onPause() {
		listView.discardUndo();
		super.onPause();
		this.mActivityPaused = true;
		if (this.xmppConnectionServiceBound) {
			this.xmppConnectionService.getNotificationService().setIsInForeground(false);
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		final int theme = findTheme();
		final boolean usingEnterKey = usingEnterKey();
		if (this.mTheme != theme || usingEnterKey != mUsingEnterKey) {
			recreate();
		}
		this.mActivityPaused = false;
		if (this.xmppConnectionServiceBound) {
			this.xmppConnectionService.getNotificationService().setIsInForeground(true);
		}

		if (!isConversationsOverviewVisable() || !isConversationsOverviewHideable()) {
			sendReadMarkerIfNecessary(getSelectedConversation());
		}

	}

	@Override
	public void onSaveInstanceState(final Bundle savedInstanceState) {
		Conversation conversation = getSelectedConversation();
		if (conversation != null) {
			savedInstanceState.putString(STATE_OPEN_CONVERSATION,
					conversation.getUuid());
		}
		savedInstanceState.putBoolean(STATE_PANEL_OPEN,
				isConversationsOverviewVisable());
		if (this.mPendingImageUris.size() >= 1) {
			savedInstanceState.putString(STATE_PENDING_URI, this.mPendingImageUris.get(0).toString());
		}
		super.onSaveInstanceState(savedInstanceState);
	}

	@Override
	void onBackendConnected() {
		this.xmppConnectionService.getNotificationService().setIsInForeground(true);
		updateConversationList();

		if (mPendingConferenceInvite != null) {
			mPendingConferenceInvite.execute(this);
			mPendingConferenceInvite = null;
		}

		if (xmppConnectionService.getAccounts().size() == 0) {
			if (!mRedirected) {
				this.mRedirected = true;
				startActivity(new Intent(this, TermsandCondition.class));
				finish();
			}
		} else if (conversationList.size() <= 0) {
			if (!mRedirected) {
				this.mRedirected = true;
				Intent intent = new Intent(this, StartConversationActivity.class);
				intent.putExtra("init",true);
				startActivity(intent);
				finish();
			}
		} else if (getIntent() != null && VIEW_CONVERSATION.equals(getIntent().getType())) {
			handleViewConversationIntent(getIntent());
		} else if (selectConversationByUuid(mOpenConverstaion)) {
			if (mPanelOpen) {
				showConversationsOverview();
			} else {
				if (isConversationsOverviewHideable()) {
					openConversation();
				}
			}
			this.mConversationFragment.reInit(getSelectedConversation());
			mOpenConverstaion = null;
		} else if (getSelectedConversation() == null) {
			showConversationsOverview();
			mPendingImageUris.clear();
			mPendingFileUris.clear();
			mPendingGeoUri = null;
			mPendingContactUris = null;
			setSelectedConversation(conversationList.get(0));
			this.mConversationFragment.reInit(getSelectedConversation());
		}

        if(!mConfirmAttchment) {
            for (Iterator<Uri> i = mPendingImageUris.iterator(); i.hasNext(); i.remove()) {
                attachImageToConversation(getSelectedConversation(), i.next());
            }

            for (Iterator<Uri> i = mPendingFileUris.iterator(); i.hasNext(); i.remove()) {
                attachFileToConversation(getSelectedConversation(), i.next());
            }
        }
		if (mPendingGeoUri != null) {
			attachLocationToConversation(getSelectedConversation(), mPendingGeoUri);
			mPendingGeoUri = null;
		}
		if(mPendingContactUris != null){
			attachLocationToConversation(getSelectedConversation(), mPendingContactUris);
			mPendingContactUris = null;
		}
		ExceptionHelper.checkForCrash(this, this.xmppConnectionService);
		setIntent(new Intent());
	}

	private void handleViewConversationIntent(final Intent intent) {
		final String uuid = intent.getStringExtra(CONVERSATION);
		final String downloadUuid = intent.getStringExtra(MESSAGE);
		final String text = intent.getStringExtra(TEXT);
		final String nick = intent.getStringExtra(NICK);
		if (selectConversationByUuid(uuid)) {
			Bundle extras = getIntent().getExtras();
			if (extras != null) {
				if(extras.getBoolean("event"))
				{
					mConversationFragment.changeLayoutforEvents();
				}
				else
				{
					mConversationFragment.resizeLayoutforOthers();
				}
			}
			this.mConversationFragment.reInit(getSelectedConversation());
			if (nick != null) {
				this.mConversationFragment.highlightInConference(nick);
			} else {
				this.mConversationFragment.appendText(text);
			}
			hideConversationsOverview();
			openConversation();
			if (mContentView instanceof SlidingPaneLayout) {
				updateActionBarTitle(true); //fixes bug where slp isn't properly closed yet
			}
		if (downloadUuid != null) {
				final Message message = mSelectedConversation.findMessageWithFileAndUuid(downloadUuid);
				if (message != null) {
					mConversationFragment.messageListAdapter.startDownloadable(message);
				}
			}
		}
	}

	private boolean selectConversationByUuid(String uuid) {
		if (uuid == null) {
			return false;
		}
		for (Conversation aConversationList : conversationList) {
			if (aConversationList.getUuid().equals(uuid)) {
				setSelectedConversation(aConversationList);
				return true;
			}
		}
		return false;
	}

	@Override
	protected void unregisterListeners() {
		super.unregisterListeners();
		xmppConnectionService.getNotificationService().setOpenConversation(null);
	}

	@SuppressLint("NewApi")
	private static List<Uri> extractUriFromIntent(final Intent intent) {
		List<Uri> uris = new ArrayList<>();
		Uri uri = intent.getData();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2 && uri == null) {
			ClipData clipData = intent.getClipData();
			for(int i = 0; i < clipData.getItemCount(); ++i) {
				uris.add(clipData.getItemAt(i).getUri());
			}
		} else {
			uris.add(uri);
		}
		return uris;
	}

	//Function is added by Jose.
	protected void confirmFileAttachment(final ConversationActivity obj,final int requestCode,final Intent data) {
		final AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setNegativeButton(R.string.cancel, null);
		builder.setTitle(R.string.pref_accept_files);
		builder.setMessage(R.string.mgmt_account_are_you_sure);
		builder.setPositiveButton(R.string.accept, new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
                mConfirmAttchment = false;
				if (requestCode == REQUEST_DECRYPT_PGP) {
					mConversationFragment.hideSnackbar();
					mConversationFragment.updateMessages();
				} else if (requestCode == ATTACHMENT_CHOICE_CHOOSE_IMAGE) {
					mPendingImageUris.clear();
					mPendingImageUris.addAll(extractUriFromIntent(data));
					if (xmppConnectionServiceBound) {
						for(Iterator<Uri> i = mPendingImageUris.iterator(); i.hasNext(); i.remove()) {

							attachImageToConversation(getSelectedConversation(),i.next());
						}
					}
				} else if (requestCode == ATTACHMENT_CHOICE_CHOOSE_FILE || requestCode == ATTACHMENT_CHOICE_RECORD_VOICE) {
					mPendingFileUris.clear();
					mPendingFileUris.addAll(extractUriFromIntent(data));
					if (xmppConnectionServiceBound) {
						for(Iterator<Uri> i = mPendingFileUris.iterator(); i.hasNext(); i.remove()) {
							attachFileToConversation(getSelectedConversation(), i.next());
						}
					}
				} else if (requestCode == ATTACHMENT_CHOICE_TAKE_PHOTO) {
					if (mPendingImageUris.size() == 1) {
						Uri uri = mPendingImageUris.get(0);
						if (xmppConnectionServiceBound) {
							attachImageToConversation(getSelectedConversation(), uri);
							mPendingImageUris.clear();
						}
						Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
						intent.setData(uri);
						sendBroadcast(intent);
					} else {
						mPendingImageUris.clear();
					}
                  // Changes made by Elumalai for Sharing Location
				} else if (requestCode == ATTACHMENT_CHOICE_LOCATION) {
					double latitude = data.getDoubleExtra("latitude",0);
					double longitude = data.getDoubleExtra("longitude",0);
					obj.mPendingGeoUri = Uri.parse("geo:"+String.valueOf(latitude)+","+String.valueOf(longitude));
					if (xmppConnectionServiceBound) {
						attachLocationToConversation(getSelectedConversation(), mPendingGeoUri);
						obj.mPendingGeoUri = null;
					}
					//Added by Elumalai for Sharing Contact
				} else if(requestCode == REQUEST_CODE_PICK_CONTACTS){
					String contactname = data.getStringExtra("name");
					String contactnumber = data.getStringExtra("number");
					String contactemail = data.getStringExtra("email");
					String contactimage = data.getStringExtra("contactimage");
                    obj.mPendingContactUris = Uri.parse("contact:"+contactname+","+contactnumber+","+contactemail+","+contactimage);
					attachLocationToConversation(getSelectedConversation(), mPendingContactUris);
					obj.mPendingContactUris = null;
				}
			}
		});
		builder.create().show();
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			final Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
            if(requestCode == 9999) //added by Jose.
            {
                this.endConversation(getSelectedConversation());
            }
			// Added by Elumalai for contact sharing
			else if(requestCode == REQUEST_CODE_PICK_CONTACTS){
				mConfirmAttchment = true;
				confirmFileAttachment(this, requestCode, data);
			}else
			{
                mConfirmAttchment = true;
				//below code added by Jose. User has asked confirm dialog before adding files,images to the conversation.
				confirmFileAttachment(this, requestCode, data);
			}

		} else {
			mPendingImageUris.clear();
			mPendingFileUris.clear();
		}
	}

	private void attachLocationToConversation(Conversation conversation, Uri uri) {
		xmppConnectionService.attachLocationToConversation(conversation, uri, new UiCallback<Message>() {

			@Override
			public void success(Message message) {
				xmppConnectionService.sendMessage(message);
			}

			@Override
			public void error(int errorCode, Message object) {

			}

			@Override
			public void userInputRequried(PendingIntent pi, Message object) {

			}
		});
	}

	private void attachFileToConversation(Conversation conversation, Uri uri) {
        if (conversation == null) {
            			return;
        }

		prepareFileToast = Toast.makeText(getApplicationContext(),
				getText(R.string.preparing_file), Toast.LENGTH_LONG);
		prepareFileToast.show();
		xmppConnectionService.attachFileToConversation(conversation, uri, new UiCallback<Message>() {
			@Override
			public void success(Message message) {
				hidePrepareFileToast();
				xmppConnectionService.sendMessage(message);
			}

			@Override
			public void error(int errorCode, Message message) {
				displayErrorDialog(errorCode);
			}

			@Override
			public void userInputRequried(PendingIntent pi, Message message) {

			}
		});
	}

	private void attachImageToConversation(Conversation conversation, Uri uri) {
        if (conversation == null) {
            	return;
    	}
        prepareFileToast = Toast.makeText(getApplicationContext(),
				getText(R.string.preparing_image), Toast.LENGTH_LONG);
		prepareFileToast.show();
		xmppConnectionService.attachImageToConversation(conversation, uri,
				new UiCallback<Message>() {

					@Override
					public void userInputRequried(PendingIntent pi,
												  Message object) {
						hidePrepareFileToast();
					}

					@Override
					public void success(Message message) {
						xmppConnectionService.sendMessage(message);
					}

					@Override
					public void error(int error, Message message) {
						hidePrepareFileToast();
						displayErrorDialog(error);
					}
				});
	}

	private void hidePrepareFileToast() {
		if (prepareFileToast != null) {
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					prepareFileToast.cancel();
				}
			});
		}
	}

	public void updateConversationList() {
		xmppConnectionService
			.populateWithOrderedConversations(conversationList);
		if (swipedConversation != null) {
			if (swipedConversation.isRead()) {
				conversationList.remove(swipedConversation);
			} else {
				listView.discardUndo();
			}
		}
		System.out.println(listAdapter);
		if(listAdapter == null){
		}else {
			listAdapter.notifyDataSetChanged();
		}
	}

	public void runIntent(PendingIntent pi, int requestCode) {
		try {
			this.startIntentSenderForResult(pi.getIntentSender(), requestCode,
					null, 0, 0, 0);
		} catch (final SendIntentException ignored) {
		}
	}

	public void encryptTextMessage(Message message) {
		xmppConnectionService.getPgpEngine().encrypt(message,
				new UiCallback<Message>() {

					@Override
					public void userInputRequried(PendingIntent pi,
							Message message) {
						ConversationActivity.this.runIntent(pi,
								ConversationActivity.REQUEST_SEND_MESSAGE);
					}

					@Override
					public void success(Message message) {
						message.setEncryption(Message.ENCRYPTION_DECRYPTED);
						xmppConnectionService.sendMessage(message);
					}

					@Override
					public void error(int error, Message message) {
					}
				});
	}

	public boolean forceEncryption() {
		return getPreferences().getBoolean("force_encryption", false);
	}

	public boolean useSendButtonToIndicateStatus() {
		return getPreferences().getBoolean("send_button_status", true);
	}

	public boolean indicateReceived() {
		return getPreferences().getBoolean("indicate_received", true);
	}

	@Override
	protected void refreshUiReal() {
		updateConversationList();
		if (xmppConnectionService != null && xmppConnectionService.getAccounts().size() == 0) {
			if (!mRedirected) {
				this.mRedirected = true;
				startActivity(new Intent(this, EditAccountActivity.class));
				finish();
			}
		} else if (conversationList.size() == 0) {
			if (!mRedirected) {
				this.mRedirected = true;
				Intent intent = new Intent(this, StartConversationActivity.class);
				intent.putExtra("init",true);
				startActivity(intent);
				finish();
			}
		} else {
			ConversationActivity.this.mConversationFragment.updateMessages();
			updateActionBarTitle();
		}
	}

	@Override
	public void onAccountUpdate() {
		this.refreshUi();
	}

	@Override
	public void onConversationUpdate() {
		this.refreshUi();
	}

	@Override
	public void onRosterUpdate() {
		this.refreshUi();
	}

	@Override
	public void OnUpdateBlocklist(Status status) {
		this.refreshUi();
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				invalidateOptionsMenu();
			}
		});
	}

	public void unblockConversation(final Blockable conversation) {
		xmppConnectionService.sendUnblockRequest(conversation);
	}

    public boolean highlightSelectedConversations() {
        return !isConversationsOverviewHideable();// || this.conversationWasSelectedByKeyboard;
    }
	public boolean enterIsSend() {
		return getPreferences().getBoolean("enter_is_send",false);
	}
    public void showAlertDialog(Context context, String title, String message, Boolean status)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(message);

        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);


        alertDialog.setButton("OK", new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }





	protected void setMenuBackground(){
		// Log.d(TAG, "Enterting setMenuBackGround");
		getLayoutInflater().setFactory(new LayoutInflater.Factory() {
			public View onCreateView(String name, Context context, AttributeSet attrs) {
				if (name.equalsIgnoreCase("com.android.internal.view.menu.IconMenuItemView")) {
					try { // Ask our inflater to create the view
						LayoutInflater f = getLayoutInflater();
						final View view = f.createView(name, null, attrs);

                        /* The background gets refreshed each time a new item is added the options menu.
                        * So each time Android applies the default background we need to set our own
                        * background. This is done using a thread giving the background change as runnable
                        * object */
						new Handler().post(new Runnable() {
							public void run() {
								// sets the background color
								view.setBackgroundResource(R.color.background_material_dark);
								// sets the text color
								((TextView) view).setTextColor(Color.BLACK);
								// sets the text size
								((TextView) view).setTextSize(18);
							}
						});
						return view;
					} catch (InflateException e) {
					} catch (ClassNotFoundException e) {
					}
				}
				return null;
			}
		});
	}
}