package com.orbmix.palscomm.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.ui.adapter.AdvertisementsAdapter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Elumalai on 7/20/2015.
 */


public class AdvertisementActivity extends XmppActivity implements AdapterView.OnItemClickListener {

    InputStream is = null;
    private static String ads_image = null;
    private static String company_url = null;
    private static String ads_name = null;
    Bitmap bitmap;
    String cat_id;
    ListView l1;
    List<RowItem1> rowItems;
    ArrayList<HashMap<String, String>> list1 = new ArrayList<HashMap<String,String>>();

    ArrayList<String> adsname = new ArrayList<String>();
    ArrayList<String> companyurl = new ArrayList<String>();
    ArrayList<Bitmap> bmp_images = new ArrayList<Bitmap>();

    private ProgressBar progressBar;

    public void onBackendConnected()
    {
            String type = "2";
            AsyncTask<String, Integer, String> data = new ExecuteTask().execute(type, cat_id, "","");
            l1.setOnItemClickListener(this);
            cat_id = "";
            type = "";
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_advertisement);
        l1 = (ListView) findViewById(R.id.ads_list_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            cat_id = extras.getString("category");
//            System.out.println("sel val :");
//            System.out.println(cat_id);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        String url = rowItems.get(i).getCompanyurl();
        Intent intent;
        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://"+url));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            avatarService().setAdBitmapCache(src,myBitmap);
            return myBitmap;
        } catch (IOException e) {
            return null;
        }

    }
    public void addListRow(String strJson) {
        try {
            JSONArray ja = new JSONArray(strJson);
            JSONObject jo = null;
            for (int i = 0; i < ja.length(); i++) {

                jo = ja.getJSONObject(i);
                ads_name = jo.getString("advertisement_name");
                company_url = jo.getString("company_url");
                ads_image = jo.getString("advertisement_image");

                bitmap = null;
                bitmap = avatarService().getAdBitmapCache(ads_image);
                if(bitmap == null)
                    bitmap = getBitmapFromURL(ads_image);

                adsname.add(ads_name);
                companyurl.add(company_url);
                bmp_images.add(bitmap);

                HashMap<String, String> map = new HashMap<String, String>();
                map.put("company_url", jo.getString("company_url"));
                map.put("advertisement_image", jo.getString("advertisement_image"));
                list1.add(map);
            }
        }
            catch(JSONException e){
                e.printStackTrace();
            }
        }

    class ExecuteTask extends AsyncTask<String, Integer, String>
    {

        @Override
        protected String doInBackground(String... params) {

            String res=PostData(params);
            return res;
        }

        @Override
        protected void onPostExecute(String result) {

            rowItems = new ArrayList<RowItem1>();
            for (int i = 0; i < adsname.size(); i++) {
                RowItem1 item = new RowItem1(bmp_images.get(i), adsname.get(i), companyurl.get(i));
                rowItems.add(item);
            }
            AdvertisementsAdapter adapter = new AdvertisementsAdapter(getApplicationContext(),
                    R.layout.advertisements, rowItems);
            l1.setAdapter(adapter);
            progressBar.setVisibility(View.GONE);

        }
            // Toast.makeText(getApplicationContext(), result, 3).show();
        }

    public String PostData(String[] valuse) {
        String s="";
        try
        {
            if(valuse !=null && valuse.length>0){
                HttpClient httpClient = new DefaultHttpClient();
//                HttpPost httpPost = new HttpPost("http://palscom.com/ws/ads.php");
                HttpPost httpPost = new HttpPost(Config.ADVERTISEMENTS_URI);
                List<NameValuePair> list = new ArrayList<NameValuePair>();
                list.add(new BasicNameValuePair("type", valuse[0]));
                list.add(new BasicNameValuePair("category_id", valuse[1]));
                httpPost.setEntity(new UrlEncodedFormEntity(list));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();

                //System.out.println("Elumalai :: This is HttpResponse");
                System.out.println(httpResponse);
                s = readResponse(httpResponse);
                //System.out.println("Elumalai :: Return readResponse object" + s);
                //System.out.println(s);
                addListRow(s);
           }
            else {
                System.out.println("Empty = "+ valuse);
            }

        }
        catch(Exception exception)  {}
        return s;
    }
    public String readResponse(HttpResponse res) {
        InputStream is=null;
        String return_text="";
        try {
            is=res.getEntity().getContent();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(is));
            String line="";
            StringBuffer sb=new StringBuffer();
            while ((line=bufferedReader.readLine())!=null)
            {
                sb.append(line);
            }
            return_text=sb.toString();
        } catch (Exception e)
        {

        }
        return return_text;

    }
}