package com.orbmix.palscomm.xmpp.jingle;

import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.xmpp.PacketReceived;
import com.orbmix.palscomm.xmpp.jingle.stanzas.JinglePacket;

public interface OnJinglePacketReceived extends PacketReceived {
	public void onJinglePacketReceived(Account account, JinglePacket packet);
}
