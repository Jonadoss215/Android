package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.xmpp.stanzas.IqPacket;

public interface OnIqPacketReceived extends PacketReceived {
	public void onIqPacketReceived(Account account, IqPacket packet);
}
