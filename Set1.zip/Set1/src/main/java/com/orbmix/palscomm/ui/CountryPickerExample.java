package com.orbmix.palscomm.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.countrycodepicker.CountryPicker;
import com.orbmix.palscomm.countrycodepicker.CountryPickerListener;

public class CountryPickerExample extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_picker);
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();

        CountryPicker picker = new CountryPicker();
        picker.setListener(new CountryPickerListener() {
            @Override
            public void onSelectCountry(String name, String code, String dialCode) {
              /*  Toast.makeText(
                        CountryPickerExample.this,
                        "Country Name: " + name + " - Code: " + code
                                + " - Currency: "
                                + CountryPicker.getCurrencyCode(code) + " - Dial Code: " + dialCode,
                        Toast.LENGTH_SHORT).show();*/

                Intent intent=new Intent();
                String m =getIntent().getExtras().getString("RegisterActivity");
                String m1 = getIntent().getExtras().getString("startconversation");
                System.out.println("Get Extra string ----"+m);
                if(m != null) {
                    if (m.equals("RegisterActivity")) {
                        intent.putExtra("NAME", name);
                        intent.putExtra("CODE", code);
                        intent.putExtra("DIALCODE", dialCode);
                        setResult(2, intent);
                        finish();//finishing activity
                    }
                }
               else if(m1 != null){
                    if(m1.equals("startconversation")){
                        intent.putExtra("NAME", name);
                        intent.putExtra("CODE", code);
                        intent.putExtra("DIALCODE", dialCode);
                        setResult(3, intent);
                        finish();
                    }
                }
            }
        });
        transaction.replace(R.id.home, picker);
        transaction.commit();
        getActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.

                    home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

  /*  @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.country_picker, menu);
        MenuItem item = menu.findItem(R.id.show_dialog);
        item.setOnMenuItemClickListener(new OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                CountryPicker picker = CountryPicker.newInstance("SelectCountry");
                picker.setListener(new CountryPickerListener() {

                    @Override
                    public void onSelectCountry(String name, String code, String dialCode) {
                        Toast.makeText(
                                CountryPickerExample.this,
                                "Country Name: " + name + " - Code: " + code
                                        + " - Currency: "
                                        + CountryPicker.getCurrencyCode(code) + " - Dial Code: " + dialCode,
                                Toast.LENGTH_SHORT).show();
                    }
                });

                picker.show(getSupportFragmentManager(), "COUNTRY_CODE_PICKER");
                return false;
            }
        });
        return true;
    }*/
}
