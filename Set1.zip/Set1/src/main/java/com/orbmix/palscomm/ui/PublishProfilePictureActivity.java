package com.orbmix.palscomm.ui;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.MucOptions;
import com.orbmix.palscomm.utils.ExifHelper;
import com.orbmix.palscomm.utils.PhoneHelper;
import com.orbmix.palscomm.utils.UIHelper;
import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;
import com.orbmix.palscomm.xmpp.pep.Avatar;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.RejectedExecutionException;

public class PublishProfilePictureActivity extends XmppActivity {

	private static final int REQUEST_CHOOSE_FILE = 0xac23;

	String uuid = null;
	private ImageView avatar;
	private TextView accountTextView;
	private TextView hintOrWarning;
	private TextView secondaryHint;
	private Button cancelButton;
	private Button publishButton;
	private EditText nickName;

	private Uri avatarUri;
	private Uri defaultUri;
	public String imagePath;
	public String imageName;
	public String current__seleted_status = null;

	TextView customstatus;
	EditText statusMsg;
	private static int IMAGE_SIZE = 1920;
	public long imageSize = 0; // kb

	final private ArrayList<Integer> sizes = new ArrayList<>();
	private static final String PREFIX_CONVERSATION = "conversation";

	private Conversation mConversation;
	private OnLongClickListener backToDefaultListener = new OnLongClickListener() {

		@Override
		public boolean onLongClick(View v) {
			avatarUri = defaultUri;
			loadImageIntoPreview(defaultUri);
			return true;
		}
	};
	public Account account;
	private boolean support = false;
	private boolean mInitialAccountSetup;
    private boolean avatarNotChanged = true;
	private UiCallback<Avatar> avatarPublication = new UiCallback<Avatar>() {


        @Override
		public void success(Avatar object) {
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					if (mInitialAccountSetup) {
						Intent intent = new Intent(getApplicationContext(),
								StartConversationActivity.class);
						intent.putExtra("init",true);
						startActivity(intent);
					}
					Toast.makeText(PublishProfilePictureActivity.this,
							R.string.avatar_has_been_published,
							Toast.LENGTH_SHORT).show();
					finish();
				}
			});
		}

		@Override
		public void error(final int errorCode, Avatar object) {
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					hintOrWarning.setText(errorCode);
					hintOrWarning.setTextColor(getWarningTextColor());
					publishButton.setText(R.string.publish);
					enablePublishButton();
				}
			});

		}

		@Override
		public void userInputRequried(PendingIntent pi, Avatar object) {
		}
	};

    @Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_publish_profile_picture);
		this.avatar = (ImageView) findViewById(R.id.account_image);
		this.cancelButton = (Button) findViewById(R.id.cancel_button);
		this.publishButton = (Button) findViewById(R.id.publish_button);
		this.accountTextView = (TextView) findViewById(R.id.account);
		this.hintOrWarning = (TextView) findViewById(R.id.hint_or_warning);
		this.secondaryHint = (TextView) findViewById(R.id.secondary_hint);
		this.nickName = (EditText) findViewById(R.id.nick_name);

		//avatar.setBackgroundColor(0x00000000);
        //Added by Elumalai  for status update
		statusMsg = (EditText) findViewById(R.id.autoCompleteTextView1);
		customstatus = (TextView) findViewById(R.id.custom_status);
		customstatus.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(PublishProfilePictureActivity.this, StatusActivity.class);
				intent.putExtra("currentStatus", account.getAccountStatusMsg());
				startActivityForResult(intent, 23456);
			}
		});


        if(getIntent().getBooleanExtra("isgroup",false))
		{
			this.hintOrWarning.setVisibility(View.GONE);
			this.nickName.setVisibility(View.GONE);
		}


		this.publishButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

                if(statusMsg.getText().toString().trim().length() > 0) {

                    account.setAccountStatusMsg(statusMsg.getText().toString().trim());
                    xmppConnectionService.databaseBackend.updateAccount(account);
					xmppConnectionService.sendPalscomPresence(account, statusMsg.getText().toString());
					Toast.makeText(PublishProfilePictureActivity.this,
							"Your status published successfully!",
							Toast.LENGTH_LONG).show();
                }
                if(nickName.getText().toString().trim().length() > 0) {
                    account.setAccountNickName(nickName.getText().toString().trim());
                    xmppConnectionService.databaseBackend.updateAccount(account);

                }

                if (avatarUri != null && !avatarNotChanged) {
					publishButton.setText(R.string.publishing);
					disablePublishButton();

					if(getIntent().getBooleanExtra("isgroup",false))
					{
						uploadGrpAvatar(mConversation,avatarUri);
					}
					else
					{
						xmppConnectionService.publishAvatar(account, avatarUri,
							avatarPublication);
					}
				}
                PublishProfilePictureActivity.this.finish();
			}
		});
		this.cancelButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mInitialAccountSetup) {
					Intent intent = new Intent(getApplicationContext(),
							StartConversationActivity.class);
					if (xmppConnectionService != null && xmppConnectionService.getAccounts().size() == 1) {
						intent.putExtra("init", true);
					}
					startActivity(intent);
				}
				finish();
			}
		});
		this.avatar.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent attachFileIntent = new Intent();
				attachFileIntent.setType("image/*");
				attachFileIntent.setAction(Intent.ACTION_GET_CONTENT);
				Intent chooser = Intent.createChooser(attachFileIntent,
						getString(R.string.attach_file));
				startActivityForResult(chooser, REQUEST_CHOOSE_FILE);
			}
		});

		this.defaultUri = PhoneHelper.getSefliUri(getApplicationContext());

	}

	private void  uploadGrpAvatar(final Conversation conversation,
			  final Uri image)
	{

		try
		{
			// GET IMAGE PATH
			imagePath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+Config.APP_MEDIA_FOLDER+"/"+getIntent().getExtras().getString("name")+".webp";
			// IMAGE NAME
			imageName = imagePath.substring(imagePath.lastIndexOf("/"));
			imageSize = this.getFileSize(imagePath);

			InputStream is = this.getContentResolver()
					.openInputStream(image);
			File file = new File(imagePath);
			file.getParentFile().mkdirs();
			file.createNewFile();
			Bitmap originalBitmap;
			BitmapFactory.Options options = new BitmapFactory.Options();
			int inSampleSize = (int) Math.pow(2, 0);
			Log.d(Config.LOGTAG, "reading bitmap with sample size "
					+ inSampleSize);
			options.inSampleSize = inSampleSize;
			originalBitmap = BitmapFactory.decodeStream(is, null, options);
			is.close();
			if (originalBitmap == null) {
				Toast.makeText(PublishProfilePictureActivity.this,
						"Group Avatar Image conversion error",
						Toast.LENGTH_SHORT).show();

			}
			Bitmap scalledBitmap = resize(originalBitmap, IMAGE_SIZE);
			originalBitmap = null;
			int rotation = getRotation(image);
			if (rotation > 0) {
				scalledBitmap = rotate(scalledBitmap, rotation);
			}
			OutputStream os = new FileOutputStream(file);
			boolean success = scalledBitmap.compress(
					Bitmap.CompressFormat.WEBP, 75, os);
			if (!success) {
				Toast.makeText(PublishProfilePictureActivity.this,
						"Group Avatar Image Compression failed",
						Toast.LENGTH_SHORT).show();
			}
            Bitmap temp = null;
            temp = UIHelper.makeCircleBitmap(scalledBitmap);
			String KEY = key(conversation.getMucOptions(), getPixel(194));
			xmppConnectionService.getBitmapCache().put(KEY, temp);
			KEY = key(conversation.getMucOptions(), getPixel(48));
			xmppConnectionService.getBitmapCache().put(KEY, temp);
			KEY = key(conversation.getMucOptions(), getPixel(36));
			xmppConnectionService.getBitmapCache().put(KEY, temp);
			os.flush();
			os.close();



			// EXECUTED ASYNCTASK TO UPLOAD IMAGE
			new ImageUploader().execute();
		}
		catch (Exception e)
		{
	            // handle exception here
	            Log.e(e.getClass().getName(), e.getMessage());
		}
	}
	private String key(MucOptions options, int size) {
		synchronized (this.sizes) {
			if (!this.sizes.contains(size)) {
				this.sizes.add(size);
			}
		}
		return PREFIX_CONVERSATION + "_" + options.getConversation().getUuid()
				+ "_" + String.valueOf(size);
	}
	public Bitmap resize(Bitmap originalBitmap, int size) {
		int w = originalBitmap.getWidth();
		int h = originalBitmap.getHeight();
		if (Math.max(w, h) > size) {
			int scalledW;
			int scalledH;
			if (w <= h) {
				scalledW = (int) (w / ((double) h / size));
				scalledH = size;
			} else {
				scalledW = size;
				scalledH = (int) (h / ((double) w / size));
			}
			Bitmap scalledBitmap = Bitmap.createScaledBitmap(originalBitmap,
					scalledW, scalledH, true);
			return scalledBitmap;
		} else {
			return originalBitmap;
		}
	}

	public Bitmap rotate(Bitmap bitmap, int degree) {
		int w = bitmap.getWidth();
		int h = bitmap.getHeight();
		Matrix mtx = new Matrix();
		mtx.postRotate(degree);
		return Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true);
	}

	private int getRotation(Uri image) {
		try {
			InputStream is = this.getContentResolver()
					.openInputStream(image);
			return ExifHelper.getOrientation(is);
		} catch (FileNotFoundException e) {
			return 0;
		}
	}


	/**
	 * Get the image path
	 * @param uri
	 * @return
	 */
	private String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

	/**
	 * Get the file size in kilobytes
	 * @return
	 */
	private long getFileSize(String imagePath){
		long length = 0;

		try {

			File file = new File(imagePath);
			length = file.length();
			length = length / 1024;

		} catch (Exception e) {

			e.printStackTrace();
		}

		return length;
	}

	private class ImageUploader extends AsyncTask<Void, Integer, Boolean>  {
		@Override
		protected Boolean doInBackground(Void... params) {
	        try{

	        	InputStream inputStream = new FileInputStream(new File(imagePath));

	            //*** CONVERT INPUTSTREAM TO BYTE ARRAY

	            byte[] data = this.convertToByteArray(inputStream);

	            HttpClient httpClient = new DefaultHttpClient();
	            httpClient.getParams().setParameter(CoreProtocolPNames.USER_AGENT,System.getProperty("http.agent"));

	            HttpPost httpPost = new HttpPost(Config.UPLOAD_GRP_AVATAR_SERVER_URI);

	            // STRING DATA
	            StringBody dataString = new StringBody("This is the sample image");

	            // FILE DATA OR IMAGE DATA
	            InputStreamBody inputStreamBody = new InputStreamBody(new ByteArrayInputStream(data),imageName);

	           // MultipartEntity multipartEntity = new MultipartEntity();
	            MultipartEntity  multipartEntity = new MultipartEntity();


	            //*** ADD THE FILE
	            multipartEntity.addPart("fileToUpload", inputStreamBody);

	            //*** ADD STRING DATA
	            multipartEntity.addPart("description",dataString);

	            httpPost.setEntity(multipartEntity);
	            httpPost.setEntity(multipartEntity);

	            // EXECUTE HTTPPOST
	            HttpResponse httpResponse = httpClient.execute(httpPost);

	            // THE RESPONSE FROM SERVER
	            String stringResponse =  EntityUtils.toString(httpResponse.getEntity());

	            // DISPLAY RESPONSE OF THE SERVER
	            Log.d("data from server",stringResponse);



	        } catch (FileNotFoundException e1) {
	            e1.printStackTrace();

	            return false;

	        } catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

				return false;

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

				return false;
			}

			 return true;
		}


		/**
		 * Convert the InputStream to byte[]
		 * @param inputStream
		 * @return
		 * @throws IOException
		 */
		private byte[] convertToByteArray(InputStream inputStream) throws IOException{

			ByteArrayOutputStream bos = new ByteArrayOutputStream();

            int next = inputStream.read();
            while (next > -1) {
                bos.write(next);
                next = inputStream.read();
            }

            bos.flush();

            return bos.toByteArray();
		}
		@Override
		protected void onProgressUpdate(Integer... values) {
			super.onProgressUpdate(values);

			// UPDATE THE PROGRESS DIALOG

			//System.out.println"Uploading"+values[0]);
			//progressDialog.setProgress(values[0]);
		}

		@Override
		protected void onPostExecute(Boolean uploaded) {
			// TODO Auto-generated method stub
			super.onPostExecute(uploaded);
			if( uploaded){
				// UPLOADING DATA SUCCESS
				//progressDialog.dismiss();
				Toast.makeText(PublishProfilePictureActivity.this,
				R.string.avatar_has_been_published,
				Toast.LENGTH_SHORT).show();
				finish();
			}else{
				// UPLOADING DATA FAILED
				Toast.makeText(PublishProfilePictureActivity.this, R.string.error_publish_avatar_server_reject, Toast.LENGTH_SHORT).show();
				//progressDialog.setMessage("Uploading Failed");
				//progressDialog.setCancelable(true);
			}
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			final Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			if (requestCode == REQUEST_CHOOSE_FILE) {
				this.avatarUri = data.getData();
				if (xmppConnectionServiceBound) {
					loadImageIntoPreview(this.avatarUri);
				}
			}
		}if(requestCode == 23456) {
			PublishProfilePictureActivity.this.runOnUiThread(new Runnable() {
				public void run() {
					if (data != null) {
						current__seleted_status = data.getStringExtra("result");
						if (current__seleted_status != null) {
							String str = current__seleted_status + "";
							Log.i("seleted contacts", "---" + str);
//							customstatus.setText(str);

//							statusMsg.setText("");
//							statusMsg.setHint("");
                            statusMsg.setText(str);
							enablePublishButton();
						}
					}
				}
			});

		}
	}

	class BitmapWorkerTask extends AsyncTask<Conversation, Void, Bitmap> {
		private final WeakReference<ImageView> imageViewReference;
		private Conversation conversation = null;

		public BitmapWorkerTask(ImageView imageView) {
			imageViewReference = new WeakReference<>(imageView);
		}

		@Override
		protected Bitmap doInBackground(Conversation... params) {
			return avatarService().get(params[0], getPixel(56));
		}

		@Override
		protected void onPostExecute(Bitmap bitmap) {
			if (bitmap != null) {
				final ImageView imageView = imageViewReference.get();
				if (imageView != null) {
					imageView.setImageBitmap(bitmap);
					imageView.setBackgroundColor(0x00000000);
				}
			}
		}
	}

	// Changed by Elumalai for avatar issue
	public void loadAvatar(Conversation conversation, ImageView imageView) {
		Bitmap bm = avatarService().get(conversation, getPixel(194), true);
		if (bm != null) {
			imageView.setImageBitmap(bm);
			imageView.setBackgroundColor(0x00000000);

		}  else {
			if (conversation.getJid().toBareJid().toString().contains("_bc_")) {
				Drawable myDrawable = PublishProfilePictureActivity.this.getResources().getDrawable(R.drawable.bc_group);
				imageView.setImageDrawable(myDrawable);
			}else if (conversation.getJid().toBareJid().toString().contains("_ev_")){
				Drawable myDrawable = PublishProfilePictureActivity.this.getResources().getDrawable(R.drawable.event_group);
				imageView.setImageDrawable(myDrawable);
			} else if (conversation.getJid().toBareJid().toString().contains("conference")) {
				Drawable myDrawable = PublishProfilePictureActivity.this.getResources().getDrawable(R.drawable.group);
				imageView.setImageDrawable(myDrawable);
			} else {
				Drawable myDrawable = PublishProfilePictureActivity.this.getResources().getDrawable(R.drawable.user_default);
				imageView.setImageDrawable(myDrawable);
			}
		/* else if (cancelPotentialWork(conversation, imageView)) {
			//imageView.setBackgroundColor(UIHelper.getColorForName(conversation.getName()));
			final BitmapWorkerTask task = new BitmapWorkerTask(imageView);
			final AsyncDrawable asyncDrawable = new AsyncDrawable(getResources(), null, task);
			imageView.setImageDrawable(asyncDrawable);
			try {
				task.execute(conversation);
			} catch (final RejectedExecutionException ignored) {
			}*/
		}
	}
	public static boolean cancelPotentialWork(Conversation conversation, ImageView imageView) {
		final BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);

		if (bitmapWorkerTask != null) {
			final Conversation oldConversation = bitmapWorkerTask.conversation;
			if (oldConversation == null || conversation != oldConversation) {
				bitmapWorkerTask.cancel(true);
			} else {
				return false;
			}
		}
		return true;
	}

	private static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
		if (imageView != null) {
			final Drawable drawable = imageView.getDrawable();
			if (drawable instanceof AsyncDrawable) {
				final AsyncDrawable asyncDrawable = (AsyncDrawable) drawable;
				return asyncDrawable.getBitmapWorkerTask();
			}
		}
		return null;
	}

	static class AsyncDrawable extends BitmapDrawable {
		private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

		public AsyncDrawable(Resources res, Bitmap bitmap, BitmapWorkerTask bitmapWorkerTask) {
			super(res, bitmap);
			bitmapWorkerTaskReference = new WeakReference<>(bitmapWorkerTask);
		}

		public BitmapWorkerTask getBitmapWorkerTask() {
			return bitmapWorkerTaskReference.get();
		}
	}
	@Override
	protected void onBackendConnected() {
		///System.out.println("onbackend caled!");
		//System.out.printlnn(xmppConnectionService);

		uuid = getIntent().getExtras().getString("uuid");
		if (uuid != null) {
			mConversation = xmppConnectionService.findConversationByUuid(uuid);
		}
		if (getIntent() != null) {
            Jid jid;
            try {
                jid = Jid.fromString(getIntent().getStringExtra("account"));
            } catch (InvalidJidException e) {
                jid = null;
            }
            if (jid != null) {
				this.account = xmppConnectionService.findAccountByJid(jid);
				if (this.account.getXmppConnection() != null) {
					this.support = this.account.getXmppConnection().getFeatures().pep();
				}
				nickName.setText(this.account.getAccountNickName());
				statusMsg.setText(this.account.getAccountStatusMsg());
				statusMsg.setText("");
				statusMsg.setText(current__seleted_status);
				if (this.avatarUri == null) {
					if (this.account.getAvatar() != null
							|| this.defaultUri == null) {
						if(getIntent().getBooleanExtra("isgroup",false))
						{
							/*new Thread()
							{
								public void run()
								{
									avatar.setImageBitmap(avatarService().get(mConversation,
									getPixel(194)));
								}
							};*/
							loadAvatar(mConversation, avatar);
						}
						else
						{
							this.avatar.setImageBitmap(avatarService().get(account,
									getPixel(194)));
						}

						if (this.defaultUri != null) {
							this.avatar
									.setOnLongClickListener(this.backToDefaultListener);
						} else {
							this.secondaryHint.setVisibility(View.INVISIBLE);
						}
						if (!support) {
							this.hintOrWarning
									.setTextColor(getWarningTextColor());
							this.hintOrWarning
									.setText(R.string.error_publish_avatar_no_server_support);
						}
					} else {
						this.avatarUri = this.defaultUri;
						loadImageIntoPreview(this.defaultUri);
						this.secondaryHint.setVisibility(View.INVISIBLE);
					}
				} else {
					loadImageIntoPreview(avatarUri);
				}
				if(getIntent().getBooleanExtra("isgroup",false))
				{
					if(mConversation != null)
						this.accountTextView.setText(mConversation.getName());
				}
				else
					this.accountTextView.setText(this.account.getJid().toBareJid().toString().split("@")[0]);

			}
		}

	}

	@Override
	protected void onStart() {
		super.onStart();
		if (getIntent() != null) {
			this.mInitialAccountSetup = getIntent().getBooleanExtra("setup",
					false);
		}
		if (this.mInitialAccountSetup) {
			this.cancelButton.setText(R.string.skip);
		}
		if(current__seleted_status != null){
			statusMsg.setText("");
			statusMsg.setText(current__seleted_status);
		}
	}

	protected void loadImageIntoPreview(Uri uri) {
		Bitmap bm = xmppConnectionService.getFileBackend().cropCenterSquare(
				uri, 384);
		if (bm == null) {
			disablePublishButton();
			this.hintOrWarning.setTextColor(getWarningTextColor());
			this.hintOrWarning
					.setText(R.string.error_publish_avatar_converting);
			return;
		}
		bm = UIHelper.makeCircleBitmap(bm);
		this.avatar.setImageBitmap(bm);
		if (support) {
			enablePublishButton();
            avatarNotChanged = false;
			this.publishButton.setText(R.string.publish);
			this.hintOrWarning.setText(R.string.publish_avatar_explanation);
			this.hintOrWarning.setTextColor(getPrimaryTextColor());
		} else {
			disablePublishButton();
			this.hintOrWarning.setTextColor(getWarningTextColor());
			this.hintOrWarning
					.setText(R.string.error_publish_avatar_no_server_support);
		}
		if (this.defaultUri != null && uri.equals(this.defaultUri)) {
			this.secondaryHint.setVisibility(View.INVISIBLE);
			this.avatar.setOnLongClickListener(null);
		} else if (this.defaultUri != null) {
			this.secondaryHint.setVisibility(View.VISIBLE);
			this.avatar.setOnLongClickListener(this.backToDefaultListener);
		}
	}

	protected void enablePublishButton() {
		this.publishButton.setEnabled(true);
		this.publishButton.setTextColor(getPrimaryTextColor());
	}

	protected void disablePublishButton() {
		this.publishButton.setEnabled(false);
		this.publishButton.setTextColor(getSecondaryTextColor());
	}

}
