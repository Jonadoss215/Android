package com.orbmix.palscomm.countrycodepicker;

public interface CountryPickerListener {
	public void onSelectCountry(String name, String code, String dialCode);
}
