package com.orbmix.palscomm.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Favorite;
import com.orbmix.palscomm.entities.ListItem;
import com.orbmix.palscomm.entities.Presences;
import com.orbmix.palscomm.ui.adapter.FavoriteStatusAdapter;
import com.orbmix.palscomm.ui.adapter.UpdateStatusAdapter;
import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Elumalai on 12/18/2015.
 */
public abstract class AbstractFavouritesActivity extends XmppActivity{

    private ListView mListView;
    private final List<ListItem> listItems = new ArrayList<>();
    private ArrayAdapter<ListItem> mListItemsAdapter;
    private EditText mSearchEditText;
    protected static final int ADD_USERS_TO_FAVOURITE = 0x0132456;

    private final MenuItem.OnActionExpandListener mOnActionExpandListener = new MenuItem.OnActionExpandListener() {

        @Override
        public boolean onMenuItemActionExpand(final MenuItem item) {
            mSearchEditText.post(new Runnable() {

                @Override
                public void run() {
                    mSearchEditText.requestFocus();
                    final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(mSearchEditText,
                            InputMethodManager.SHOW_IMPLICIT);
                }
            });

            return true;
        }

        @Override
        public boolean onMenuItemActionCollapse(final MenuItem item) {
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mSearchEditText.getWindowToken(),
                    InputMethodManager.HIDE_IMPLICIT_ONLY);
            mSearchEditText.setText("");
            filterContacts();
            return true;
        }
    };

    private final TextWatcher mSearchTextWatcher = new TextWatcher() {

        @Override
        public void afterTextChanged(final Editable editable) {
            filterContacts(editable.toString());
        }

        @Override
        public void beforeTextChanged(final CharSequence s, final int start, final int count,
                                      final int after) {
        }

        @Override
        public void onTextChanged(final CharSequence s, final int start, final int before,
                                  final int count) {
        }
    };

    public ListView getListView() {
        return mListView;
    }

    public List<ListItem> getListItems() {
        return listItems;
    }

    public EditText getSearchEditText() {
        return mSearchEditText;
    }

    public ArrayAdapter<ListItem> getListItemAdapter() {
        return mListItemsAdapter;
    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_status);
        mListView = (ListView) findViewById(R.id.update_status);
        mListView.setFastScrollEnabled(false);
        mListItemsAdapter = new FavoriteStatusAdapter(this, listItems);
        mListView.setAdapter(mListItemsAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.choose_contact, menu);
        final MenuItem menuSearchView = menu.findItem(R.id.action_search);
        final View mSearchView = menuSearchView.getActionView();
        mSearchEditText = (EditText) mSearchView
                .findViewById(R.id.search_field);
        mSearchEditText.addTextChangedListener(mSearchTextWatcher);
        menuSearchView.setOnActionExpandListener(mOnActionExpandListener);
        return true;
    }

    protected void filterContacts() {
        filterContacts(null);
    }

    protected abstract void filterContacts(final String needle);

    @Override
    void onBackendConnected() {
        filterContacts();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_show_unblock_contacts:
                final Intent intent = new Intent(getApplicationContext(),
                        ChooseContactForFavourite.class);
                intent.putExtra("multiple", true);
                intent.putExtra("favourite", true);
                startActivityForResult(intent, ADD_USERS_TO_FAVOURITE);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    protected void onActivityResult(int requestCode, int resultCode,
                                    final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_USERS_TO_FAVOURITE && resultCode == RESULT_OK) {
            //Added by Elumalai conform to the before blocking group of contacts
            confirmUserAddition(data,this);
//            addContactstoFavorite(data, this);
        }
    }

    protected void confirmUserAddition(final Intent data,final XmppActivity obj)
    {

    /*    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle(R.string.confirm);
        builder.setMessage(R.string.confirm_unblock_contact);
        builder.setPositiveButton(R.string.action_block_contact, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {*/

                if (data.getBooleanExtra("multiple", false)) {
                    String[] toAdd = data.getStringArrayExtra("contacts");
                    for (String item : toAdd) {

                        Jid jid = null;
                        Contact contact;
                        try {
                            jid = Jid.fromString(item);
                            // jid.getLocalpart();
                            contact = new Contact(jid);
                            Log.i("favorite","xmppConnectionService.getAccounts().get(0)-----"+xmppConnectionService.getAccounts().get(0));
                            contact.setAccount(xmppConnectionService.getAccounts().get(0));
                            final Favorite cont = contact;

                            xmppConnectionService.sendFavoriteRequest(cont);
                        } catch (InvalidJidException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                } else {

                    // String[] toAdd = data.getStringArrayExtra("contacts");
                    String item = data.getStringExtra("contact");
                    // for (String item : toAdd) {

                    Jid jid = null;
                    Contact contact;
                    try {
                        jid = Jid.fromString(item);
                        Log.i("favorite", "favorite single contacts selected --- item---"+item);
                        // jid.getLocalpart();
                        contact = new Contact(jid);
                        Log.i("favorite", "favorite single contacts selected --- Jid---"+jid);
                        contact.setAccount(xmppConnectionService.getAccounts().get(0));
                        final Favorite cont = contact;
                        xmppConnectionService.sendFavoriteRequest(cont);
                    } catch (InvalidJidException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    // xmppConnectionService.sendBlockRequest(blockable);
                    //invite.jids.add(Jid.fromString(data.getStringExtra("contact")));
                    //  }

                }
            }
       /* });
        builder.create().show();
    }*/
}

