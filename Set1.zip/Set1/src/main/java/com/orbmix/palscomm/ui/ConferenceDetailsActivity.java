package com.orbmix.palscomm.ui;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.crypto.PgpEngine;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Bookmark;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.MucOptions;
import com.orbmix.palscomm.entities.MucOptions.User;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.services.XmppConnectionService.OnConversationUpdate;
import com.orbmix.palscomm.services.XmppConnectionService.OnMucRosterUpdate;
import com.orbmix.palscomm.utils.HttpCall;
import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;

import org.openintents.openpgp.util.OpenPgpUtils;

import java.lang.ref.WeakReference;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class ConferenceDetailsActivity extends XmppActivity implements OnConversationUpdate, OnMucRosterUpdate, XmppConnectionService.OnAffiliationChanged, XmppConnectionService.OnRoleChanged, XmppConnectionService.OnConferenceOptionsPushed {
    public static final String ACTION_VIEW_MUC = "view_muc";
    private Conversation mConversation;
    private OnClickListener inviteListener = new OnClickListener() {

        @Override
        public void onClick(View v) {
            inviteToConversation(mConversation);
        }
    };
    private TextView mYourNick;
    private ImageView mYourPhoto;
    private ImageView mGroupPhoto;
    private ImageButton mEditNickButton;
    private TextView mRoleAffiliaton;
    private TextView mFullJid;
    private TextView mAccountJid;
    private LinearLayout membersView;
    private LinearLayout mMoreDetails;
    private TextView mConferenceType;
    private ImageButton mChangeConferenceSettingsButton;
    private Button mInviteButton;
    private String uuid = null;
    private User mSelectedUser = null;

    private String mucOnlineUsers = "";
    private String mucOfflineUsers = "";
    private String deleteMsg = "Exit";

    private boolean mAdvancedMode = false;
    ProgressDialog pd;
    private UiCallback<Conversation> renameCallback = new UiCallback<Conversation>() {
        @Override
        public void success(Conversation object) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(ConferenceDetailsActivity.this, getString(R.string.your_nick_has_been_changed), Toast.LENGTH_SHORT).show();
                    Log.i("updateView", "sucess(Conversation objects)");
                    updateView();
                }
            });

        }

        @Override
        public void error(final int errorCode, Conversation object) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(ConferenceDetailsActivity.this, getString(errorCode), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public void userInputRequried(PendingIntent pi, Conversation object) {

        }
    };
    private OnClickListener mChangeConferenceSettings = new OnClickListener() {
        @Override
        public void onClick(View v) {
            final MucOptions mucOptions = mConversation.getMucOptions();
            AlertDialog.Builder builder = new AlertDialog.Builder(ConferenceDetailsActivity.this);
            builder.setTitle(R.string.conference_options);
            String[] options = {getString(R.string.members_only),
                    getString(R.string.non_anonymous)};
            final boolean[] values = new boolean[options.length];
            values[0] = mucOptions.membersOnly();
            values[1] = mucOptions.nonanonymous();
            builder.setMultiChoiceItems(options, values, new DialogInterface.OnMultiChoiceClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                    values[which] = isChecked;
                }
            });
            builder.setNegativeButton(R.string.cancel, null);
            builder.setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (!mucOptions.membersOnly() && values[0]) {
                        xmppConnectionService.changeAffiliationsInConference(mConversation,
                                MucOptions.Affiliation.NONE,
                                MucOptions.Affiliation.MEMBER);
                    }
                    Bundle options = new Bundle();
                    options.putString("muc#roomconfig_membersonly", values[0] ? "1" : "0");
                    options.putString("muc#roomconfig_whois", values[1] ? "anyone" : "moderators");
                    options.putString("muc#roomconfig_persistentroom", "1");
                    xmppConnectionService.pushConferenceConfiguration(mConversation,
                            options,
                            ConferenceDetailsActivity.this);
                }
            });
            builder.create().show();
        }
    };
    private OnValueEdited onSubjectEdited = new OnValueEdited() {

        @Override
        public void onValueEdited(String value) {
            xmppConnectionService.pushSubjectToConference(mConversation, value);
        }
    };

    @Override
    public void onConversationUpdate() {
        refreshUi();
    }

    @Override
    public void onMucRosterUpdate() {
        refreshUi();
    }

    @Override
    protected void refreshUiReal() {
        updateView();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muc_details);
        mGroupPhoto = (ImageView) findViewById(R.id.group_photo);
        mYourNick = (TextView) findViewById(R.id.muc_your_nick);
        mYourPhoto = (ImageView) findViewById(R.id.your_photo);
//        mEditNickButton = (ImageButton) findViewById(R.id.edit_nick_button);
        mFullJid = (TextView) findViewById(R.id.muc_jabberid);
        membersView = (LinearLayout) findViewById(R.id.muc_members);
        mAccountJid = (TextView) findViewById(R.id.details_account);
        mMoreDetails = (LinearLayout) findViewById(R.id.muc_more_details);
        //mMoreDetails.setVisibility(View.GONE);
        mChangeConferenceSettingsButton = (ImageButton) findViewById(R.id.change_conference_button);
        mChangeConferenceSettingsButton.setOnClickListener(this.mChangeConferenceSettings);
        mConferenceType = (TextView) findViewById(R.id.muc_conference_type);

        pd = new ProgressDialog(ConferenceDetailsActivity.this);
        pd.setMessage("Please wait...");
        pd.setCancelable(false);
        pd.setIndeterminate(true);

        mInviteButton = (Button) findViewById(R.id.invite);
        mInviteButton.setOnClickListener(inviteListener);
//        mConferenceType = (TextView) findViewById(R.id.muc_conference_type);
        if (getActionBar() != null) {
            getActionBar().setHomeButtonEnabled(true);
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }
        mGroupPhoto.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (v.equals(mGroupPhoto)) {
                    // Write your awesome code here
                    //System.out.println"It's group avatar clicked. open the load avatar page.");
                    Intent intent = new Intent(getApplicationContext(),
                            PublishProfilePictureActivity.class);
                    intent.putExtra("account", mConversation.getAccount().getJid().toString());
                    intent.putExtra("uuid", uuid);
                    //System.out.println"id:"+mConversation.getMucOptions().getConversation().getJid().toBareJid().toString().split("@")[0]);
                    intent.putExtra("name", mConversation.getMucOptions().getConversation().getJid().toBareJid().toString().split("@")[0]);
                    intent.putExtra("isgroup", true);
                    startActivity(intent);
                }
            }
        });
       /* mEditNickButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                quickEdit(mConversation.getMucOptions().getActualNick(),
                        new OnValueEdited() {

                            @Override
                            public void onValueEdited(String value) {
                                xmppConnectionService.renameInMuc(mConversation,value,renameCallback);
                            }
                        });
            }
        });*/


    }

    protected void delete_emptyConference() {

        final Bookmark bookmark = this.mConversation.getBookmark();
        System.out.println("deleteConference :: " + getString(R.string.remove_bookmark_text,
                bookmark.getDisplayName()));
        System.out.println("bookmark.getAccount() ::" + bookmark.getAccount() + ",bookmark.getConversation():" + bookmark.getConversation());
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle("No members");
        builder.setMessage(getString(R.string.remove_bookmark_text,
                bookmark.getDisplayName()));
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //xmppConnectionService.leaveMuc(bookmark.getConversation());
                xmppConnectionService.archiveConversation(bookmark.getConversation());
                //xmppConnectionService.
                System.out.println("bookmark.getConversation() ::" + bookmark.getConversation());
                //xmppConnectionService.databaseBackend.updateConversation(bookmark.getConversation());
                bookmark.unregisterConversation();
                Account account = bookmark.getAccount();
                account.getBookmarks().remove(bookmark);
                xmppConnectionService.pushBookmarks(account);
                finish();
            }
        });
        builder.create().show();
    }

    protected void deleteEmptyConversation() {
        System.out.println("deleteEmptyConversation");
        Bookmark bkmrg = this.mConversation.getBookmark();
        xmppConnectionService.archiveConversation(bkmrg.getConversation());
        //xmppConnectionService.
        System.out.println("bookmark.getConversation() ::" + bkmrg.getConversation());
        //xmppConnectionService.databaseBackend.updateConversation(bookmark.getConversation());
        bkmrg.unregisterConversation();
        Account account = bkmrg.getAccount();
        account.getBookmarks().remove(bkmrg);
        xmppConnectionService.pushBookmarks(account);
    }


    // Added by Elumalai for getting Group member count
    protected void emptymember_group_delete_Auto() {
        final boolean[] flag = {false};
        String param = "";
        String eventOwnerId = "", totUsers = "";
        param = "type=4&groupid=" + mConversation.getContact().getJid().toBareJid();
        //below two lines are added by Elumalai.
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String returnval;

//                returnval = HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
        pd.show();
        returnval = HttpCall.webService(Config.GROUP_MEMBERS_URI, param);

        if (returnval != null)
            pd.dismiss();

        final String[] wsdetails = returnval.split("\\|");
        eventOwnerId = wsdetails[0];
        totUsers = wsdetails[1];

        check_EmptyGroups(totUsers);
    }

    //Aee
    protected void check_EmptyGroups(String membercunt) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.delete_alert);
        builder.setMessage(getString(R.string.empty_member_group_delete_auto));
        builder.setNegativeButton(R.string.cancel, null);
        final String finalTotUsers = membercunt;
        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                int memcount = Integer.parseInt(finalTotUsers);
                if (memcount == 1 || memcount == 0) {
                    deleteEmptyConversation();
                }
            }
        });
        builder.create().show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {

        switch (menuItem.getItemId()) {
            case android.R.id.home:
                // added by Elumalai Empty member Groups deleted autometically
//                emptymember_group_delete_Auto();

                String param = "";
                String eventOwnerId = "", totUsers = "";
                param = "type=4&groupid=" + mConversation.getContact().getJid().toBareJid();
                //below two lines are added by Elumalai.
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String returnval;

//                returnval = HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                pd.show();
                returnval = HttpCall.webService(Config.GROUP_MEMBERS_URI, param);

                if (returnval != null)
                    pd.dismiss();

                final String[] wsdetails = returnval.split("\\|");
                eventOwnerId = wsdetails[0];
                totUsers = wsdetails[1];

                int memcount = Integer.parseInt(totUsers);
                if (memcount == 1 || memcount == 0) {
                    deleteEmptyConversation();
                }
                break;
            case R.id.action_edit_subject:
                if (mConversation != null) {
                    quickEdit(mConversation.getName(), this.onSubjectEdited);
                }
                break;
            case R.id.action_save_as_bookmark:
                saveAsBookmark();
                break;
            case R.id.action_delete_bookmark:
                deleteBookmark();
                break;
            case R.id.action_advanced_mode:
                this.mAdvancedMode = !menuItem.isChecked();
                menuItem.setChecked(this.mAdvancedMode);
                invalidateOptionsMenu();
                Log.i("updateView", "action_advance_mode menu");
                updateView();
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    protected String getShareableUri() {
        if (mConversation != null) {
            return "xmpp:" + mConversation.getJid().toBareJid().toString() + "?join";
        } else {
            return "";
        }
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem menuItemSaveBookmark = menu.findItem(R.id.action_save_as_bookmark);
        MenuItem menuItemDeleteBookmark = menu.findItem(R.id.action_delete_bookmark);
        MenuItem menuItemAdvancedMode = menu.findItem(R.id.action_advanced_mode);
        menuItemAdvancedMode.setVisible(false);
        menuItemAdvancedMode.setChecked(mAdvancedMode);
        if (mConversation == null) {
            return true;
        }
        Account account = mConversation.getAccount();
        if (account.hasBookmarkFor(mConversation.getJid().toBareJid())) {
            menuItemSaveBookmark.setVisible(false);
            menuItemDeleteBookmark.setVisible(false);
        } else {
            menuItemDeleteBookmark.setVisible(false);
            menuItemSaveBookmark.setVisible(false);
        }
        // Added by Elumalai for Deleting Group visibility
        if (mConversation.getMucOptions().canInvite()) {
            String param = "";
            String eventOwnerId = "", totUsers = "";
            param = "type=4&groupid=" + mConversation.getContact().getJid().toBareJid();
            //below two lines are added by Elumalai.
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            String returnval;
//            returnval = HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
            pd.show();
            returnval = HttpCall.webService(Config.GROUP_MEMBERS_URI, param);

            if (returnval != null) {
                pd.dismiss();
            }
//            Log.i("contactdetails", "returnval ----" + returnval + "--- param --" + param);
            final String[] wsdetails = returnval.split("\\|");
            eventOwnerId = wsdetails[0];
            totUsers = wsdetails[1];
            int memcount = Integer.parseInt(totUsers);
//            Log.i("membercount","Delete Group ---"+memcount);
            if (memcount != 0) {
                if (memcount <= 1) {
                    menuItemDeleteBookmark.setVisible(true);
                }
            }
        } else {
            menuItemDeleteBookmark.setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.muc_details, menu);
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        Object tag = v.getTag();
        if (tag instanceof User) {
            getMenuInflater().inflate(R.menu.muc_details_context, menu);
            final User user = (User) tag;
            final User self = mConversation.getMucOptions().getSelf();
            this.mSelectedUser = user;
            String name;
            if (user.getJid() != null) {
                final Contact contact = user.getContact();
                if (contact != null) {
                    name = contact.getDisplayName();
                } else {
                    name = user.getJid().toBareJid().toString();
                }
                menu.setHeaderTitle(name);
                MenuItem startConversation = menu.findItem(R.id.start_conversation);
                MenuItem giveMembership = menu.findItem(R.id.give_membership);
                MenuItem removeMembership = menu.findItem(R.id.remove_membership);
                MenuItem giveAdminPrivileges = menu.findItem(R.id.give_admin_privileges);
                MenuItem removeAdminPrivileges = menu.findItem(R.id.remove_admin_privileges);
                MenuItem removeFromRoom = menu.findItem(R.id.remove_from_room);
                MenuItem banFromConference = menu.findItem(R.id.ban_from_conference);
                startConversation.setVisible(true);
                if (self.getAffiliation().ranks(MucOptions.Affiliation.ADMIN) &&
                        self.getAffiliation().outranks(user.getAffiliation())) {
                    if (mAdvancedMode) {
                        if (user.getAffiliation() == MucOptions.Affiliation.NONE) {
                            giveMembership.setVisible(true);
                        } else {
                            removeMembership.setVisible(true);
                        }
                        banFromConference.setVisible(true);
                    } else {
                        removeFromRoom.setVisible(true);
                    }
                    if (user.getAffiliation() != MucOptions.Affiliation.ADMIN) {
                        giveAdminPrivileges.setVisible(true);
                    } else {
                        removeAdminPrivileges.setVisible(true);
                    }
                }
            }
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.start_conversation:
                startConversation(mSelectedUser);
                return true;
            case R.id.give_admin_privileges:
                xmppConnectionService.changeAffiliationInConference(mConversation, mSelectedUser.getJid(), MucOptions.Affiliation.ADMIN, this);
                return true;
            case R.id.give_membership:
                xmppConnectionService.changeAffiliationInConference(mConversation, mSelectedUser.getJid(), MucOptions.Affiliation.MEMBER, this);
                return true;
            case R.id.remove_membership:
                xmppConnectionService.changeAffiliationInConference(mConversation, mSelectedUser.getJid(), MucOptions.Affiliation.NONE, this);
                return true;
            case R.id.remove_admin_privileges:
                xmppConnectionService.changeAffiliationInConference(mConversation, mSelectedUser.getJid(), MucOptions.Affiliation.MEMBER, this);
                return true;
            case R.id.remove_from_room:
                removeFromRoom(mSelectedUser);
//                Log.i("RemoveFromGroup", "Selected User ---" + mSelectedUser);
                return true;
            case R.id.ban_from_conference:
//                Log.i("RemoveFromGroup", "ban_form_conference ---"+mSelectedUser.getJid());
                xmppConnectionService.changeAffiliationInConference(mConversation, mSelectedUser.getJid(), MucOptions.Affiliation.OUTCAST, this);
                xmppConnectionService.changeRoleInConference(mConversation, mSelectedUser.getName(), MucOptions.Role.NONE, this);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    // Removing Group member commented by Elumalai
    private void removeFromRoom(final User user) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.ban_from_conference);
        builder.setMessage(getString(R.string.removing_from_public_conference, user.getName()));
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.ban_now, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                xmppConnectionService.pushConferenceNotification(mConversation, user.getJid().toBareJid().getLocalpart() + " was removed ");
                if (mConversation.getMucOptions().membersOnly()) {
                    String param = "type=2&groupid=" + mConversation.getJid().toBareJid() + "&userslist=" + user.getJid().toBareJid();
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
//                    System.out.println("param::" + param);

                    //Removing Group member webServices call commented by Elumalai
//                    HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);

                    pd.show();
                    HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                    pd.dismiss();

                    xmppConnectionService.changeAffiliationInConference(mConversation, user.getJid(), MucOptions.Affiliation.NONE, ConferenceDetailsActivity.this);
                    xmppConnectionService.changeRoleInConference(mConversation, mSelectedUser.getName(), MucOptions.Role.NONE, ConferenceDetailsActivity.this);
                } else {

                    xmppConnectionService.changeAffiliationInConference(mConversation, user.getJid(), MucOptions.Affiliation.OUTCAST, ConferenceDetailsActivity.this);
                    xmppConnectionService.changeRoleInConference(mConversation, mSelectedUser.getName(), MucOptions.Role.NONE, ConferenceDetailsActivity.this);

                }
            }
        });
        builder.create().show();
    }

    protected void startConversation(User user) {
        if (user.getJid() != null) {
            Conversation conversation = xmppConnectionService.findOrCreateConversation(this.mConversation.getAccount(), user.getJid().toBareJid(), false);
            switchToConversation(conversation);
        }
    }

    protected void saveAsBookmark() {
        Account account = mConversation.getAccount();
        Bookmark bookmark = new Bookmark(account, mConversation.getJid().toBareJid());
        if (!mConversation.getJid().isBareJid()) {
            bookmark.setNick(mConversation.getJid().getResourcepart());
        }
        bookmark.setAutojoin(true);
        account.getBookmarks().add(bookmark);
        xmppConnectionService.pushBookmarks(account);
        mConversation.setBookmark(bookmark);
    }

    protected void deleteBookmark() {
        //added confirmation dialog by JOse.
        String ownerOrmember = "";
        if (deleteMsg.equals("Exit")) {
            ownerOrmember = " You are a member this group.\nDo you really want to " + deleteMsg + " group?\nYou will be removed from the group and the group will be removed from your group list";
        } else {
            ownerOrmember = " You are the owner of this group.\nDo you really want to " + deleteMsg + " and Exit the group?\nThe group will be removed the group list.";
        }
        new AlertDialog.Builder(this)

                .setTitle(deleteMsg + " Group")
                .setMessage(ownerOrmember)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {

                        Bookmark bkmrg = mConversation.getBookmark();
                        xmppConnectionService.archiveConversation(bkmrg.getConversation());
                        //xmppConnectionService.
                        System.out.println("bookmark.getConversation() ::" + bkmrg.getConversation());
                        //xmppConnectionService.databaseBackend.updateConversation(bookmark.getConversation());
                        bkmrg.unregisterConversation();
                        Account account = bkmrg.getAccount();
                        account.getBookmarks().remove(bkmrg);
                        xmppConnectionService.pushBookmarks(account);
//                        Log.i("Elumalai", "Please don't delete me!!!");
                        xmppConnectionService.pushConferenceNotification(mConversation, mConversation.getAccount().getJid().toBareJid().getLocalpart() + " has left ");
                        //below line added by Jose.
                        xmppConnectionService.leaveMuc(mConversation);
                        Intent returnIntent = new Intent();
                        setResult(RESULT_OK, returnIntent);
                        finish();
                    }
                })
                .setNegativeButton(android.R.string.no, null).show();
    }

    @Override
    void onBackendConnected() {
        if (mPendingConferenceInvite != null) {
            mPendingConferenceInvite.execute(this);
            mPendingConferenceInvite = null;
        }
        if (getIntent().getAction().equals(ACTION_VIEW_MUC)) {
            this.uuid = getIntent().getExtras().getString("uuid");
        }
        if (uuid != null) {
            this.mConversation = xmppConnectionService
                    .findConversationByUuid(uuid);
            if (this.mConversation != null) {
                Log.i("updateView", "onBackendConnected()");
                updateView();
            }
        }
    }

    //Function added by Jose.
    void getMucOfflineUsers() {
        if (mConversation != null) {
            //below code added by Jose.
            String param = "";
            mucOnlineUsers = "";

            for (final User user : mConversation.getMucOptions().getUsers()) {
                try {
                    mucOnlineUsers += URLEncoder.encode(user.getName(), "UTF-8") + "|" +  URLEncoder.encode(user.getJid().toBareJid().toString(), "UTF-8") + ",";
//                    Log.i("offlineuser", " mucOnlineUsers user.getName() --" + user.getName() + " ---user.getJid.toBareJid() ---" + user.getJid().toBareJid());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            User tempself = mConversation.getMucOptions().getSelf();
            if (tempself != null) {
                try {
                    mucOnlineUsers += URLEncoder.encode(tempself.getName(), "UTF-8") + "|" + URLEncoder.encode(tempself.getJid().toBareJid().toString(), "UTF-8") + ",";
//                    Log.i("offlineuser", "mucOnlineUsers -- getName and Jid.toBareJid --" + mucOnlineUsers);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            //System.out.println("Conference ID:"+mConversation.getContact().getJid().toBareJid());
            param = "type=3&groupid=" + mConversation.getContact().getJid().toBareJid() + "&userslist=" + mucOnlineUsers;
            //below two lines are added by Jose.
            //This is not advisable. Need to change this .
            // Add thread and call the webservice in another thread and pass the value to the UI through callback.

            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            System.out.println("offlineuser param::" + param);
//            mucOfflineUsers = HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
            pd.show();
            mucOfflineUsers = HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
            if (mucOnlineUsers != null) {
                pd.dismiss();
            }
            System.out.println("updateView offline users:" + mucOfflineUsers);
        }
         }

    class BitmapWorkerTask extends AsyncTask<Conversation, Void, Bitmap> {
        private final WeakReference<ImageView> imageViewReference;
        private Conversation conversation = null;

        public BitmapWorkerTask(ImageView imageView) {
            imageViewReference = new WeakReference<>(imageView);
        }

        @Override
        protected Bitmap doInBackground(Conversation... params) {
            return avatarService().get(params[0], getPixel(56));
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                final ImageView imageView = imageViewReference.get();
                if (imageView != null) {
                    imageView.setImageBitmap(bitmap);
                    imageView.setBackgroundColor(0x00000000);
                }
            }
        }
    }

    // Changed by Elumalai for avatar issue
    public void loadAvatar(Conversation conversation, ImageView imageView) {
        Bitmap bm = avatarService().get(conversation, getPixel(48), true);
        if (bm != null) {
            imageView.setImageBitmap(bm);
            imageView.setBackgroundColor(0x00000000);
        } else {
            if (conversation.getJid().toBareJid().toString().contains("_bc_")) {
                Drawable myDrawable = ConferenceDetailsActivity.this.getResources().getDrawable(R.drawable.bc_group);
                imageView.setImageDrawable(myDrawable);
            } else if (conversation.getJid().toBareJid().toString().contains("_ev_")) {
                Drawable myDrawable = ConferenceDetailsActivity.this.getResources().getDrawable(R.drawable.event_group);
                imageView.setImageDrawable(myDrawable);
            } else if (conversation.getJid().toBareJid().toString().contains("conference")) {
                Drawable myDrawable = ConferenceDetailsActivity.this.getResources().getDrawable(R.drawable.group);
                imageView.setImageDrawable(myDrawable);
            } else {
                Drawable myDrawable = ConferenceDetailsActivity.this.getResources().getDrawable(R.drawable.user_default);
                imageView.setImageDrawable(myDrawable);
            }
            /*else if (cancelPotentialWork(conversation, imageView)) {
            imageView.setBackgroundColor(UIHelper.getColorForName(conversation.getName()));
            final BitmapWorkerTask task = new BitmapWorkerTask(imageView);
            final AsyncDrawable asyncDrawable = new AsyncDrawable(getResources(), null, task);
            imageView.setImageDrawable(asyncDrawable);
            try {
                task.execute(conversation);
            } catch (final RejectedExecutionException ignored) {
            }*/
        }
    }

    public static boolean cancelPotentialWork(Conversation conversation, ImageView imageView) {
        final BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);

        if (bitmapWorkerTask != null) {
            final Conversation oldConversation = bitmapWorkerTask.conversation;
            if (oldConversation == null || conversation != oldConversation) {
                bitmapWorkerTask.cancel(true);
            } else {
                return false;
            }
        }
        return true;
    }

    private static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
        if (imageView != null) {
            final Drawable drawable = imageView.getDrawable();
            if (drawable instanceof AsyncDrawable) {
                final AsyncDrawable asyncDrawable = (AsyncDrawable) drawable;
                return asyncDrawable.getBitmapWorkerTask();
            }
        }
        return null;
    }

    static class AsyncDrawable extends BitmapDrawable {
        private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

        public AsyncDrawable(Resources res, Bitmap bitmap, BitmapWorkerTask bitmapWorkerTask) {
            super(res, bitmap);
            bitmapWorkerTaskReference = new WeakReference<>(bitmapWorkerTask);
        }

        public BitmapWorkerTask getBitmapWorkerTask() {
            return bitmapWorkerTaskReference.get();
        }
    }

    private void updateView() {
        pd.show();
        // to get the offlien users list from palscom server.
        getMucOfflineUsers();

        final MucOptions mucOptions = mConversation.getMucOptions();
        final User self = mucOptions.getSelf();
        Log.i("MUC", "self --" + self);
        mAccountJid.setText(getString(R.string.using_account, mConversation
                .getAccount().getJid().toBareJid()));
        mAccountJid.setVisibility(View.GONE);
        mYourPhoto.setImageBitmap(avatarService().get(mConversation.getAccount(), getPixel(48)));
        loadAvatar(mConversation, mGroupPhoto);
        setTitle(mConversation.getName().toString().toString().replace("_bc_", ""));
        //mFullJid.setText(mConversation.getJid().toBareJid().getLocalpart());
        mFullJid.setText(mConversation.getName().toString().toString().replace("_bc_", ""));
        //System.out.println();
//        System.out.println("MUC :: mConversation.getMucOptions().getSubject()--" + mConversation.getMucOptions().getSubject());
//        System.out.println("MUC Here is the subject:: mConversation.getName() --" + mConversation.getName());
        //mFullJid.setText(mConversation.getName());

        mYourNick.setText(mucOptions.getActualNick());
        mRoleAffiliaton = (TextView) findViewById(R.id.muc_role);
        if (mucOptions.online()) {
            mMoreDetails.setVisibility(View.VISIBLE);
            final String status = getStatus(self);
            Log.i("MUC", "Status form getStatus(self) ---" + status);
            if (status != null) {
                mRoleAffiliaton.setVisibility(View.VISIBLE);
                mRoleAffiliaton.setText(status);
            } else {
                mRoleAffiliaton.setVisibility(View.GONE);
            }
            if (mucOptions.membersOnly()) {
                mConferenceType.setText(R.string.private_conference);
            } else {
                mConferenceType.setText(R.string.public_conference);
            }
            if (self.getAffiliation().ranks(MucOptions.Affiliation.OWNER)) {
                mChangeConferenceSettingsButton.setVisibility(View.VISIBLE);
                deleteMsg = " Delete ";
            } else {
                mChangeConferenceSettingsButton.setVisibility(View.GONE);
            }
        }

        //added by Jose.
        //Temporarily remove the bublic/private conference options.
        // By default all the groups are private only.
        mConferenceType.setVisibility(View.GONE);
        mChangeConferenceSettingsButton.setVisibility(View.GONE);

        //added for broadcast.
        /*if(mConversation.getJid().toBareJid().toString().contains("_bc_"))
		{
			mConferenceType.setVisibility(View.GONE);
			mChangeConferenceSettingsButton.setVisibility(View.GONE);
		}
		*/
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        membersView.removeAllViews();
        final ArrayList<User> users = new ArrayList<>();
        Log.i("updateView", "user ---" + users);
        users.addAll(mConversation.getMucOptions().getUsers());
        Log.i("updateView", "mConversation.getMucOptions().getUsers() ---" + mConversation.getMucOptions().getUsers());

        Collections.sort(users, new Comparator<User>() {
            @Override
            public int compare(User lhs, User rhs) {
                return lhs.getName().compareToIgnoreCase(rhs.getName());
            }
        });

        //Code added by Jose. to add the offline users to the list.
        if (!mucOfflineUsers.trim().equalsIgnoreCase("")) {
            String contactList[];
            contactList = mucOfflineUsers.split(",");
            for (int i = 0; i < contactList.length; i++) {
                String temp = contactList[i].toString();
                System.out.println("updateView temp ---" + temp);
                final String[] contactJidNick = temp.split("\\|");
                int len = contactJidNick.length;
                if (len == 2) {
                    final User tempUser = mucOptions.getDummy();
                    try {
                        tempUser.setJid(Jid.fromString(contactJidNick[1].trim(), true));
                        Log.i("updateView", "contactJidNick[1].trim() ---" + contactJidNick[1].trim());
                    } catch (InvalidJidException e) {
                        e.printStackTrace();
                    }
					/*System.out.println("Nick"+contactJidNick[0].trim());
					System.out.println("ID" + contactJidNick[1].trim());*/
                    tempUser.setName(contactJidNick[0].trim());
                    Log.i("updateView", "setName(contactJidNick[0].trim()) ---" + contactJidNick[0].trim());
                    tempUser.setAffiliation("");
/*
					System.out.println("After setting the value is :" + tempUser.getJid());
					System.out.println("After setting the value is :" + tempUser.getName());*/
                    users.add(tempUser);
                }
            }
        }

        for (final User user : users) {
            pd.show();
            System.out.println("updateView Group Members::  user.getJid() --" + user.getJid());
            View view = inflater.inflate(R.layout.contact, membersView, false);
            this.setListItemBackgroundOnView(view);
            view.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Commented by Jose.
                    //Temporary change.
                    //highlightInMuc(mConversation, user.getName());
                }
            });
            registerForContextMenu(view);
            view.setTag(user);
            TextView tvDisplayName = (TextView) view.findViewById(R.id.contact_display_name);
            TextView tvKey = (TextView) view.findViewById(R.id.key);
            TextView tvStatus = (TextView) view.findViewById(R.id.contact_jid);
            if (mAdvancedMode && user.getPgpKeyId() != 0) {
                tvKey.setVisibility(View.VISIBLE);
                tvKey.setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        viewPgpKey(user);
                    }
                });
                tvKey.setText(OpenPgpUtils.convertKeyIdToHex(user.getPgpKeyId()));
            }
            Bitmap bm;
            Contact contact = user.getContact();
            if (contact != null) {
                bm = avatarService().get(contact, getPixel(48));
                tvDisplayName.setText(contact.getDisplayName());
                tvStatus.setText(user.getName() + " \u2022 " + getStatus(user));
            } else {
                bm = avatarService().get(user.getName(), getPixel(48));
                tvDisplayName.setText(user.getName());
                tvStatus.setText(getStatus(user));
            }
            ImageView iv = (ImageView) view.findViewById(R.id.contact_photo);
            iv.setImageBitmap(bm);
            membersView.addView(view);
            pd.dismiss();
            if (mConversation.getMucOptions().canInvite()) {
                mInviteButton.setVisibility(View.VISIBLE);
            } else {
                // Commented by Elumalai for Removing current user contact form group like whatsapp exit Group
                mInviteButton.setVisibility(View.GONE);
            }
        }
        pd.dismiss();
    }

    private String getStatus(User user) {
        if (mAdvancedMode) {
            StringBuilder builder = new StringBuilder();
            builder.append(getString(user.getAffiliation().getResId()));
            builder.append(" (");
            builder.append(getString(user.getRole().getResId()));
            builder.append(')');
            return builder.toString();
        } else {
            return getString(user.getAffiliation().getResId());
        }
    }

    @SuppressWarnings("deprecation")
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void setListItemBackgroundOnView(View view) {
        int sdk = android.os.Build.VERSION.SDK_INT;
        if (sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackgroundDrawable(getResources().getDrawable(R.drawable.greybackground));
        } else {
            view.setBackground(getResources().getDrawable(R.drawable.greybackground));
        }
    }

    private void viewPgpKey(User user) {
        PgpEngine pgp = xmppConnectionService.getPgpEngine();
        if (pgp != null) {
            PendingIntent intent = pgp.getIntentForKey(
                    mConversation.getAccount(), user.getPgpKeyId());
            if (intent != null) {
                try {
                    startIntentSenderForResult(intent.getIntentSender(), 0,
                            null, 0, 0, 0);
                } catch (SendIntentException ignored) {

                }
            }
        }
    }

    @Override
    public void onAffiliationChangedSuccessful(Jid jid) {

    }

    @Override
    public void onAffiliationChangeFailed(Jid jid, int resId) {
        displayToast(getString(resId, jid.toBareJid().toString()));
    }

    @Override
    public void onRoleChangedSuccessful(String nick) {
        displayToast("Successfully Removed..!");
        if (pd != null && pd.isShowing()) {
            pd.dismiss();
        }
    }

    @Override
    public void onRoleChangeFailed(String nick, int resId) {
        displayToast(getString(resId, nick));
        if (pd != null && pd.isShowing()) {
            pd.dismiss();
        }
    }

    @Override
    public void onPushSucceeded() {
        displayToast(getString(R.string.modified_conference_options));
        if (pd != null && pd.isShowing()) {
            pd.dismiss();
        }
    }

    @Override
    public void onPushFailed() {
        displayToast(getString(R.string.could_not_modify_conference_options));
        if (pd != null && pd.isShowing()) {
            pd.dismiss();
        }
    }

    private void displayToast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ConferenceDetailsActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
