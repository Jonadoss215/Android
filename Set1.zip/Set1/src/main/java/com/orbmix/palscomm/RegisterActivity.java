package com.orbmix.palscomm;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.orbmix.palscomm.ui.CountryPickerExample;
import com.orbmix.palscomm.utils.ConnectionDetector;
import com.orbmix.palscomm.utils.HttpCall;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public class RegisterActivity extends Activity {

    public Button btnSubmit;
    public TextView lblNote, lblCountryCode, lblPhone, lblPhoneCode;
    public TextView lblcountryname = null, countrylabel;
    public EditText txtPhone;
    public ImageView countryselectimage;
    public SharedPreferences preference;

    Context cont;
    String country;
    String userCountry;
    String countrydialcode;
    String content = null;
    String serviceReturn = "";

    public ArrayList<String> countrynamelist = new ArrayList<String>();
    // flag for Internet connection status
    Boolean isInternetPresent = false;
    // Connection detector class2
    ConnectionDetector cd;

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cont = this;
        preference = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        cd = new ConnectionDetector(getApplicationContext());

        LinearLayout myLayout = new LinearLayout(cont);
        myLayout.setPadding(10, 10, 10, 10);
        myLayout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout myLayoutPn = new LinearLayout(cont);
        myLayoutPn.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
        myLayoutPn.setOrientation(LinearLayout.HORIZONTAL);

        RelativeLayout myLayoutPn1 = new RelativeLayout(cont);
        myLayoutPn1.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));

        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, 5);

        RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        countrylabel = new TextView(cont);
        countrylabel.setPadding(0, 20, 0, 0);
        countrylabel.setWidth(200);
        countrylabel.setText("Country");
        countryselectimage = new ImageView(cont);
        String uri = "@drawable/selectcountry_images";

        int imageResource = getResources().getIdentifier(uri, null, getPackageName());
        Drawable res = getResources().getDrawable(imageResource);
        countryselectimage.setImageDrawable(res);
        countryselectimage.setPadding(100, 15, 15, 0);
        String localcountrypostalcode = GetCountryZipCode();

        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        String countryCode = tm.getNetworkCountryIso();
        Locale loc = new Locale("", countryCode);

        userCountry = loc.getDisplayCountry();
        countrydialcode = userCountry;
        lblcountryname = new TextView(cont);
        lblcountryname.setPadding(215, 20, 0, 0);

//      device local country is selected default
        lblcountryname.setText(countrydialcode);

        //** Button **//
        btnSubmit = new Button(cont);
        btnSubmit.setBackgroundResource(R.drawable.rounded_button);
        btnSubmit.setText("Register");
        btnSubmit.setTextColor(Color.WHITE);
        /** */
        lblNote = new TextView(cont);
        lblNote.setText("Palscom will send a one time SMS message to verify your phone number. Carrier SMS charges may apply");
        lblNote.setPadding(0, 20, 10, 0);
        // ** txtPhone *//
        lblCountryCode = new TextView(cont);
        lblCountryCode.setText("Please confirm your country code and enter your phone number");
        lblCountryCode.setPadding(0, 20, 10, 20);

        lblPhone = new TextView(cont);
        lblPhoneCode = new TextView(cont);
        lblPhoneCode.setPadding(0, 20, 50, 20);
        lblPhoneCode.setWidth(200);
        // Added by Elumalai
        lblPhoneCode.setText("+" + localcountrypostalcode);
        lblPhone.setText("Enter the Phone number");
        txtPhone = new EditText(cont);
        txtPhone.setInputType(InputType.TYPE_CLASS_PHONE);
        txtPhone.setHint("Mobile number");
        txtPhone.setPadding(10, 15, 0, 5);

        android.widget.LinearLayout.LayoutParams params = new android.widget.LinearLayout.LayoutParams(
                LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT, 1f);
        txtPhone.setLayoutParams(params);

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(11);
        txtPhone.setFilters(FilterArray);
        myLayoutPn.addView(lblPhoneCode);
        myLayoutPn.addView(txtPhone);

        countryselectimage.setLayoutParams(lp);
        lblcountryname.setLayoutParams(lp1);
        myLayoutPn1.addView(countrylabel);
        myLayoutPn1.addView(lblcountryname);
        myLayoutPn1.addView(countryselectimage);

        myLayout.addView(lblNote);
        myLayout.addView(lblCountryCode);
        myLayout.addView(myLayoutPn1);
        myLayout.addView(myLayoutPn);
        myLayout.addView(btnSubmit);
        // Button click Listener
        // addListenerOnButton();
        btnSubmit.setOnClickListener(this.mSubmitButtonListener);
        setContentView(myLayout);
        //System.out.println("Register activity22....");
        //System.out.println("userStatus1::"+preference.getBoolean("userStatus1",false));
        if (preference.getBoolean("userStatus1", false)) {
            Intent intent = new Intent(getBaseContext(), OtpActivity.class);
            intent.putExtra("UID", preference.getString("userId", null));
            startActivity(intent);
            finish();
        }

        //Elumalai onClickListener for country selection
        lblcountryname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, CountryPickerExample.class);
                intent.putExtra("RegisterActivity", "RegisterActivity");
                startActivityForResult(intent, 2);
            }
        });
        countryselectimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, CountryPickerExample.class);
                intent.putExtra("RegisterActivity", "RegisterActivity");
                startActivityForResult(intent, 2);
            }
        });
        myLayoutPn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, CountryPickerExample.class);
                intent.putExtra("RegisterActivity", "RegisterActivity");
                startActivityForResult(intent, 2);
            }
        });
    }

    // Function added by Elumalai for local country selected defult
    public String GetCountryZipCode() {
        String CountryID = "";
        String CountryZipCode = "";

        TelephonyManager manager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        //getNetworkCountryIso
        CountryID = manager.getSimCountryIso().toUpperCase();
        String[] rl = this.getResources().getStringArray(R.array.CountryCodes);
        for (int i = 0; i < rl.length; i++) {
            String[] g = rl[i].split(",");
            if (g[1].trim().equals(CountryID.trim())) {
                CountryZipCode = g[0];
                break;
            }
        }
        return CountryZipCode;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        System.out.println("Request code " + requestCode + "  Result code  " + resultCode + "  data  " + data);
        if (requestCode == 2) {

            if (resultCode == 2) {
                Bundle extras = data.getExtras();
                if (extras != null) {
//                    System.out.println("this is onActivity result");
                    String countryname = data.getStringExtra("NAME");
                    String countrycode = data.getStringExtra("CODE");
                    countrydialcode = data.getStringExtra("DIALCODE");
                    countrynamelist.clear();
                    countrynamelist.add(countryname);
                    lblcountryname.setText(countryname);
                    lblPhoneCode.setText(countrydialcode);
                            /*System.out.println("Country Name ---"+countryname);
                            System.out.println("Country Code ---"+countrycode);
                            System.out.println("Country Dial Code ---"+countrydialcode);*/
                }
            }
        }
    }


    public boolean PhoneNumberValidation(int fixNum, String countryName, String numberPatten) {

        if (txtPhone.getText().toString().trim().isEmpty()) {
            txtPhone.setError("Please Enter Your Phone Number");
            txtPhone.requestFocus();
            return true;
        } else if (!txtPhone.getText().toString().matches(numberPatten)) {
            if (txtPhone.getText().length() < fixNum) {
                txtPhone.setError("Phone number is Short : " + countryName);
                txtPhone.requestFocus();
                return true;
            } else if (txtPhone.getText().length() > fixNum) {
                txtPhone.setError("Phone number is Long : " + countryName);
                txtPhone.requestFocus();
                return true;
            }
        } else {
            if (txtPhone.getText().length() < fixNum) {
                txtPhone.setError("Phone number is Short : " + countryName);
                txtPhone.requestFocus();
                return true;
            } else if (txtPhone.getText().length() > fixNum) {
                txtPhone.setError("Phone number is Long : " + countryName);
                txtPhone.requestFocus();
                return true;
            }/*else {
                txtPhone.setError("Enter Valid Phone Number");
                txtPhone.requestFocus();
                return;
            }*/
        }
        return false;
    }

    protected OnClickListener mSubmitButtonListener = new OnClickListener() {
        @Override
        public void onClick(View v) {

            country = lblPhoneCode.getText().toString().trim();
            Log.i("countryDetails", "country code --" + country);
            String MobilePattern = null;
            int fixLength = 0;
            String countryName = null;
            String name = null;
            boolean result;
            switch (country) {
                case "+91":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    countryName = "INDIA";
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+93":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    countryName = "AFGHANISTAN";
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+355":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    countryName = "ALBANIA";
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+213":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Algeria";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+376":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Andorra";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+244":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Angola";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+672":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Antarctica";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+54":
                    MobilePattern = "[0-9]{10,12}";
                    fixLength = 11;
                    name = "Argentina";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+374":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Armenia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+297":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Aruba";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+61":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Australia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+43":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Austria";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+994":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Azerbaijan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+973":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Bahrain";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+880":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Bangladesh";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+375":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Belarus";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+32":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Belgium";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+501":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Belize";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+229":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Benin";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+975":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Bhutan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+591":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Bolivia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+387":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Bosnia-Herzegovina";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+267":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Botswana";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+55":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Bouvet Island";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+673":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Brunei Darussalam";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+359":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Bulgaria";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+226":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Burkina Faso";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+95":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Myanmar";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+257":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Burundi";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+855":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Cambodia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+237":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Cameroon";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Canada";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+238":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Cape Verde";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+236":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Central African Republic";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+235":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Chad";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+56":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Chile";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+86":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "China";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 869":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Saint Kitts & Nevis Anguilla";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 758":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Saint Lucia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 784":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Saint Vincent & Grenadines";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 868":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Trinidad and Tobago";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 649":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Turks and Caicos Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 284":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Virgin Islands (British)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 340":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Virgin Islands (USA)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+57"://66 error 2 times  Colombia
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Colombia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+269":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Comoros";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+242":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Congo";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+243":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Congo";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+682": // Cook Islands
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "Cook Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+506":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Croatia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+385":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Croatia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+53": //Cuba
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Cuba";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+357":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Cyprus";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+420":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Czech Rep.";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+45":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Denmark";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+253":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Djibouti";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+670":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Northern Mariana Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+593":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Ecuador";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+20":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Egypt";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+503":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "El Salvador";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+240":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Equatorial Guinea";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+291":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Eritrea";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+372":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Estonia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+251":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Ethiopia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+500":
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "Falkland Islands (Malvinas)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+298":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Faroe Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+679":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Fiji";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+358":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Finland";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+33":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 9;
                    name = "France";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+689":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Polynesia (French)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+241":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Gabon";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+220":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Gambia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+995":
                    MobilePattern = "[0-9]{9,10}";
                    fixLength = 8;
                    name = "Georgia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+49":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Germany";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+233":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Ghana";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+350":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Gibraltar";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+30":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Greece";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 876":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Jamaica";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 939":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Puerto Rico";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+299":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Greenland";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 664":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Montserrat";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+502":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Guatemala";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+224":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Guinea";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+245":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Guinea Bissau";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+592":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Guyana";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+509":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Haiti";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+504":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Honduras";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+852":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Hong Kong";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+36":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Hungary";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+62":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Indonesia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+98":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Iran";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+964":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Iraq";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+353":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Ireland";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+44":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "united kingdom";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+972":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Israel";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+39":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Italy";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+225":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Ivory Coast";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+81":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Japan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+962":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Jordan  ";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+7":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Russia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+254":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Kenya";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 684":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "americansamoa";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 264":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "americansamoa";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 268":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "antigula and barbuda";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 242":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "bahamas";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 246":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "barbados";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 441":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "bermuda";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+686":
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "Kiribati";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+965":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Kuwait";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+996":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Kyrgyzstan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+856":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Laos";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+371":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Latvia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+961":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Lebanon";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+266":
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "Lesotho";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+231":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Liberia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+218":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Libya";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+423":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Liechtenstein";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+370":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Lithuania";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+352":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Luxembourg";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+853":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 8;
                    name = "Macau";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+389":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Macedonia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+261":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Madagascar";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+265":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Malawi";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+60":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Malaysia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+960":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Maldives";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+223":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Mali";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+356":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Malta";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+692":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Marshall Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+222":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Mauritania";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+230":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Mauritius";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+262":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Reunion (Island)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+52":
                    MobilePattern = "[0-9]{10,12}";
                    fixLength = 11;
                    name = "Mexico";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+691":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Micronesia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+379":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Micronesia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+373":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Moldova";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+377":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Monaco";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+77":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Kazakhstan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+976":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Mongolia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+382":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Montenegro";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+212":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Morocco";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+258":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Mozambique";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+264":
                    MobilePattern = "[0-9]{10,12}";
                    fixLength = 11;
                    name = "Namibia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+674":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Nauru";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+977":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Nepal";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+31":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Netherlands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+599":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Netherlands Antilles";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+687":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "New Caledonia (French)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+64":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "New Zealand";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+505":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Nicaragua";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+227":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Niger";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+234":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Nigeria";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+683":
                    MobilePattern = "[0-9]{3,5}";
                    fixLength = 4;
                    name = "Niue";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+850":
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "Korea-North";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+47":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Norway";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+968":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Oman";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+92":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Pakistan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+680":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Palau";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+507":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Panama";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+675":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Papua New Guinea";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+595":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Paraguay";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+51":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Peru";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+63":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Philippines";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+870":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Bgan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+48":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Poland";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+351":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Portugal";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+974":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Qatar";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+40":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Romania";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+250":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Rwanda";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+590":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "French Antilles (Guadeloupe, St Barthelemy, St Martin)";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+685":
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "samoa";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+378":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "San Marino";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+239":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Sao Tome and Principe";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+966":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Saudi Arabia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+221":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Senegal";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+381":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Serbia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+248":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Seychelles";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+232":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Sierra Leone";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+65":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Singapore";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+421":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Slovakia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+386":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Slovenia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+677":
                    MobilePattern = "[0-9]{4,6}";
                    fixLength = 5;
                    name = "Solomon Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+252":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Somalia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+27":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "South Africa";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+82":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Korea-South";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+34":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Spain";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+345":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "cayman islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 767":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "dominica";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 849":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "dominican republic";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 671":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "guam";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+1 473":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Grenada";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+94":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 4;
                    name = "Sri Lanka";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+290":
                    MobilePattern = "[0-9]{3,5}";
                    fixLength = 4;
                    name = "Saint Helena";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+508":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Saint Pierre and Miquelon";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+249":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Sudan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+597":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Suriname";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+268":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Swaziland";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+46":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Sweden";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+41":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Switzerland";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+963":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Syria";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+886":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Taiwan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+992":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Tajikistan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+255":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Tanzania";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else

                        break;
                case "+66":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Thailand";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+228":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Togo";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+690":
                    MobilePattern = "[0-9]{3,5}";
                    fixLength = 4;
                    name = "Tokelau";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+676":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Tonga";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+216":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Tunisia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+90":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Turkey";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+993":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "Turkmenistan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+688":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Tuvalu";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+971":
                    MobilePattern = "[0-9]{7,9}";
                    fixLength = 8;
                    name = "United Arab Emirates";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+256":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Uganda";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+380":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Ukraine";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+598":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 8;
                    name = "Uruguay";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+998":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Uzbekistan";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+678":
                    MobilePattern = "[0-9]{6,8}";
                    fixLength = 7;
                    name = "Vanuatu";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+58":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Venezuela";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+84":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Vietnam";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+681":
                    MobilePattern = "[0-9]{5,7}";
                    fixLength = 6;
                    name = "Wallis and Futuna Islands";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+967":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Yemen";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+260":
                    MobilePattern = "[0-9]{9,11}";
                    fixLength = 10;
                    name = "Zambia";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                case "+263":
                    MobilePattern = "[0-9]{8,10}";
                    fixLength = 9;
                    name = "Zimbabwe";
                    countryName = name.toUpperCase();
                    result = PhoneNumberValidation(fixLength, countryName, MobilePattern);
                    if (result) {
                        return;
                    } else
                        break;
                default:
            }


            try {
                country = country.substring(1);
//            Log.i("countryDetails", "country.substring(1) --"+country);

                content = "user=" + URLEncoder.encode(txtPhone.getText().toString().trim(), "UTF-8") + "&type=" + URLEncoder.encode("1");
                content = content + "&countrycode=" + "+" + URLEncoder.encode(country, "UTF-8");
                content = content + "&country=" + URLEncoder.encode(countrydialcode.toString(), "UTF-8");

              /*System.out.println("user---"+txtPhone.getText().toString().trim());
                System.out.println("country code---"+country);
                System.out.println("country tostring--"+countrydialcode.toString());
                Log.i("RegisterActivity", "content ----"+content);*/
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //System.out.println("Registration params:"+content);

            isInternetPresent = cd.isConnectingToInternet();
            if (isInternetPresent) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                builder.setTitle(txtPhone.getText().toString());
                builder.setNegativeButton(R.string.cancel, null);
                builder.setMessage("We will send a verification code to this number via SMS.");
                builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        btnSubmit.setEnabled(false);
//                        WebServices webServices = new WebServices();
//                        serviceReturn = webServices.userRegistrationURL(content);
                        serviceReturn = HttpCall.webService(Config.USER_REGISTRATION_URI, content);
//                        Log.i("RegisterActivity", "webservices call parameter :" + content);
//                        Log.i("RegisterActivity", "webservices call return values :"+serviceReturn);

                        //Elumalai services return userStatus1 old user or account started
                        if (serviceReturn.equalsIgnoreCase("userStatus1")) {
                            preference.edit().putBoolean("userStatus1", true).commit();
                            preference.edit().putString("userId", "+" + country + txtPhone.getText().toString().trim()).commit();

                            Intent intent = new Intent(getBaseContext(), OtpActivity.class);
                            intent.putExtra("UID", "+" + country + txtPhone.getText().toString().trim());
                            intent.putExtra("New", false);
                            intent.putExtra("country", countrydialcode);/*spinner1.getSelectedItem().toString().trim()*/
                            intent.putExtra("countrycode", "+" + country);
                            intent.putExtra("user", txtPhone.getText().toString().trim());
                            startActivity(intent);
                            finish();
                            //Elumalai services return userStatus3 new user or account created
                        } else if (serviceReturn.equalsIgnoreCase("userStatus3")) {
                            preference.edit().putBoolean("userStatus1", true).commit();
                            preference.edit().putString("userId", "+" + country + txtPhone.getText().toString().trim()).commit();

                            Intent intent = new Intent(getBaseContext(), OtpActivity.class);
                            intent.putExtra("UID", "+" + country + txtPhone.getText().toString().trim());
                            intent.putExtra("New", true);
                            startActivity(intent);
                            finish();
                        }
                    }
                });
                builder.create().show();
            } else {
                // Internet connection is not present
                // Ask user to connect to Internet
                showAlertDialog(RegisterActivity.this, "No Internet Connection",
                        "You don't have internet connection.", false);
            }

        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.register, menu);
        return true;
    }

    /**
     * Function to display simple Alert Dialog
     *
     * @param context - application context
     * @param title   - alert dialog title
     * @param message - alert message
     * @param status  - success/failure (used to set icon)
     */
    public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);
        // Setting Dialog Message
        alertDialog.setMessage(message);
        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        // Showing Alert Message
        alertDialog.show();
    }

}