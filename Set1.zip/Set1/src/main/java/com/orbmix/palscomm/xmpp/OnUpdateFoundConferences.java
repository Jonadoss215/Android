package com.orbmix.palscomm.xmpp;

/**
 * Created by philip on 16.07.15.
 */
public interface OnUpdateFoundConferences {
    @SuppressWarnings("MethodNameSameAsClassName")
    void onUpdateFoundConferences();
}
