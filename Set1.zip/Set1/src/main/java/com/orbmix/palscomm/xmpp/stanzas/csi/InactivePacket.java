package com.orbmix.palscomm.xmpp.stanzas.csi;

import com.orbmix.palscomm.xmpp.stanzas.AbstractStanza;

public class InactivePacket extends AbstractStanza {
	public InactivePacket() {
		super("inactive");
		setAttribute("xmlns", "urn:xmpp:csi:0");
	}
}
