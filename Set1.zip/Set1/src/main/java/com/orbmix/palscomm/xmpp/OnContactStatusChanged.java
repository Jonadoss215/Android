package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Contact;

public interface OnContactStatusChanged {
	public void onContactStatusChanged(final Contact contact, final boolean online);
}
