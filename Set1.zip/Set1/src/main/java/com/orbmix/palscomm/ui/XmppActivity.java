package com.orbmix.palscomm.ui;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.Message;
import com.orbmix.palscomm.entities.MucOptions;
import com.orbmix.palscomm.services.AvatarService;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.services.XmppConnectionService.XmppConnectionBinder;
import com.orbmix.palscomm.utils.ExceptionHelper;
import com.orbmix.palscomm.utils.HttpCall;
import com.orbmix.palscomm.xmpp.OnUpdateBlocklist;
import com.orbmix.palscomm.xmpp.OnUpdateFavoritelist;
import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;

public abstract class XmppActivity extends Activity {

    protected static final int REQUEST_ANNOUNCE_PGP = 0x0101;
    protected static final int REQUEST_INVITE_TO_CONVERSATION = 0x0102;

    public XmppConnectionService xmppConnectionService;
    public boolean xmppConnectionServiceBound = false;
    protected boolean registeredListeners = false;

    ProgressDialog progressd;

    protected int mPrimaryTextColor;
    protected int mSecondaryTextColor;
    protected int mPrimaryBackgroundColor;
    protected int mSecondaryBackgroundColor;
    protected int mColorRed;
    protected int mColorOrange;
    protected int mColorGreen;
    protected int mPrimaryColor;

    protected boolean mUseSubject = true;

    private DisplayMetrics metrics;
    protected int mTheme;
    protected boolean mUsingEnterKey = false;

    private long mLastUiRefresh = 0;
    private Handler mRefreshUiHandler = new Handler();
    private Runnable mRefreshUiRunnable = new Runnable() {
        @Override
        public void run() {
            mLastUiRefresh = SystemClock.elapsedRealtime();
            refreshUiReal();
        }
    };

    protected ConferenceInvite mPendingConferenceInvite = null;
    public ProgressDialog pd;


    protected void refreshUi() {
        final long diff = SystemClock.elapsedRealtime() - mLastUiRefresh;
        if (diff > Config.REFRESH_UI_INTERVAL) {
            mRefreshUiHandler.removeCallbacks(mRefreshUiRunnable);
            runOnUiThread(mRefreshUiRunnable);
        } else {
            final long next = Config.REFRESH_UI_INTERVAL - diff;
            mRefreshUiHandler.removeCallbacks(mRefreshUiRunnable);
            mRefreshUiHandler.postDelayed(mRefreshUiRunnable, next);
        }
    }

    protected void refreshUiReal() {

    }
    ;

    protected interface OnValueEdited {
        public void onValueEdited(String value);
    }

    public interface OnPresenceSelected {
        public void onPresenceSelected();
    }

    protected ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            XmppConnectionBinder binder = (XmppConnectionBinder) service;
            xmppConnectionService = binder.getService();
            xmppConnectionServiceBound = true;
            if (!registeredListeners && shouldRegisterListeners()) {
                registerListeners();
                registeredListeners = true;
            }
            onBackendConnected();
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            xmppConnectionServiceBound = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        if (!xmppConnectionServiceBound) {
            connectToBackend();
        } else {
            if (!registeredListeners) {
                this.registerListeners();
                this.registeredListeners = true;
            }
            this.onBackendConnected();
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    protected boolean shouldRegisterListeners() {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return !isDestroyed() && !isFinishing();
        } else {
            return !isFinishing();
        }
    }

    public void connectToBackend() {
        Intent intent = new Intent(this, XmppConnectionService.class);
        intent.setAction("ui");
        startService(intent);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (xmppConnectionServiceBound) {
            if (registeredListeners) {
                this.unregisterListeners();
                this.registeredListeners = false;
            }
            unbindService(mConnection);
            xmppConnectionServiceBound = false;
        }
    }

    protected void hideKeyboard() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        View focus = getCurrentFocus();

        if (focus != null) {

            inputManager.hideSoftInputFromWindow(focus.getWindowToken(),
                    InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    public boolean hasPgp() {
        return xmppConnectionService.getPgpEngine() != null;
    }

    public void showInstallPgpDialog() {
        Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.openkeychain_required));
        builder.setIconAttribute(android.R.attr.alertDialogIcon);
        builder.setMessage(getText(R.string.openkeychain_required_long));
        builder.setNegativeButton(getString(R.string.cancel), null);
        builder.setNeutralButton(getString(R.string.restart),
                new OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (xmppConnectionServiceBound) {
                            unbindService(mConnection);
                            xmppConnectionServiceBound = false;
                        }
                        stopService(new Intent(XmppActivity.this,
                                XmppConnectionService.class));
                        finish();
                    }
                });
        builder.setPositiveButton(getString(R.string.install),
                new OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Uri uri = Uri
                                .parse("market://details?id=org.sufficientlysecure.keychain");
                        Intent marketIntent = new Intent(Intent.ACTION_VIEW,
                                uri);
                        PackageManager manager = getApplicationContext()
                                .getPackageManager();
                        List<ResolveInfo> infos = manager
                                .queryIntentActivities(marketIntent, 0);
                        if (infos.size() > 0) {
                            startActivity(marketIntent);
                        } else {
                            uri = Uri.parse("http://www.openkeychain.org/");
                            Intent browserIntent = new Intent(
                                    Intent.ACTION_VIEW, uri);
                            startActivity(browserIntent);
                        }
                        finish();
                    }
                });
        builder.create().show();
    }

    abstract void onBackendConnected();

    protected void registerListeners() {
        if (this instanceof XmppConnectionService.OnConversationUpdate) {
            this.xmppConnectionService.setOnConversationListChangedListener((XmppConnectionService.OnConversationUpdate) this);
        }
        if (this instanceof XmppConnectionService.OnAccountUpdate) {
            this.xmppConnectionService.setOnAccountListChangedListener((XmppConnectionService.OnAccountUpdate) this);
        }
        if (this instanceof XmppConnectionService.OnRosterUpdate) {
            this.xmppConnectionService.setOnRosterUpdateListener((XmppConnectionService.OnRosterUpdate) this);
        }
        if (this instanceof XmppConnectionService.OnMucRosterUpdate) {
            this.xmppConnectionService.setOnMucRosterUpdateListener((XmppConnectionService.OnMucRosterUpdate) this);
        }
        if (this instanceof OnUpdateBlocklist) {
            this.xmppConnectionService.setOnUpdateBlocklistListener((OnUpdateBlocklist) this);
        }
        // for favorite
        if (this instanceof OnUpdateFavoritelist) {
            this.xmppConnectionService.setOnUpdateFavoritelistListener((OnUpdateFavoritelist) this);
        }
    }

    protected void unregisterListeners() {
        if (this instanceof XmppConnectionService.OnConversationUpdate) {
            this.xmppConnectionService.removeOnConversationListChangedListener();
        }
        if (this instanceof XmppConnectionService.OnAccountUpdate) {
            this.xmppConnectionService.removeOnAccountListChangedListener();
        }
        if (this instanceof XmppConnectionService.OnRosterUpdate) {
            this.xmppConnectionService.removeOnRosterUpdateListener();
        }
        if (this instanceof XmppConnectionService.OnMucRosterUpdate) {
            this.xmppConnectionService.removeOnMucRosterUpdateListener();
        }
        if (this instanceof OnUpdateBlocklist) {
            this.xmppConnectionService.removeOnUpdateBlocklistListener();
        }
        // for favorite
        if (this instanceof OnUpdateFavoritelist) {
            this.xmppConnectionService.removeOnUpdateFavoritelistListener();
        }
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                startActivity(new Intent(this, SettingsActivity.class));
                break;
            case R.id.action_faq:
                startActivity(new Intent(this, FaqextendActivity.class));
                break;
            case R.id.action_accounts:
                startActivity(new Intent(this, ManageAccountActivity.class));
                break;
            case android.R.id.home:
                finish();
                break;
            case R.id.action_show_qr_code:
                showQrCode();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        metrics = getResources().getDisplayMetrics();
        ExceptionHelper.init(getApplicationContext());
        mPrimaryTextColor = getResources().getColor(R.color.primarytext);
        mSecondaryTextColor = getResources().getColor(R.color.secondarytext);
        mColorRed = getResources().getColor(R.color.red);
        mColorOrange = getResources().getColor(R.color.orange);
        mColorGreen = getResources().getColor(R.color.green);
        mPrimaryColor = getResources().getColor(R.color.primary);
        mPrimaryBackgroundColor = getResources().getColor(R.color.primarybackground);
        mSecondaryBackgroundColor = getResources().getColor(R.color.secondarybackground);

        this.mTheme = findTheme();
        setTheme(this.mTheme);
        this.mUsingEnterKey = usingEnterKey();
        mUseSubject = getPreferences().getBoolean("use_subject", true);
        final ActionBar ab = getActionBar();
        if (ab != null) {
            ab.setDisplayHomeAsUpEnabled(true);
        }

        pd = new ProgressDialog(XmppActivity.this);
        pd.setMessage("Please wait...");
        pd.setCancelable(false);
        pd.setIndeterminate(true);
    }

    protected boolean usingEnterKey() {
        return getPreferences().getBoolean("display_enter_key", false);
    }

    protected SharedPreferences getPreferences() {
        return PreferenceManager
                .getDefaultSharedPreferences(getApplicationContext());
    }

    public boolean useSubjectToIdentifyConference() {
        return mUseSubject;
    }

    public void switchToConversation(Conversation conversation) {
        switchToConversation(conversation, null, false);
    }

    public void switchToConversation(Conversation conversation, String text,
                                     boolean newTask) {
        switchToConversation(conversation, text, null, newTask);
    }

    public void highlightInMuc(Conversation conversation, String nick) {
        switchToConversation(conversation, null, nick, false);
    }

    private void switchToConversation(Conversation conversation, String text, String nick, boolean newTask) {
        Intent viewConversationIntent = new Intent(this,
                ConversationActivity.class);
        viewConversationIntent.setAction(Intent.ACTION_VIEW);
        viewConversationIntent.putExtra(ConversationActivity.CONVERSATION,
                conversation.getUuid());
        if (text != null) {
            viewConversationIntent.putExtra(ConversationActivity.TEXT, text);
        }
        if (nick != null) {
            viewConversationIntent.putExtra(ConversationActivity.NICK, nick);
        }
        viewConversationIntent.setType(ConversationActivity.VIEW_CONVERSATION);
        if (conversation.getJid().toBareJid().toString().contains("_ev_")) {
            viewConversationIntent.putExtra("event", true);
        }
        if (newTask) {
            viewConversationIntent.setFlags(viewConversationIntent.getFlags()
                    | Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        } else {
            viewConversationIntent.setFlags(viewConversationIntent.getFlags()
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        startActivity(viewConversationIntent);
        finish();
    }

    public void switchToContactDetails(Contact contact) {
        Intent intent = new Intent(this, ContactDetailsActivity.class);
        intent.setAction(ContactDetailsActivity.ACTION_VIEW_CONTACT);
        intent.putExtra("account", contact.getAccount().getJid().toBareJid().toString());
        intent.putExtra("contact", contact.getJid().toString());
        Log.i("contactdetails", "account --" + contact.getAccount().getJid().toBareJid().toString() + "---contacts --" + contact.getJid().toString());
        startActivity(intent);
    }

    public void switchToAccount(Account account) {
        Intent intent = new Intent(this, EditAccountActivity.class);
        intent.putExtra("jid", account.getJid().toBareJid().toString());
        startActivity(intent);
    }

    protected void inviteToConversation(Conversation conversation) {
        Intent intent = new Intent(getApplicationContext(),
                ChooseContactActivity.class);
        List<String> contacts = new ArrayList<>();
        if (conversation.getMode() == Conversation.MODE_MULTI) {
            for (MucOptions.User user : conversation.getMucOptions().getUsers()) {
                Jid jid = user.getJid();
                if (jid != null) {
                    Log.i("GroupUsers", "---" + jid.toBareJid().toString());
                    contacts.add(jid.toBareJid().toString());
                }
            }
        } else {
            Log.i("GroupUsers", "conversation jid--"+conversation.getJid().toBareJid().toString());
            contacts.add(conversation.getJid().toBareJid().toString());
        }
        intent.putExtra("filter_contacts", contacts.toArray(new String[contacts.size()]));
        intent.putExtra("conversation", conversation.getUuid());
        intent.putExtra("multiple", true);
        startActivityForResult(intent, REQUEST_INVITE_TO_CONVERSATION);
    }

    protected void announcePgp(Account account, final Conversation conversation) {
        xmppConnectionService.getPgpEngine().generateSignature(account,
                "online", new UiCallback<Account>() {

                    @Override
                    public void userInputRequried(PendingIntent pi,
                                                  Account account) {
                        try {
                            startIntentSenderForResult(pi.getIntentSender(),
                                    REQUEST_ANNOUNCE_PGP, null, 0, 0, 0);
                        } catch (final SendIntentException ignored) {
                        }
                    }

                    @Override
                    public void success(Account account) {
                        xmppConnectionService.databaseBackend
                                .updateAccount(account);
                        xmppConnectionService.sendPresence(account);
                        if (conversation != null) {
                            conversation
                                    .setNextEncryption(Message.ENCRYPTION_PGP);
                            xmppConnectionService.databaseBackend
                                    .updateConversation(conversation);
                        }
                    }

                    @Override
                    public void error(int error, Account account) {
                        displayErrorDialog(error);
                    }
                });
    }

    protected void displayErrorDialog(final int errorCode) {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(
                        XmppActivity.this);
                builder.setIconAttribute(android.R.attr.alertDialogIcon);
                builder.setTitle(getString(R.string.error));
                builder.setMessage(errorCode);
                builder.setNeutralButton(R.string.accept, null);
                builder.create().show();
            }
        });

    }

    protected void showAddToRosterDialog(final Conversation conversation) {
        showAddToRosterDialog(conversation.getContact());
    }

    protected void showAddToRosterDialog(final Contact contact) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(contact.getJid().toString());
        builder.setMessage(getString(R.string.not_in_roster));
        builder.setNegativeButton(getString(R.string.cancel), null);
        builder.setPositiveButton(getString(R.string.add_contact),
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final Jid jid = contact.getJid();
                        Account account = contact.getAccount();
                        Contact contact = account.getRoster().getContact(jid);
                        xmppConnectionService.createContact(contact);
                    }
                });
        builder.create().show();
    }

    private void showAskForPresenceDialog(final Contact contact) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(contact.getJid().toString());
        builder.setMessage(R.string.request_presence_updates);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.request_now,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (xmppConnectionServiceBound) {
                            xmppConnectionService.sendPresencePacket(contact
                                    .getAccount(), xmppConnectionService
                                    .getPresenceGenerator()
                                    .requestPresenceUpdatesFrom(contact));
                        }
                    }
                });
        builder.create().show();
    }

    private void warnMutalPresenceSubscription(final Conversation conversation,
                                               final OnPresenceSelected listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(conversation.getContact().getJid().toString());
        builder.setMessage(R.string.without_mutual_presence_updates);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.ignore, new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                conversation.setNextCounterpart(null);
                if (listener != null) {
                    listener.onPresenceSelected();
                }
            }
        });
        builder.create().show();
    }

    protected void quickEdit(String previousValue, OnValueEdited callback) {
        quickEdit(previousValue, callback, false);
    }

    protected void quickPasswordEdit(String previousValue,
                                     OnValueEdited callback) {
        quickEdit(previousValue, callback, true);
    }

    @SuppressLint("InflateParams")
    private void quickEdit(final String previousValue,
                           final OnValueEdited callback, boolean password) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.quickedit, null);
        final EditText editor = (EditText) view.findViewById(R.id.editor);
        OnClickListener mClickListener = new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                String value = editor.getText().toString();
                if (!previousValue.equals(value) && value.trim().length() > 0) {
                    callback.onValueEdited(value);
                }
            }
        };
        if (password) {
            editor.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            editor.setHint(R.string.password);
            builder.setPositiveButton(R.string.accept, mClickListener);
        } else {
            builder.setPositiveButton(R.string.edit, mClickListener);
        }
        editor.requestFocus();
        editor.setText(previousValue);
        builder.setView(view);
        builder.setNegativeButton(R.string.cancel, null);
        builder.create().show();
    }

    public void selectPresence(final Conversation conversation,
                               final OnPresenceSelected listener) {
        //if (conversation.getMode() == Conversation.MODE_MULTI ) {
        listener.onPresenceSelected();
        return;
        //}
        /*final Contact contact = conversation.getContact();
		if (conversation.hasValidOtrSession()) {
			SessionID id = conversation.getOtrSession().getSessionID();
			Jid jid;
			try {
				jid = Jid.fromString(id.getAccountID() + "/" + id.getUserID());
			} catch (InvalidJidException e) {
				jid = null;
			}
			conversation.setNextCounterpart(jid);
			listener.onPresenceSelected();
		} else 	if (!contact.showInRoster()) {
			showAddToRosterDialog(conversation);
		} else {
			Presences presences = contact.getPresences();
			if (presences.size() == 0) {
				if (!contact.getOption(Contact.Options.TO)
						&& !contact.getOption(Contact.Options.ASKING)
						&& contact.getAccount().getStatus() == Account.State.ONLINE) {
					showAskForPresenceDialog(contact);
				} else if (!contact.getOption(Contact.Options.TO)
						|| !contact.getOption(Contact.Options.FROM)) {
					warnMutalPresenceSubscription(conversation, listener);
				} else {
					conversation.setNextCounterpart(null);
					listener.onPresenceSelected();
				}
			} else if (presences.size() == 1) {
				String presence = presences.asStringArray()[0];
				try {
					conversation.setNextCounterpart(Jid.fromParts(contact.getJid().getLocalpart(),contact.getJid().getDomainpart(),presence));
				} catch (InvalidJidException e) {
					conversation.setNextCounterpart(null);
				}
				listener.onPresenceSelected();
			} else {
				final StringBuilder presence = new StringBuilder();
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setTitle(getString(R.string.choose_presence));
				final String[] presencesArray = presences.asStringArray();
				int preselectedPresence = 0;
				for (int i = 0; i < presencesArray.length; ++i) {
					if (presencesArray[i].equals(contact.lastseen.presence)) {
						preselectedPresence = i;
						break;
					}
				}
				presence.append(presencesArray[preselectedPresence]);
				builder.setSingleChoiceItems(presencesArray,
						preselectedPresence,
						new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								presence.delete(0, presence.length());
								presence.append(presencesArray[which]);
							}
						});
				builder.setNegativeButton(R.string.cancel, null);
				builder.setPositiveButton(R.string.ok, new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						try {
							conversation.setNextCounterpart(Jid.fromParts(contact.getJid().getLocalpart(),contact.getJid().getDomainpart(),presence.toString()));
						} catch (InvalidJidException e) {
							conversation.setNextCounterpart(null);
						}
						listener.onPresenceSelected();
					}
				});
				builder.create().show();
			}
		}*/
    }

    protected void onActivityResult(int requestCode, int resultCode,
                                    final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_INVITE_TO_CONVERSATION && resultCode == RESULT_OK) {
            //Added by Jose to confirm the user before adding users to the group.
            confirmUserAddition(data, this);

        }
    }

    //Function added by Jose.
    protected void confirmUserAddition(final Intent data, final XmppActivity obj) {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle(R.string.confirm);
        builder.setMessage(R.string.confirm_add_contact);
        builder.setPositiveButton(R.string.invite_contact, new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                mPendingConferenceInvite = ConferenceInvite.parse(data);
                Log.i("GroupUsers", "---" + mPendingConferenceInvite);
                if (xmppConnectionServiceBound && mPendingConferenceInvite != null) {
                    mPendingConferenceInvite.execute(obj);
                    mPendingConferenceInvite = null;
                }
            }
        });
        builder.create().show();
    }

    private UiCallback<Conversation> adhocCallback = new UiCallback<Conversation>() {
        @Override
        public void success(final Conversation conversation) {
            switchToConversation(conversation);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(XmppActivity.this, R.string.conference_created, Toast.LENGTH_LONG).show();
                }
            });
        }

        @Override
        public void error(final int errorCode, Conversation object) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(XmppActivity.this, errorCode, Toast.LENGTH_LONG).show();
                }
            });
        }

        @Override
        public void userInputRequried(PendingIntent pi, Conversation object) {

        }
    };

    public int getSecondaryTextColor() {
        return this.mSecondaryTextColor;
    }

    public int getPrimaryTextColor() {
        return this.mPrimaryTextColor;
    }

    public int getWarningTextColor() {
        return this.mColorRed;
    }

    public int getPrimaryColor() {
        return this.mPrimaryColor;
    }

    public int getOnlineColor() {
        return this.mColorGreen;
    }

    public int getPrimaryBackgroundColor() {
        return this.mPrimaryBackgroundColor;
    }

    public int getSecondaryBackgroundColor() {
        return this.mSecondaryBackgroundColor;
    }

    public int getPixel(int dp) {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        return ((int) (dp * metrics.density));
    }

    public boolean copyTextToClipboard(String text, int labelResId) {
        ClipboardManager mClipBoardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        String label = getResources().getString(labelResId);
        if (mClipBoardManager != null) {
            ClipData mClipData = ClipData.newPlainText(label, text);
            mClipBoardManager.setPrimaryClip(mClipData);
            return true;
        }
        return false;
    }

    protected void registerNdefPushMessageCallback() {
        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter != null && nfcAdapter.isEnabled()) {
            nfcAdapter.setNdefPushMessageCallback(new NfcAdapter.CreateNdefMessageCallback() {
                @Override
                public NdefMessage createNdefMessage(NfcEvent nfcEvent) {
                    return new NdefMessage(new NdefRecord[]{
                            NdefRecord.createUri(getShareableUri()),
                            NdefRecord.createApplicationRecord("com.orbmix.palscomm")
                    });
                }
            }, this);
        }
    }

    protected void unregisterNdefPushMessageCallback() {
        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter != null && nfcAdapter.isEnabled()) {
            nfcAdapter.setNdefPushMessageCallback(null, this);
        }
    }

    protected String getShareableUri() {
        return null;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.getShareableUri() != null) {
            this.registerNdefPushMessageCallback();
        }
    }

    protected int findTheme() {
        if (getPreferences().getBoolean("use_larger_font", false)) {
            return R.style.ConversationsTheme_LargerText;
        } else {
            return R.style.ConversationsTheme;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        this.unregisterNdefPushMessageCallback();
    }

    protected void showQrCode() {
        String uri = getShareableUri();
        if (uri != null) {
            Point size = new Point();
            getWindowManager().getDefaultDisplay().getSize(size);
            final int width = (size.x < size.y ? size.x : size.y);
            Bitmap bitmap = createQrCodeBitmap(uri, width);
            ImageView view = new ImageView(this);
            view.setImageBitmap(bitmap);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(view);
            builder.create().show();
        }
    }

    protected Bitmap createQrCodeBitmap(String input, int size) {
        Log.d(Config.LOGTAG, "qr code requested size: " + size);
        try {
            final QRCodeWriter QR_CODE_WRITER = new QRCodeWriter();
            final Hashtable<EncodeHintType, Object> hints = new Hashtable<>();
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
            final BitMatrix result = QR_CODE_WRITER.encode(input, BarcodeFormat.QR_CODE, size, size, hints);
            final int width = result.getWidth();
            final int height = result.getHeight();
            final int[] pixels = new int[width * height];
            for (int y = 0; y < height; y++) {
                final int offset = y * width;
                for (int x = 0; x < width; x++) {
                    pixels[offset + x] = result.get(x, y) ? Color.BLACK : Color.TRANSPARENT;
                }
            }
            final Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Log.d(Config.LOGTAG, "output size: " + width + "x" + height);
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
            return bitmap;
        } catch (final WriterException e) {
            return null;
        }
    }

    public static class ConferenceInvite {
        ConferenceDetailsActivity activity1 = new ConferenceDetailsActivity();
        private String uuid;
        private List<Jid> jids = new ArrayList<>();

        public static ConferenceInvite parse(Intent data) {
            ConferenceInvite invite = new ConferenceInvite();
            invite.uuid = data.getStringExtra("conversation");
            if (invite.uuid == null) {
                return null;
            }
            try {
                if (data.getBooleanExtra("multiple", false)) {
                    String[] toAdd = data.getStringArrayExtra("contacts");
                    for (String item : toAdd) {
                        invite.jids.add(Jid.fromString(item));
                    }
                } else {
                    invite.jids.add(Jid.fromString(data.getStringExtra("contact")));
                }
            } catch (final InvalidJidException ignored) {
                return null;
            }
            return invite;
        }

        // Adding Group member Commented by Elumalai
        public void execute(XmppActivity activity) {
            activity.pd.show();
            XmppConnectionService service = activity.xmppConnectionService;
            Conversation conversation = service.findConversationByUuid(this.uuid);
            if (conversation == null) {
                return;
            }
            if (conversation.getMode() == Conversation.MODE_MULTI) {
                String userslist = "";
                for (Jid jid : jids) {
                    System.out.println("GroupUsers Invitation comes  here::" + jid.toBareJid());
                    System.out.println("GroupUsers userid:" + jid.getLocalpart());
                    System.out.println("GroupUsers Conference id:" + conversation.getJid().toBareJid());
                    try {
                        userslist += URLEncoder.encode(jid.getLocalpart().toString(), "UTF-8") + "|" + URLEncoder.encode(jid.toBareJid().toString(), "UTF-8") + ",";
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    service.invite(conversation, jid);
                    activity.pd.dismiss();

					/*Message message = new Message(conversation, conversation.getAccount().getJid().toBareJid().getLocalpart() + " have added  "+jid.getLocalpart(), conversation.getNextEncryption(false));
					if (conversation.getNextCounterpart() != null)
					{
						message.setCounterpart(conversation.getNextCounterpart());
						message.setType(Message.TYPE_MUC_NOTIFICATION);
					}
					service.sendMessage(message);*/
                    if (!conversation.getContact().getJid().toBareJid().toString().contains("_bc_") && !conversation.getContact().getJid().toBareJid().toString().contains("_ev_")) {
                        service.pushConferenceNotification(conversation, conversation.getAccount().getJid().toBareJid().getLocalpart() + " have added  " + jid.getLocalpart());
                    }
                }

                // Adding Group member Commented by Elumalai
                String param = null;
                try {
                    param = "type=1&groupid=" + URLEncoder.encode(conversation.getContact().getJid().toBareJid().toString(), "UTF-8") + "&userslist=" + userslist;
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                System.out.println("param:: xmppActivity" + param);
//				HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                HttpCall.webService(Config.GROUP_MEMBERS_URI, param);


            } else {
                jids.add(conversation.getJid().toBareJid());
                service.createAdhocConference(conversation.getAccount(), jids, activity.adhocCallback);
                activity.pd.dismiss();
            }
        }
    }

    public AvatarService avatarService() {
        return xmppConnectionService.getAvatarService();
    }

    class BitmapWorkerTask extends AsyncTask<Message, Void, Bitmap> {
        private final WeakReference<ImageView> imageViewReference;
        private Message message = null;

        public BitmapWorkerTask(ImageView imageView) {
            imageViewReference = new WeakReference<>(imageView);
        }

        @Override
        protected Bitmap doInBackground(Message... params) {
            message = params[0];
            try {
                return xmppConnectionService.getFileBackend().getThumbnail(
                        message, (int) (metrics.density * 288), false);
            } catch (FileNotFoundException e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                final ImageView imageView = imageViewReference.get();
                if (imageView != null) {
                    imageView.setImageBitmap(bitmap);
                    imageView.setBackgroundColor(0x00000000);
                }
            }
        }
    }

    public void loadBitmap(Message message, ImageView imageView) {
        Bitmap bm;
        try {
            bm = xmppConnectionService.getFileBackend().getThumbnail(message,
                    (int) (metrics.density * 288), true);
        } catch (FileNotFoundException e) {
            bm = null;
        }
        if (bm != null) {
            imageView.setImageBitmap(bm);
            imageView.setBackgroundColor(0x00000000);
        } else {
            if (cancelPotentialWork(message, imageView)) {
                imageView.setBackgroundColor(0xff333333);
                final BitmapWorkerTask task = new BitmapWorkerTask(imageView);
                final AsyncDrawable asyncDrawable = new AsyncDrawable(getResources(), null, task);
                imageView.setImageDrawable(asyncDrawable);
                try {
                    task.execute(message);
                } catch (final RejectedExecutionException ignored) {
                }
            }
        }
    }

    public static boolean cancelPotentialWork(Message message,
                                              ImageView imageView) {
        final BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);

        if (bitmapWorkerTask != null) {
            final Message oldMessage = bitmapWorkerTask.message;
            if (oldMessage == null || message != oldMessage) {
                bitmapWorkerTask.cancel(true);
            } else {
                return false;
            }
        }
        return true;
    }

    private static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
        if (imageView != null) {
            final Drawable drawable = imageView.getDrawable();
            if (drawable instanceof AsyncDrawable) {
                final AsyncDrawable asyncDrawable = (AsyncDrawable) drawable;
                return asyncDrawable.getBitmapWorkerTask();
            }
        }
        return null;
    }

    static class AsyncDrawable extends BitmapDrawable {
        private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

        public AsyncDrawable(Resources res, Bitmap bitmap,
                             BitmapWorkerTask bitmapWorkerTask) {
            super(res, bitmap);
            bitmapWorkerTaskReference = new WeakReference<>(
                    bitmapWorkerTask);
        }

        public BitmapWorkerTask getBitmapWorkerTask() {
            return bitmapWorkerTaskReference.get();
        }
    }
}
