package com.orbmix.palscomm.xmpp.stanzas;

public class PresencePacket extends AbstractStanza {

	public PresencePacket() {
		super("presence");
	}
}
