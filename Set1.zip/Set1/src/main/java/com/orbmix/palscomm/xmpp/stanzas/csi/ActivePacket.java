package com.orbmix.palscomm.xmpp.stanzas.csi;

import com.orbmix.palscomm.xmpp.stanzas.AbstractStanza;

public class ActivePacket extends AbstractStanza {
	public ActivePacket() {
		super("active");
		setAttribute("xmlns", "urn:xmpp:csi:0");
	}
}
