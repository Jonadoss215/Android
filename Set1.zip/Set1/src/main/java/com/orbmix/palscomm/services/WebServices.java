package com.orbmix.palscomm.services;

import com.orbmix.palscomm.utils.HttpCall;
import com.orbmix.palscomm.Config;

/**
 * Created by Elumalai on 2/9/2016.
 */
public class WebServices {

    public WebServices(){
    }

    public String userRegistrationURL(String parameter){
        String content = parameter;
        final String result = null;
        HttpCall.webService(Config.USER_REGISTRATION_URI, content);
        return result;
    }
}
