package com.orbmix.palscomm.persistance;

public interface OnPhoneContactsMerged {
	public void phoneContactsMerged();
}
