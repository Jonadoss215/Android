package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.xmpp.stanzas.PresencePacket;

public interface OnPresencePacketReceived extends PacketReceived {
	public void onPresencePacketReceived(Account account, PresencePacket packet);
}
