package com.orbmix.palscomm.xmpp.jingle;

import com.orbmix.palscomm.entities.DownloadableFile;

public interface OnFileTransmissionStatusChanged {
	public void onFileTransmitted(DownloadableFile file);

	public void onFileTransferAborted();
}
