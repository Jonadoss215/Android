package com.orbmix.palscomm.entities;

import com.orbmix.palscomm.xmpp.jid.Jid;

/**
 * Created by Elumalai on 12/30/2015.
 */
public interface Favorite {

    public boolean isFavorite();
    public boolean isDomainFavorite();
    public Jid getFavoriteJid();
    public Jid getJid();
    public Account getAccount();
    public String getName();
}
