package com.orbmix.palscomm.utils;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class HttpCall{

	public HttpCall() {
	 	   //super("ImageUpload");
	}
	
	public static String webService(String url, String content)
		{
		 HttpURLConnection conn = null;
		 int responceCode=-1;
		 String tempstr ="";
		 try
		 {
			 	//System.out.println("webService:: "+content+","+url);
	        	conn = (HttpURLConnection)new URL(url).openConnection();
	            conn.setRequestMethod("POST");
//			 conn.setRequestMethod("GET");
	            conn.setDoInput(true);
	            conn.setDoOutput(true);
				conn.connect();
				conn.setConnectTimeout(10000); //set timeout to 10 seconds
				
				
				/*String content = "email=" 	+ 	URLEncoder.encode(LocalStore.get("login"), "UTF-8") +
								 "&pwd=" 	+	URLEncoder.encode(LocalStore.get("pass"), "UTF-8");
								 */

				//System.out.println("mail deials :: "+content);
				DataOutputStream output = null;
				output = new DataOutputStream(conn.getOutputStream());

				output.writeBytes(content);
				//output.flush();
				//output.close();
				
				
	            responceCode = conn.getResponseCode();
	            BufferedInputStream in;
	            in = new BufferedInputStream(conn.getInputStream(), 8192);

	            byte [] buffer = new byte[8192];
	            int read;
	            while ((read = in.read(buffer)) != -1)
	            {
	                tempstr = new String(buffer, 0, read);
	               // System.out.println(tempstr);
	            }
				
	            //System.out.println("responceCode :: "+responceCode);
	            if(tempstr.equals(""))
	            	tempstr = "-5";
	            return tempstr;
		 }catch (Exception e) {
		      e.printStackTrace();
		    }
         return "-1";
	}
} 
		 

	
