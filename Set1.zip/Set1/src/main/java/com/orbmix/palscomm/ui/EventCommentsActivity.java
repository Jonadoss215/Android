package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.ui.adapter.MessageAdapter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Elumalai on 8/8/2015.
 */
public class EventCommentsActivity extends Activity {

    Conversation mconversation;
    ImageView img;
    Bitmap bitmap;
    ProgressDialog pDialog;

    XmppConnectionService xmppConnectionService;
    private EditMessage mEditMessage;
    private ImageButton mSendButton;
    private ListView listviewmessage;

    private String messageid = null;
    private String eventname = null;
    private String message = null;
    private String user = null;
    private String timesent = null;
    private String accountuser = null;

    private TextView commentname;
    private TextView commentstime;
    private TextView commentsbody;
    private TextView eventgroup;
    private ImageView commentimage;

    private static final String EVENT_ID = "id";
    private static final String EVENT_MESSAGE_ID = "event_msg_id";
    private static final String COMMENTD = "comments";
    private static final String COMMENTS_BY = "commented_by";
    private static final String COMMENTS_ON = "commented_on";

    SimpleAdapter adapter;
    HashMap<String, String> map;
    ArrayList<HashMap<String, String>> alist;
    String text;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message_event_comments);
        listviewmessage = (ListView) findViewById(R.id.messages_event_view);
        mEditMessage = (EditMessage) findViewById(R.id.textinput);
        mSendButton = (ImageButton) findViewById(R.id.textSendButton);
        commentname = (TextView) findViewById(R.id.message_user);
        commentstime = (TextView) findViewById(R.id.message_time);
        commentsbody = (TextView) findViewById(R.id.message_body);
        commentimage = (ImageView) findViewById(R.id.message_image);
        eventgroup = (TextView) findViewById(R.id.event_group_name);

        Bundle extras = getIntent().getExtras();
        if(extras != null)
        {
            messageid = extras.getString("messageid");
            eventname = extras.getString("eventname");
            message = extras.getString("message");
            user = extras.getString("user");
            timesent = extras.getString("time");
            accountuser = extras.getString("accountuser");
            String image = extras.getString("imageparameter");
//            Log.i("Elumalai", "image parameter :"+image);
            if(image.contains("null")){

//                Log.i("Elumalai","i am text Event");
                commentimage.setVisibility(View.GONE);
                commentsbody.setText(message);
            }else {
//                Log.i("Elumalai", "i am image Event");
                new LoadImage().execute(image);
            }

/*          System.out.println("message uuid :"+messageid);
            System.out.println("user name :"+eventname);
            System.out.println("mesage body :"+message);
            System.out.println("user name :"+user);
            System.out.println("comment time :"+timesent);
            System.out.println("accountuser  :"+accountuser);*/

            commentname.setText(user);
            commentstime.setText(timesent);
            eventgroup.setText(eventname);
        }
        alist = new ArrayList<HashMap<String, String>>();
        adapter = new SimpleAdapter(this, alist, R.layout.message_event_commentslist, new String[]{"message","timesent","messager_name"}, new int[]{R.id.message_body, R.id.message_time,R.id.messager_name});
        listviewmessage.setAdapter(adapter);
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(mEditMessage.getText().toString().trim().length()>0)
                    addRow(view);
            }
        });
        //new ExecuteTask().execute();
        String type = "2";
        String commentson = "0";
        AsyncTask<String, Integer, String> data = new ExecuteTask().execute(type, messageid, commentson,"","");
        getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void addRow(View view) {
        // HashMap for data values of each row
        map = new HashMap<String, String>();
        map.put("message", mEditMessage.getText().toString());
        String dt = ""+DateFormat.getDateTimeInstance().format(new Date());

        map.put("timesent", dt);
        map.put("messager_name", accountuser);
        alist.add(map);

        AsyncTask<String, Integer, String> data = new ExecuteTask().execute("1", messageid, dt,mEditMessage.getText().toString(),accountuser);
        mEditMessage.setText("");
        // Notify the ListView of data changed
        adapter.notifyDataSetChanged();

    }
    public void addListRow(String strJson)
    {
        try {
            //JSONObject jsonRootObject = new JSONObject(strJson);
            JSONArray jsonArray = new JSONArray(strJson);
            for(int i=0; i < jsonArray.length(); i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String id = jsonObject.optString("id").toString();
                String name = jsonObject.optString("event_msg_id").toString();
                String message = jsonObject.optString("comments").toString();
                String commented_by = jsonObject.optString("commented_by").toString();
                String commented_on = jsonObject.optString("commented_on").toString();
                map = new HashMap<String, String>();
                map.put("message", message);
                map.put("timesent", commented_on);
                map.put("messager_name", commented_by);
                alist.add(map);
            }
            adapter.notifyDataSetChanged();
        }
        catch (JSONException e) {e.printStackTrace();}


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    class ExecuteTask extends AsyncTask<String, Integer, String>
    {

        @Override
        protected String doInBackground(String... params) {

            String res=PostData(params);

            return res;
        }

        @Override
        protected void onPostExecute(String result) {

            //progess_msz.setVisibility(View.GONE);
            // Toast.makeText(getApplicationContext(), result, 3).show();
        }

    }

    public String PostData(String[] values) {
        String s="";
        try
        {
            HttpClient httpClient=new DefaultHttpClient();
//            HttpPost httpPost=new HttpPost("http://palscom.com/ws/comments.php");
            HttpPost httpPost=new HttpPost(Config.COMMENTS_URI);

            List<NameValuePair> list=new ArrayList<NameValuePair>();
            list.add(new BasicNameValuePair("type", values[0]));
            list.add(new BasicNameValuePair("event_msg_id", values[1]));
            list.add(new BasicNameValuePair("commented_on",  values[2]));
            list.add(new BasicNameValuePair("comments",  values[3]));
            list.add(new BasicNameValuePair("commented_by",  values[4]));
            httpPost.setEntity(new UrlEncodedFormEntity(list));
            HttpResponse httpResponse=  httpClient.execute(httpPost);

            HttpEntity httpEntity=httpResponse.getEntity();
            s= readResponse(httpResponse);
            //System.out.println("Postdata returns: "+s);
            if(!s.equals("{\"status\":\"OK\"}"))
                addListRow(s);

        }
        catch(Exception exception)  {}
       // System.out.println("Elumalai post data:>>>>>" +s);
        return s;


    }
    public String readResponse(HttpResponse res) {
        InputStream is=null;
        String return_text="";
        try {
            is=res.getEntity().getContent();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(is));
            String line="";
            StringBuffer sb=new StringBuffer();
            while ((line=bufferedReader.readLine())!=null)
            {
                sb.append(line);
            }
            return_text=sb.toString();
        } catch (Exception e)
        {

        }
      //  System.out.println("Elumalai readresponse:>>>>> " +return_text);
        return return_text;

    }

    private class LoadImage extends AsyncTask<String, String, Bitmap> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(EventCommentsActivity.this);
            pDialog.setMessage("Loading Image ....");
            pDialog.show();

            }
        protected Bitmap doInBackground(String... args) {
            try {
                bitmap = BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

                } catch (Exception e) {
                e.printStackTrace();
                }
            return bitmap;
            }

                protected void onPostExecute(Bitmap image) {

            if(image != null){
                commentimage.setVisibility(View.VISIBLE);
                commentimage.setImageBitmap(image);
                pDialog.dismiss();

                }else{

                pDialog.dismiss();
                Toast.makeText(EventCommentsActivity.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();

                }
            }
        }

}

