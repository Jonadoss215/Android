package com.orbmix.palscomm.ui;

/**
 * Created by Elumalai on 7/1/2015.
 */

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.Toast;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.ui.adapter.ExpandableList;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FaqextendActivity extends Activity {

    List<String> groupList;
    List<String> childList;
    Map<String, List<String>> faqCollection;
    ExpandableListView expListView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faqs);

        /*if (getActionBar() != null) {
            getActionBar().setHomeButtonEnabled(true);
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }*/

        createGroupList();
        createCollection();

        expListView = (ExpandableListView) findViewById(R.id.laptop_list);
        final ExpandableList expListAdapter = new ExpandableList(
                this, groupList, faqCollection);
        expListView.setAdapter(expListAdapter);

        setGroupIndicatorToRight();

        expListView.setOnChildClickListener(new OnChildClickListener() {

            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                final String selected = (String) expListAdapter.getChild(
                        groupPosition, childPosition);
                Toast.makeText(getBaseContext(),"faqoptions" + selected, Toast.LENGTH_LONG)
                        .show();

                return true;
            }
        });

        getActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
               finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void createGroupList() {
        groupList = new ArrayList<String>();
        groupList.add("How to block a contact?");
        groupList.add("Do I need to add contacts manually?");
        groupList.add("How to share messages/images with other contact/groups or other apps?");
      /*  groupList.add("Verifying your phone number in palscom?");
        groupList.add("How to reinstall palscom?");*/
        groupList.add("How to change the profile picture");
        groupList.add("How to delete a contact?");
        // groupList.add("How to register?");
        groupList.add("How to delete chat message?");
        groupList.add("How to send voice messages?");


    }

    private void createCollection() {
        // preparing laptops collection(child);
        String[] question1 = { "You can stop receiving palscon messages form a contact by blocking them. \n" +
                "\n" +
                "To block a contact do the following steps:\n" +
                "\n" +
                "1. Go to your Chat screen.\n" +
                "2. Click on menu -> Choose Contact Details >\n" +
                "3. Again Click menu -> Block contact\n" +
                "\n" +
                "\t You can not send messages to the blocked contact and vice versa.\n" +
                "\n" +
                " If you want to send the message to the blocked contact you need to unblock the contact.\n" +
                "\n" };
        /*String[] hclModels = { "palscom will send a one time SMS message to verify your phone number.\n" +
                "\n" +
                "select country and enter phone number\n" +
                "\n" +
                "Having trouble veritying plascom on your phone? We have step by step instructions for you:\n" +
                "\n" +
                "1. Check that you entered the correct phone number for your phone. This importent!\n" +
                "\n" +
                "  \n" +
                "2. make sure that you have an internet connection Wi-Fi, cellular data, 3G or EDGD service. if you are roaming, verification may not work correctly.\n" +
                "\n" +
                "3. Reboot your phone.\n" };*/
        String[] question4 = { "To change the profile picture.\n" +
                "\n" +
                "1. Go to menu, seleclt manage accounts option.\n" +
                "\n" +
                "2. Click on your account list ( Mobile number/profile image).\n" +
                "\n" +
                "3. Another window will be open up with profile picture.\n" +
                "\n" +
                "4. Click on profile picture, to change it.\n" +
                "\n" +
                "Note: If you don't want the new picture and wants to reset to old picture, long press the profile picture and it will reset to old picture.\n" };
        String[] question3 = { "To share images/videos/files to the contact/group or to the other messenger \n" +
                "\n" +
                "1. Long press on the message. Popup menu will appear. Choose the sharewith option and select the contact/group or another.\n" +
                "2. To copy a message, long press the message and copy text option will come. The text message will be copied and available for sharing.\n" };
        String[] question2 = { "If any of your friends are already using Palscom their contacts will be automatically to the palscom. \n" +
                "\n" +
                "If any new contact is being added in the android contact book, it would be automatically pulled from android contact and saved in the Palscom contacts .\n" +
                "Also, there is another option Palscom offers is that, without being added into the android's contact you can add the user from Palscom app itself.\n" +
                "\n" +
                "To add the user in the app .\n" +
                "\n" +
                "Click the + icon from the home screen. Go the contact's tab. Click the add user icon on top.\n" +
                "Create contact's popup will be opened up. Enter the contact's details and save.\n" +
                "These contacts will not be added into the Android's contacts list but only in the app's contacts.\n" };
        /*String[] samsungModels = {"Uninstalling palscom:\n" +
                "\n" +
                "1. Go to device Setting >Application >palscom >Uninstall.\n" +
                "\n" +
                "2. Reboot your phone\n"};*/
        String[] delectcontact = {"To delete a contact from Palscom contact's list.\n" +
                "\n" +
                "\n" +
                "1. You can delete the contact from contact list screen by long pressing the contact and selecting the option 'delete contact'.\n" +
                "\n" +
                "2. You can also, delete the contact from contacts detail page by clicking the delete icon on top of the page.\n"};

        /*String[] registe_otb = {"Having trouble veritying plascom on your phone? We have step by step instructions for you:\n" +
                "\n" +
                "1. Check that you entered the correct phone number for your phone. This importent!\n" +
                "\n" +
                "  \n" +
                "2. make sure that you have an internet connection Wi-Fi, cellular data, 3G or EDGD service. if you are roaming, verification may not work correctly.\n" +
                "3. Reboot your phone.\n" +
                "\n" +
                "4. Delete and reinstall to the latest version of the app.\n" +
                "\n" +
                "5. Send a test SMS message from your phone, to your phone number exactly as it appears inside palscom.\n" +
                "\n" +
                "6. if your SMS really show in your phone.\n"};*/
        String[] deletemessage = {" You can delete entire chat messages or a particular chat message.\n" +
                "\n" +
                "1. To delete a single message, long press on the message and choose the 'delete message' option to delete the message.\n" +
                "\n" +
                "2. To delete entire conversations click the menu icon from chat window and choose the menu option 'Clear history' to delete all the messages .\n" };
        String[] voicemessage = {"Voice messaging allows you to instantly communicate with a contact or group chat. It provides an enriching chat experience, and you can account on it to deliver important and time sensitive messages.\n" +
                "\n" +
                " To Send a Voice message\n" +
                "\n" +
                "1. Click on the attachment icon, its show a list.\n" +
                "\n" +
                "2. Click on that Record voice, Record voice messages from native android's voice recorder.\n" +
                "\n" +
                "3. Once done recording click 'done' from the voice recorder, Palscom will ask the confirmation before sending the file.\n"};

        faqCollection = new LinkedHashMap<String, List<String>>();

        for (String faq : groupList) {
            if (faq.equals("How to block a contact?")) {
                loadChild(question1);
            }
            else if (faq.equals("Do I need to add contacts manually?"))
                loadChild(question2);
            else if (faq.equals("How to share messages/images with other contact/groups or other apps?"))
                loadChild(question3);
          /*  else if (faq.equals("Veritying your phone number in palscom?"))
                loadChild(hclModels);
            else if (faq.equals("How to reinstall palscom?"))
                loadChild(samsungModels);*/
            else if (faq.equals("How to change the profile picture"))
                loadChild(question4);
            else if(faq.equals("How to delete a contact?"))
                loadChild(delectcontact);
           /* else if(faq.endsWith("How to register and otp?"))
                loadChild(registe_otb);*/
            else if(faq.equals("How to delete chat message?"))
                loadChild(deletemessage);
            else if(faq.equals("How to send voice messages?"))
                loadChild(voicemessage);
            faqCollection.put(faq, childList);
        }
    }



    private void loadChild(String[] questions) {
        childList = new ArrayList<String>();
        for (String faquest : questions)
            childList.add(faquest);
    }

    private void setGroupIndicatorToRight() {
        /* Get the screen width */
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;

        expListView.setIndicatorBounds(width - getDipsFromPixel(35), width
                - getDipsFromPixel(5));
    }

    // Convert pixel to dip
    public int getDipsFromPixel(float pixels) {
        // Get the screen's density scale
        final float scale = getResources().getDisplayMetrics().density;
        // Convert the dps to pixels, based on density scale
        return (int) (pixels * scale + 0.5f);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.faq, menu);
        return true;
    }
}

