package com.orbmix.palscomm.fragments;

import android.os.Bundle;
import android.preference.PreferenceFragment;

import com.orbmix.palscomm.R;

public class SettingsFragment extends PreferenceFragment {

	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		addPreferencesFromResource(R.xml.settings);
	}
}
