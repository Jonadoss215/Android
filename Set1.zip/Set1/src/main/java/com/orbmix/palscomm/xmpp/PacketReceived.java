package com.orbmix.palscomm.xmpp;

public abstract interface PacketReceived {

}
