package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;

public interface OnStatusChanged {
	public void onStatusChanged(Account account);
}
