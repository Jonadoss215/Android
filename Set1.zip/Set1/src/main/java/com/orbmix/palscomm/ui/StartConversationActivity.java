package com.orbmix.palscomm.ui;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.ActionBar.TabListener;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.provider.ContactsContract;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Blockable;
import com.orbmix.palscomm.entities.Bookmark;
import com.orbmix.palscomm.entities.Contact;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.ListItem;
import com.orbmix.palscomm.entities.Presences;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.services.XmppConnectionService.OnRosterUpdate;
import com.orbmix.palscomm.ui.adapter.ListItemAdapter;
import com.orbmix.palscomm.utils.ConnectionDetector;
import com.orbmix.palscomm.utils.HttpCall;
import com.orbmix.palscomm.utils.XmppUri;
import com.orbmix.palscomm.xmpp.OnUpdateBlocklist;
import com.orbmix.palscomm.xmpp.XmppConnection;
import com.orbmix.palscomm.xmpp.jid.InvalidJidException;
import com.orbmix.palscomm.xmpp.jid.Jid;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class StartConversationActivity extends XmppActivity implements OnRosterUpdate, OnUpdateBlocklist, XmppConnectionService.OnConferenceOptionsPushed {

    public int conference_context_id;
    public int contact_context_id;
    public int broadcast_context_id;

    private Tab mContactsTab;
    private Tab mConferencesTab;
    private Tab mBroadCastTab;

    private ViewPager mViewPager;
    private MyListFragment mContactsListFragment = new MyListFragment();
    private List<ListItem> contacts = new ArrayList<>();
    private List<String> usercontactlistP = new ArrayList<String>();
    private List<String> Phonecontactlist = new ArrayList<String>();
    private ArrayAdapter<ListItem> mContactsAdapter;

    private MyListFragment mConferenceListFragment = new MyListFragment();
    private List<ListItem> conferences = new ArrayList<ListItem>();
    private ArrayAdapter<ListItem> mConferenceAdapter;

    private MyListFragment mBroadcastListFragment = new MyListFragment();
    private List<ListItem> broadcast = new ArrayList<ListItem>();
    private ArrayAdapter<ListItem> mBroadcastAdapter;

    private List<String> mActivatedAccounts = new ArrayList<String>();
    private List<String> mKnownHosts;
    private List<String> mKnownConferenceHosts;
    private Invite mPendingInvite = null;
    private Menu mOptionsMenu;
    private EditText mSearchEditText;

    String[] countryCode;
    private TextView tCountryCode = null;
    TextView countrylist;
    String countrydialcode;
    private MenuItem.OnActionExpandListener mOnActionExpandListener = new MenuItem.OnActionExpandListener() {

        @Override
        public boolean onMenuItemActionExpand(MenuItem item) {
            mSearchEditText.post(new Runnable() {

                @Override
                public void run() {
                    mSearchEditText.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(mSearchEditText,
                            InputMethodManager.SHOW_IMPLICIT);
                }
            });

            return true;
        }

        @Override
        public boolean onMenuItemActionCollapse(MenuItem item) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mSearchEditText.getWindowToken(),
                    InputMethodManager.HIDE_IMPLICIT_ONLY);
            mSearchEditText.setText("");
            filter(null);
            return true;
        }
    };
    private boolean mHideOfflineContacts = false;
    private TabListener mTabListener = new TabListener() {

        @Override
        public void onTabUnselected(Tab tab, FragmentTransaction ft) {
            return;
        }

        @Override
        public void onTabSelected(Tab tab, FragmentTransaction ft) {
            mViewPager.setCurrentItem(tab.getPosition());
            onTabChanged();
        }

        @Override
        public void onTabReselected(Tab tab, FragmentTransaction ft) {
            return;
        }
    };
    private ViewPager.SimpleOnPageChangeListener mOnPageChangeListener = new ViewPager.SimpleOnPageChangeListener() {
        @Override
        public void onPageSelected(int position) {
            if (getActionBar() != null) {
                getActionBar().setSelectedNavigationItem(position);
            }
            onTabChanged();
        }
    };
    private TextWatcher mSearchTextWatcher = new TextWatcher() {

        @Override
        public void afterTextChanged(Editable editable) {
            filter(editable.toString());
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before,
                                  int count) {
        }
    };
    private MenuItem mMenuSearchView;
    private ListItemAdapter.OnTagClickedListener mOnTagClickedListener = new ListItemAdapter.OnTagClickedListener() {
        @Override
        public void onTagClicked(String tag) {
            if (mMenuSearchView != null) {
                mMenuSearchView.expandActionView();
                mSearchEditText.setText("");
                mSearchEditText.append(tag);
                filter(tag);
            }
        }
    };
    private String mInitialJid;

    @Override
    public void onRosterUpdate() {
        this.refreshUi();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_conversation);
        mViewPager = (ViewPager) findViewById(R.id.start_conversation_view_pager);

        ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        mContactsTab = actionBar.newTab().setText(R.string.contacts)
                .setTabListener(mTabListener);
        mConferencesTab = actionBar.newTab().setText(R.string.conferences)
                .setTabListener(mTabListener);
        mBroadCastTab = actionBar.newTab().setText("Broadcast")
                .setTabListener(mTabListener);

        actionBar.addTab(mContactsTab);
        actionBar.addTab(mConferencesTab);
        actionBar.addTab(mBroadCastTab);

        mViewPager.setOnPageChangeListener(mOnPageChangeListener);
        mViewPager.setAdapter(new FragmentPagerAdapter(getFragmentManager()) {

            @Override
            public int getCount() {
                return 3;
            }

            @Override
            public Fragment getItem(int position) {
                if (position == 0) {
                    return mContactsListFragment;
                } else if (position == 1) {
                    return mConferenceListFragment;
                } else {
                    return mBroadcastListFragment;
                }
            }
        });

        mConferenceAdapter = new ListItemAdapter(this, conferences);
        mConferenceListFragment.setListAdapter(mConferenceAdapter);
        mConferenceListFragment.setContextMenu(R.menu.conference_context);
        mConferenceListFragment
                .setOnListItemClickListener(new OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> arg0, View arg1,
                                            int position, long arg3) {
                        openConversationForBookmark(position);
                    }
                });

        mContactsAdapter = new ListItemAdapter(this, contacts);
        ((ListItemAdapter) mContactsAdapter).setOnTagClickedListener(this.mOnTagClickedListener);
        mContactsListFragment.setListAdapter(mContactsAdapter);
        mContactsListFragment.setContextMenu(R.menu.contact_context);
        mContactsListFragment
                .setOnListItemClickListener(new OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> arg0, View arg1,
                                            int position, long arg3) {
                        openConversationForContact(position);
                    }
                });

        mBroadcastAdapter = new ListItemAdapter(this, broadcast);
        mBroadcastListFragment.setListAdapter(mBroadcastAdapter);
        mBroadcastListFragment.setContextMenu(R.menu.broadcast_context);
        mBroadcastListFragment
                .setOnListItemClickListener(new OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> arg0, View arg1,
                                            int position, long arg3) {
                        openBCastForBookmark(position);
                    }
                });
        this.mHideOfflineContacts = getPreferences().getBoolean("hide_offline", false);

    }

    private List<String> GetInstalledAppList() {
        String title;
        String strPackageName = null;
        final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        final List pkgAppsList = getPackageManager().queryIntentActivities(mainIntent, 0);
        String emailPackageName = "";
        List<String> packagename = new ArrayList<String>();

        for (Object object : pkgAppsList) {
            ResolveInfo info = (ResolveInfo) object;
            strPackageName = info.activityInfo.applicationInfo.packageName.toString();
            String[] temp_array = strPackageName.split("\\.");


            if (Arrays.asList(temp_array).contains("email") || Arrays.asList(temp_array).contains("gm")
                    || Arrays.asList(temp_array).contains("mail") || Arrays.asList(temp_array).contains("mms")) {
                emailPackageName = strPackageName;
                packagename.add(emailPackageName);

            }
        }
        return packagename;
    }

    protected void openConversationForContact(int position) {
//		System.out.println("Hey Jose. You got it!!!");
        Contact contact = (Contact) contacts.get(position);
        try {
            if (contact.getJid().toBareJid().toString().contains("NEW_")) {
                String tempid = contact.getJid().toBareJid().toString().split("@")[0];
                tempid = tempid.replace("NEW_", "");

                Uri uri = Uri.parse("smsto:" + tempid);

                List<Intent> targetShareIntents = new ArrayList<Intent>();
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                List<ResolveInfo> resInfos = getPackageManager().queryIntentActivities(shareIntent, 0);
                if (!resInfos.isEmpty()) {
//					System.out.println("Have package");
                    String email = "", gm = "", mail = "", mms = "";
                    String appname1 = null;
                    for (ResolveInfo resInfo : resInfos) {
                        String packageName = resInfo.activityInfo.packageName;
                        List<String> emailApp = GetInstalledAppList();
//						String emailApp = GetInstalledAppList();
                        for (String appname : emailApp) {
                            appname1 = appname;

                            if (appname1.contains("email") || appname1.contains("mail")) {
                                email = appname1;
//                                Log.i("info", "Email Application Name :"+email);

                            } else if (appname1.contains("gm")) {
                                gm = appname1;
//                                Log.i("info", "Gmail Application Name :"+gm);
                            } else {
                                mms = appname1;
//                                Log.i("info", "MMS Application Name :"+mms);
                            }
                        }

//                        Log.i("info", "one :"+email+" two :"+mms+ "three :"+gm);
//						if(packageName.contains(email) || packageName.contains("com.google.android.gm") || packageName.contains("com.android.mms")){
                        if (packageName.contains(email) || packageName.contains(mms) || packageName.contains(gm)) {
                            Intent intent = new Intent();
                            intent.setComponent(new ComponentName(packageName, resInfo.activityInfo.name));
                            intent.setAction(Intent.ACTION_SEND);
                            intent.setType("text/plain");
                            // intent.setData(uri.parse("example@email.com"+ uri));
                            intent.putExtra(Intent.EXTRA_USER, "" + uri);
                            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"toaddress@gmail.com"});
                            intent.putExtra(Intent.EXTRA_TEXT, "Check out Palscom Messenger for your smartphone. Download it today from play store.");
                            intent.putExtra(Intent.EXTRA_SUBJECT, "you are invited to palscom messenger");
                            intent.setPackage(packageName);
                            targetShareIntents.add(intent);
                        } else {
                            if (packageName.contains("com.android.mms")) {
                                Intent sms = new Intent(Intent.ACTION_SENDTO, uri);
                                sms.putExtra("sms_body", "Check out Palscomm Messenger for your smartphone. Download it today from play store.");
                                //startActivity(sms);
                            }
                        }
                    }
                    if (!targetShareIntents.isEmpty()) {
                        System.out.println("Have Intent");
                        Intent chooserIntent = Intent.createChooser(targetShareIntents.remove(0), "Invite");
                        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetShareIntents.toArray(new Parcelable[]{}));
                        startActivity(chooserIntent);
                    } else {
                        System.out.println("Do not Have Intent");
                    }
                }
            } else {

                Conversation conversation = xmppConnectionService
                        .findOrCreateConversation(contact.getAccount(),
                                contact.getJid(), false);
                switchToConversation(conversation);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void openConversationForContact() {
        int position = contact_context_id;
        openConversationForContact(position);
    }

    protected void openConversationForBookmark() {
        openConversationForBookmark(conference_context_id);
    }

    protected void openBroadcastForBookmark() {
        openConversationForBookmark(broadcast_context_id);
    }

    protected void openBCastForBookmark(int position) {
        Bookmark bookmark = (Bookmark) broadcast.get(position);
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(bookmark.getAccount(),
                        bookmark.getJid(), true);
        conversation.setBookmark(bookmark);
        if (!conversation.getMucOptions().online()) {
            xmppConnectionService.joinMuc(conversation);
        }
        if (!bookmark.autojoin()) {
            bookmark.setAutojoin(true);
            xmppConnectionService.pushBookmarks(bookmark.getAccount());
        }
        switchToConversation(conversation);
    }

    protected void openConversationForBookmark(int position) {
        Bookmark bookmark = (Bookmark) conferences.get(position);
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(bookmark.getAccount(),
                        bookmark.getJid(), true);
        conversation.setBookmark(bookmark);
        if (!conversation.getMucOptions().online()) {
            xmppConnectionService.joinMuc(conversation);
        }
        if (!bookmark.autojoin()) {
            bookmark.setAutojoin(true);
            xmppConnectionService.pushBookmarks(bookmark.getAccount());
        }
        switchToConversation(conversation);
    }

    protected void openDetailsForContact() {
        int position = contact_context_id;
        Contact contact = (Contact) contacts.get(position);
        switchToContactDetails(contact);
    }

    protected void openDetailsForGroup() {
        int position = conference_context_id;
        Bookmark bookmark = (Bookmark) conferences.get(position);
        Conversation conversation = bookmark.getConversation();
        launchgrpDetailsActivity(conversation);
    }

    protected void openDetailsForBroadcast() {
        int position = broadcast_context_id;
        Bookmark bookmark = (Bookmark) broadcast.get(position);
        Conversation conversation = bookmark.getConversation();
        launchgrpDetailsActivity(conversation);

    }

    protected void toggleContactBlock() {
        final int position = contact_context_id;
        BlockContactDialog.show(this, xmppConnectionService, (Contact) contacts.get(position));
    }

    protected void deleteBroadcast() {
        int position = broadcast_context_id;
        final Bookmark bookmark = (Bookmark) broadcast.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle(R.string.delete_bookmark);
        builder.setMessage(getString(R.string.remove_bookmark_text,
                bookmark.getDisplayName()));
        builder.setPositiveButton(R.string.delete, new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                xmppConnectionService.archiveConversation(bookmark.getConversation());
                bookmark.unregisterConversation();
                Account account = bookmark.getAccount();
                account.getBookmarks().remove(bookmark);
                xmppConnectionService.pushBookmarks(account);
                filter(mSearchEditText.getText().toString());
            }
        });
        builder.create().show();
    }

    protected void deleteContact() {
        final int position = contact_context_id;
        final Contact contact = (Contact) contacts.get(position);
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle(R.string.action_delete_contact);
        builder.setMessage(getString(R.string.remove_contact_text,
                contact.getDisplayName()));
        builder.setPositiveButton(R.string.delete, new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                xmppConnectionService.deleteContactOnServer(contact);
                filter(mSearchEditText.getText().toString());
            }
        });
        builder.create().show();
    }

    protected void deleteConference() {
        int position = conference_context_id;
        Log.i("Elumalai", "i am Group don't delete me!");
        final Bookmark bookmark = (Bookmark) conferences.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setTitle(R.string.delete_bookmark);
        builder.setMessage(getString(R.string.remove_bookmark_text,
                bookmark.getDisplayName()));
        builder.setPositiveButton(R.string.delete, new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                xmppConnectionService.archiveConversation(bookmark.getConversation());
                System.out.println("bookmark.getConversation() ::" + bookmark.getConversation());
                bookmark.unregisterConversation();
                Account account = bookmark.getAccount();
                account.getBookmarks().remove(bookmark);
                xmppConnectionService.pushBookmarks(account);
                filter(mSearchEditText.getText().toString());
            }
        });
        builder.create().show();
    }

    // Function added by Elumalai for local country selected defult
    public String GetCountryZipCode() {
        String CountryID = "";
        String CountryZipCode = "";

        TelephonyManager manager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        //getNetworkCountryIso
        CountryID = manager.getSimCountryIso().toUpperCase();
        String[] rl = this.getResources().getStringArray(R.array.CountryCodes);
        for (int i = 0; i < rl.length; i++) {
            String[] g = rl[i].split(",");
            if (g[1].trim().equals(CountryID.trim())) {
                CountryZipCode = g[0];
                break;
            }
        }
        return CountryZipCode;
    }

    AdapterView.OnItemSelectedListener onItemSelectedListener1 =
            new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View view,
                                           int position, long id) {
                    //System.out.printlncountryCode[position]);
                    tCountryCode.setText(countryCode[position]);
                    //textView1.setText(s1);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }

            };

    /* code added by Elumalai **/
    @SuppressLint("InflateParams")
    protected void showCreateContactDialog(final String prefilledJid, final String fingerprint) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.create_contact);
        View dialogView = getLayoutInflater().inflate(R.layout.create_contact_dialog, null);
        final Spinner spinner = (Spinner) dialogView.findViewById(R.id.account);

        Resources res = getResources();

        String countrypostalcode = GetCountryZipCode();
        //  countryCode = res.getStringArray(R.array.rostercountrieCode);
        tCountryCode = (TextView) dialogView.findViewById(R.id.countrycode);
        countrylist = (TextView) dialogView.findViewById(R.id.country);
        RelativeLayout ln = (RelativeLayout) dialogView.findViewById(R.id.countryselect);

        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        String countryCode = tm.getNetworkCountryIso();
        Locale loc = new Locale("", countryCode);

        String userCountry = loc.getDisplayCountry();
        countrylist.setText(userCountry);
        tCountryCode.setText("+" + countrypostalcode);

        // countrylist.setOnItemSelectedListener(onItemSelectedListener1);
        countrylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                System.out.println("country name clicked me");
                Intent intent = new Intent(StartConversationActivity.this, CountryPickerExample.class);
                intent.putExtra("startconversation", "startconversation");
                startActivityForResult(intent, 3);
                // finish();
            }
        });
        ln.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                System.out.println("country name clicked me");
                Intent intent = new Intent(StartConversationActivity.this, CountryPickerExample.class);
                intent.putExtra("startconversation", "startconversation");
                startActivityForResult(intent, 3);
                // finish();
            }
        });
        /** Jose code ends here..**/
        spinner.setVisibility(View.GONE);
        // countrylist.setVisibility(View.GONE);
        final TextView youraccount = (TextView) dialogView.findViewById(R.id.your_account);
        youraccount.setVisibility(View.GONE);
        final EditText jid = (EditText) dialogView.findViewById(R.id.jid);
        if (prefilledJid != null) {
            jid.append(prefilledJid);
        }
        final EditText nick = (EditText) dialogView.findViewById(R.id.nick_name);
        populateAccountSpinner(spinner);
        builder.setView(dialogView);
        builder.setNegativeButton(R.string.cancel, null);

//        Log.i("Elumalai", "edittext length :"+jid.getText().toString().isEmpty());
        builder.setPositiveButton(R.string.create, null);

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Invalid Mobile number format!", Toast.LENGTH_LONG).show();
            }
        });
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(final View v) {

                        if (!xmppConnectionServiceBound) {
                            return;
                        }
                        final Jid accountJid;
                        try {
                            accountJid = Jid.fromString((String) spinner.getSelectedItem());
                            Log.i("contactDetails", "accountJid ---" + accountJid);
                        } catch (final InvalidJidException e) {
                            return;
                        }
                        Jid contactJid = null;
                        String jidvalues = null;
                        try {

                            jidvalues = jid.getText().toString();
                            Log.i("contactDetails", "Jid values ---" + jidvalues);
                            contactJid = Jid.fromString(tCountryCode.getText().toString() + jid.getText().toString() + "@" + getString(R.string.server_name));
                            Log.i("contactDetails", "contact Jid ----" + contactJid);
//                          contactJid = Jid.fromString(tCountryCode.getText().toString() + id + "@" + getString(R.string.server_name));
//							Log.i("Elumalai", "Contact Jid -- :" + contactJid);
//							Log.i("Elumalai", "Jid Text Values :" + jidvalues);
//                           }
                        } catch (final InvalidJidException e) {
                            jid.setError(getString(R.string.invalid_jid));
                            return;
                        }

                        final Account account = xmppConnectionService
                                .findAccountByJid(accountJid);
                        if (account == null) {
                            dialog.dismiss();
                            return;
                        }
                        if (jidvalues.isEmpty() || jidvalues.length() == 0 || jidvalues.equals("") || jidvalues == null) {
                            jid.setError(getString(R.string.invalid_jid));
                            Toast.makeText(getApplicationContext(), "Enter the Mobile Number", Toast.LENGTH_LONG).show();
                        } else {
                            final Contact contact = account.getRoster().getContact(contactJid);
                            if (contact.showInRoster()) {
                                jid.setError(getString(R.string.contact_already_exists));
                            } else {
                                Log.i("contactDetails", "contact ----" + contact);
                                contact.addOtrFingerprint(fingerprint);
                                xmppConnectionService.createContact(contact);
                                contact.setServerName(nick.getText().toString());
                                xmppConnectionService.pushContactToServer(contact);
                                dialog.dismiss();
                                switchToConversation(contact);
                            }
                        }
                    }
                        /*Toast.makeText(getApplicationContext(), "Enter the Mobile Number",Toast.LENGTH_LONG).show();
                        dialog.show();
					}*/
                });
    }

    /*
    *
    * Function opens the create group dialog.
    * Jose.
    *
    * */
    @SuppressLint("InflateParams")
    protected void showJoinConferenceDialog(final String prefilledJid) {

        Log.i("Create Group", "showJoinConferenceDialog() -- Mothod");
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.join_conference);
        final View dialogView = getLayoutInflater().inflate(R.layout.join_conference_dialog, null);
        final Spinner spinner = (Spinner) dialogView.findViewById(R.id.account);
        /*final AutoCompleteTextView jid = (AutoCompleteTextView) dialogView.findViewById(R.id.jid);
        jid.setAdapter(new KnownHostsAdapter(this,android.R.layout.simple_list_item_1, mKnownConferenceHosts));*/

        final EditText jid = (EditText) dialogView.findViewById(R.id.jid);
        if (prefilledJid != null) {
            jid.append(prefilledJid);
        }
        populateAccountSpinner(spinner);

        final Checkable bookmarkCheckBox = (CheckBox) dialogView
                .findViewById(R.id.bookmark);
        builder.setView(dialogView);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.create, null);
        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(final View v) {
                        if (!xmppConnectionServiceBound) {
                            return;
                        }
                        final Jid accountJid;
                        try {
                            accountJid = Jid.fromString((String) spinner.getSelectedItem());
//							System.out.println("Jose:: Account JID:"+accountJid);
                        } catch (final InvalidJidException e) {
                            return;
                        }
                        final Jid conferenceJid;
                        try {
                            String id = jid.getText().toString().replaceAll("\\s+", "");
                            conferenceJid = Jid.fromString(id + "@" + getString(R.string.conference_name));
                            System.out.println("conference id::" + conferenceJid);
                            System.out.println("conference id::" + jid.getText().toString());

                        } catch (final InvalidJidException e) {
                            jid.setError(getString(R.string.invalid_jid));
                            return;
                        }
                        final Account account = xmppConnectionService
                                .findAccountByJid(accountJid);
                        if (account == null) {
                            dialog.dismiss();
                            return;
                        }
                        if (bookmarkCheckBox.isChecked()) {
                            if (account.hasBookmarkFor(conferenceJid)) {
                                jid.setError(getString(R.string.bookmark_already_exists));
                            } else {
                                final Bookmark bookmark = new Bookmark(account, conferenceJid.toBareJid());
                                bookmark.setAutojoin(true);
                                account.getBookmarks().add(bookmark);
                                xmppConnectionService
                                        .pushBookmarks(account);
                                final Conversation conversation = xmppConnectionService
                                        .findOrCreateConversation(account,
                                                conferenceJid, true);
                                conversation.setBookmark(bookmark);
                                System.out.println("conversation status:" + conversation.getMucOptions().online());
                                if (!conversation.getMucOptions().online()) {
                                    xmppConnectionService
                                            .joinMuc(conversation);
                                    Bundle options = new Bundle();
                                    options.putString("muc#roomconfig_membersonly", "1");
                                    options.putString("muc#roomconfig_whois", "moderators");
                                    options.putString("muc#roomconfig_persistentroom", "1");
                                    xmppConnectionService.pushSubjectToConference(conversation, jid.getText().toString());


                                    xmppConnectionService.pushConferenceConfiguration(conversation,
                                            options,
                                            StartConversationActivity.this);
                                }
                                dialog.dismiss();

                                // ------- below lines added by Jose. to add the user to the memebrs list.
                                String userslist = null;
                                try {
                                    userslist = URLEncoder.encode(accountJid.getLocalpart().toString(), "UTF-8") + "|" + URLEncoder.encode(accountJid.toBareJid().toString(), "UTF-8") + ",";
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }
                                String owner = "owner";
                                String param = "type=1&groupid=" + conversation.getContact().getJid().toBareJid() + "&userslist=" + userslist + "&membertype=" + owner;
                                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                                StrictMode.setThreadPolicy(policy);
                                System.out.println("param:: StartConversationActivity conference --" + param);
//                                HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                                HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                                // --------
                                launchgrpDetailsActivity(conversation);
                                //switchToConversation(conversation);
                            }
                        } else {
                            final Conversation conversation = xmppConnectionService
                                    .findOrCreateConversation(account,
                                            conferenceJid, true);
                            if (!conversation.getMucOptions().online()) {
                                xmppConnectionService.joinMuc(conversation);
                            }
                            dialog.dismiss();
                            switchToConversation(conversation);
                        }
                    }
                });
    }

    protected void launchgrpDetailsActivity(Conversation conv) {
        Intent intent = new Intent(StartConversationActivity.this, ConferenceDetailsActivity.class);
        intent.setAction(ConferenceDetailsActivity.ACTION_VIEW_MUC);
        intent.putExtra("uuid", conv.getUuid());
        /*intent.putExtra("grpnm",jid.getText().toString());
        intent.putExtra("accjid",(String) spinner.getSelectedItem());*/
        startActivityForResult(intent, 9999);
    }

   /* protected void launchbcgrpDetailsActivity(Conversation conv) {
        Intent intent = new Intent(StartConversationActivity.this, BroadcastDetailsActivity.class);
        intent.setAction(ConferenceDetailsActivity.ACTION_VIEW_MUC);
        intent.putExtra("uuid", conv.getUuid());
        *//*intent.putExtra("grpnm",jid.getText().toString());
        intent.putExtra("accjid",(String) spinner.getSelectedItem());*//*
        startActivityForResult(intent, 9999);
    }*/


    protected void showJoinBroadcastDialog(final String prefilledJid) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.join_broadcast);
        final View dialogView = getLayoutInflater().inflate(R.layout.join_broadcast_dialog, null);
        final Spinner spinner = (Spinner) dialogView.findViewById(R.id.account);
		/*final AutoCompleteTextView jid = (AutoCompleteTextView) dialogView.findViewById(R.id.jid);
		jid.setAdapter(new KnownHostsAdapter(this,android.R.layout.simple_list_item_1, mKnownConferenceHosts));*/

        final EditText jid = (EditText) dialogView.findViewById(R.id.jid);

        if (prefilledJid != null) {
            jid.append(prefilledJid);
        }
        populateAccountSpinner(spinner);

        final Checkable bookmarkCheckBox = (CheckBox) dialogView
                .findViewById(R.id.bookmark);
        builder.setView(dialogView);
        builder.setNegativeButton(R.string.cancel, null);
        builder.setPositiveButton(R.string.create, null);
        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(final View v) {
                        if (!xmppConnectionServiceBound) {
                            return;
                        }
                        final Jid accountJid;
                        try {
                            accountJid = Jid.fromString((String) spinner.getSelectedItem());
//							System.out.println("Jose:: Account JID:"+accountJid);
                        } catch (final InvalidJidException e) {
                            return;
                        }
                        final Jid conferenceJid;
                        try {
                            String id = jid.getText().toString().replaceAll("\\s+", "");
//                            Log.i("Empty validation", "id in broad cast creating group --" + id);

                            if (id.isEmpty()) {
                                conferenceJid = Jid.fromString(id + "@" + getString(R.string.conference_name));
                            } else {
                                conferenceJid = Jid.fromString(id + "_bc_@" + getString(R.string.conference_name));
                            }
//                            Log.i("Empty validation", "broadcast -- ::" + conferenceJid);
                        } catch (final InvalidJidException e) {
                            jid.setError(getString(R.string.invalid_jid));
                            return;
                        }
                        final Account account = xmppConnectionService
                                .findAccountByJid(accountJid);
                        if (account == null) {
                            dialog.dismiss();
                            return;
                        }
                        if (bookmarkCheckBox.isChecked()) {
                            if (account.hasBookmarkFor(conferenceJid)) {
                                jid.setError(getString(R.string.bookmark_already_exists));
                            } else {
                                final Bookmark bookmark = new Bookmark(account, conferenceJid.toBareJid());
                                bookmark.setAutojoin(true);
                                account.getBookmarks().add(bookmark);
                                xmppConnectionService
                                        .pushBookmarks(account);
                                final Conversation conversation = xmppConnectionService
                                        .findOrCreateConversation(account,
                                                conferenceJid, true);
                                conversation.setBookmark(bookmark);
                                System.out.println("conversation status:" + conversation.getMucOptions().online());
                                if (!conversation.getMucOptions().online()) {
                                    xmppConnectionService
                                            .joinMuc(conversation);
                                    Bundle options = new Bundle();
                                    options.putString("muc#roomconfig_membersonly", "1");
                                    options.putString("muc#roomconfig_whois", "moderators");
                                    options.putString("muc#roomconfig_persistentroom", "1");
                                    xmppConnectionService.pushSubjectToConference(conversation, jid.getText().toString());

                                    xmppConnectionService.pushConferenceConfiguration(conversation,
                                            options,
                                            StartConversationActivity.this);
                                }
                                dialog.dismiss();

                                // ------- below lines added by Jose. to add the user to the memebrs list.
                                String userslist = null;
                                try {
                                    userslist = URLEncoder.encode(accountJid.getLocalpart().toString(), "UTF-8") + "|" + URLEncoder.encode(accountJid.toBareJid().toString(), "UTF-8") + ",";
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }
                                String owner = "owner";
                                String param = "type=1&groupid=" + conversation.getContact().getJid().toBareJid() + "&userslist=" + userslist + "&membertype=" + owner;
                                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                                StrictMode.setThreadPolicy(policy);
//                                System.out.println(" startConversationActivity bc param::" + param);
//                                HttpCall.webService("http://palscom.com/ws/groupmembers.php", param);
                                HttpCall.webService(Config.GROUP_MEMBERS_URI, param);
                                // --------

//								switchToConversation(conversation);
                                launchgrpDetailsActivity(conversation);
                            }
                        } else {
                            final Conversation conversation = xmppConnectionService
                                    .findOrCreateConversation(account,
                                            conferenceJid, true);
                            if (!conversation.getMucOptions().online()) {
                                xmppConnectionService.joinMuc(conversation);
                            }
                            dialog.dismiss();
                            switchToConversation(conversation);
                        }
                    }
                });
    }

    protected void switchToConversation(Contact contact) {
        Conversation conversation = xmppConnectionService
                .findOrCreateConversation(contact.getAccount(),
                        contact.getJid(), false);
        switchToConversation(conversation);
    }

    private void populateAccountSpinner(Spinner spinner) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, mActivatedAccounts);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.mOptionsMenu = menu;
        getMenuInflater().inflate(R.menu.start_conversation, menu);
        MenuItem menuCreateContact = menu.findItem(R.id.action_create_contact);
        MenuItem menuCreateConference = menu.findItem(R.id.action_join_group);
        MenuItem menuCreateBroadcast = menu.findItem(R.id.action_join_broadcast);
        MenuItem menuHideOffline = menu.findItem(R.id.action_hide_offline);
        MenuItem menuRefresh = menu.findItem(R.id.action_refresh);
        MenuItem menuupdates = menu.findItem(R.id.action_updates);
//      MenuItem menuadvertisements = menu.findItem(R.id.action_advertisement);
        MenuItem menuShowBlocklist = menu.findItem(R.id.action_show_block_list);
        menuHideOffline.setChecked(this.mHideOfflineContacts);
        mMenuSearchView = menu.findItem(R.id.action_search);
        mMenuSearchView.setOnActionExpandListener(mOnActionExpandListener);
        View mSearchView = mMenuSearchView.getActionView();
        mSearchEditText = (EditText) mSearchView
                .findViewById(R.id.search_field);
        mSearchEditText.addTextChangedListener(mSearchTextWatcher);
        if (getActionBar().getSelectedNavigationIndex() == 0) {
            menuCreateConference.setVisible(false);
            menuCreateBroadcast.setVisible(false);
            menuRefresh.setVisible(true);
            menuupdates.setVisible(false);
        } else if (getActionBar().getSelectedNavigationIndex() == 1) {
            menuCreateContact.setVisible(false);
            menuCreateBroadcast.setVisible(false);
            menuHideOffline.setVisible(false);
            menuShowBlocklist.setVisible(false);
            menuRefresh.setVisible(false);
            menuupdates.setVisible(false);
        } else {
            menuHideOffline.setVisible(false);
            menuCreateContact.setVisible(false);
            menuCreateConference.setVisible(false);
            menuShowBlocklist.setVisible(false);
            menuRefresh.setVisible(false);
            menuupdates.setVisible(false);
        }
        if (mInitialJid != null) {
            mMenuSearchView.expandActionView();
            mSearchEditText.append(mInitialJid);
            filter(mInitialJid);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_create_contact:
//				showCreateContactDialog(null,null);
                Intent intent = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
                startActivity(intent);
                return true;
            case R.id.action_join_group:
                showJoinConferenceDialog(null);
                return true;
            case R.id.action_join_broadcast:
                showJoinBroadcastDialog(null);
                break;
            case R.id.action_show_block_list:
                final Intent showBlocklistIntent = new Intent(this, BlocklistActivity.class);
                showBlocklistIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
                startActivity(showBlocklistIntent);
                break;
            case R.id.action_show_favourite_list:
                Intent favouriteIntent = new Intent(this, FavouritesContactsActivity.class);
                favouriteIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
                startActivity(favouriteIntent);
                break;
            case R.id.action_scan_qr_code:
                new IntentIntegrator(this).initiateScan();
                return true;
            case R.id.action_hide_offline:
                mHideOfflineContacts = !item.isChecked();
                getPreferences().edit().putBoolean("hide_offline", mHideOfflineContacts).commit();
                if (mSearchEditText != null) {
                    filter(mSearchEditText.getText().toString());
                }
                invalidateOptionsMenu();
                break;
            case R.id.action_refresh:
                xmppConnectionService.refreshContacts();
                break;
            case R.id.action_updates:
                if (getPreferences().getBoolean("view_updates", true)) {
                    final Intent updatesIntent = new Intent(this, UpdatesActivity.class);
                    updatesIntent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
                    startActivity(updatesIntent);
                } else {
                    Toast.makeText(StartConversationActivity.this, "Enable the Updates from Privacy Settings to View Updates", Toast.LENGTH_LONG).show();
                }
                break;
//            code added by Elumalai for Advertisement in menu
            case R.id.action_advertisement:
                if (getPreferences().getBoolean("advertisements_indicator", true)) {
                    ConnectionDetector cd;
                    cd = new ConnectionDetector(getApplicationContext());
                    if (cd.isConnectingToInternet()) {
                        final Intent addIntent = new Intent(this, AdvertisementCategory.class);
                        startActivity(addIntent);
                    } else {
                        showAlertDialog(StartConversationActivity.this, "No Internet Connection",
                                "You don't have internet connection.", false);
                    }
                } else {
                    Toast.makeText(StartConversationActivity.this, "Enable the Advertisements settings to View Advertisements", Toast.LENGTH_LONG).show();
                }
                break;
//            code added by Elumalai for Event Group menu
            case R.id.action_eventgroups:
                item.setActionView(new ProgressBar(this));
                item.getActionView().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Log.i("info", "i am Event Group menu");
                        final Intent intent1 = new Intent(getBaseContext(), StartEventConversationActivity.class);
                        startActivity(intent1);
                    }
                }, 1000);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_SEARCH && !event.isLongPress()) {
            mOptionsMenu.findItem(R.id.action_search).expandActionView();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if ((requestCode & 0xFFFF) == IntentIntegrator.REQUEST_CODE) {
            IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
            if (scanResult != null && scanResult.getFormatName() != null) {
                String data = scanResult.getContents();
                Invite invite = new Invite(data);
                if (xmppConnectionServiceBound) {
                    invite.invite();
                } else if (invite.getJid() != null) {
                    this.mPendingInvite = invite;
                } else {
                    this.mPendingInvite = null;
                }
            }
        }
        if (requestCode == 3) {

            if (resultCode == 3) {

                Bundle extras = intent.getExtras();
                if (extras != null) {
                    String countryname = intent.getStringExtra("NAME");
                    String countrycode = intent.getStringExtra("CODE");
                    countrydialcode = intent.getStringExtra("DIALCODE");
                    countrylist.setText("");
                    tCountryCode.setText("");
                    countrylist.setText(countryname);
                    tCountryCode.setText(countrydialcode);
                          /*  System.out.println("Country Name ---"+countryname);
                            System.out.println("Country Code ---"+countrycode);
                            System.out.println("Country Dial Code ---"+countrydialcode);*/
                }
            }
        }
        super.onActivityResult(requestCode, requestCode, intent);
    }

    @Override
    protected void onBackendConnected() {
        this.mActivatedAccounts.clear();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {
                this.mActivatedAccounts.add(account.getJid().toBareJid().toString());
            }
        }
        final Intent intent = getIntent();
        final ActionBar ab = getActionBar();
        if (intent != null && intent.getBooleanExtra("init", false) && ab != null) {
            ab.setDisplayShowHomeEnabled(false);
            ab.setDisplayHomeAsUpEnabled(false);
            ab.setHomeButtonEnabled(false);
        }
        this.mKnownHosts = xmppConnectionService.getKnownHosts();
        this.mKnownConferenceHosts = xmppConnectionService.getKnownConferenceHosts();
        if (this.mPendingInvite != null) {
            mPendingInvite.invite();
            this.mPendingInvite = null;
        } else if (!handleIntent(getIntent())) {
            if (mSearchEditText != null) {
                filter(mSearchEditText.getText().toString());
            } else {
                filter(null);
            }
        }
        setIntent(null);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    Invite getInviteJellyBean(NdefRecord record) {
        return new Invite(record.toUri());
    }

    protected boolean handleIntent(Intent intent) {
        if (intent == null || intent.getAction() == null) {
            return false;
        }
        switch (intent.getAction()) {
            case Intent.ACTION_SENDTO:
            case Intent.ACTION_VIEW:
                Log.d(Config.LOGTAG, "received uri=" + intent.getData());
                return new Invite(intent.getData()).invite();
            case NfcAdapter.ACTION_NDEF_DISCOVERED:
                for (Parcelable message : getIntent().getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)) {
                    if (message instanceof NdefMessage) {
                        Log.d(Config.LOGTAG, "received message=" + message);
                        for (NdefRecord record : ((NdefMessage) message).getRecords()) {
                            switch (record.getTnf()) {
                                case NdefRecord.TNF_WELL_KNOWN:
                                    if (Arrays.equals(record.getType(), NdefRecord.RTD_URI)) {
                                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                            return getInviteJellyBean(record).invite();
                                        } else {
                                            byte[] payload = record.getPayload();
                                            if (payload[0] == 0) {
                                                return new Invite(Uri.parse(new String(Arrays.copyOfRange(
                                                        payload, 1, payload.length)))).invite();
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
        }
        return false;
    }

    private boolean handleJid(Invite invite) {
        List<Contact> contacts = xmppConnectionService.findContacts(invite.getJid());
        if (contacts.size() == 0) {
            showCreateContactDialog(invite.getJid().toString(), invite.getFingerprint());
            return false;
        } else if (contacts.size() == 1) {
            Contact contact = contacts.get(0);
            if (invite.getFingerprint() != null) {
                if (contact.addOtrFingerprint(invite.getFingerprint())) {
                    Log.d(Config.LOGTAG, "added new fingerprint");
                    xmppConnectionService.syncRosterToDisk(contact.getAccount());
                }
            }
            switchToConversation(contact);
            return true;
        } else {
            if (mMenuSearchView != null) {
                mMenuSearchView.expandActionView();
                mSearchEditText.setText("");
                mSearchEditText.append(invite.getJid().toString());
                filter(invite.getJid().toString());
            } else {
                mInitialJid = invite.getJid().toString();
            }
            return true;
        }
    }

    protected void filter(final String needle) {
        if (xmppConnectionServiceBound) {
            this.filterContacts(needle);
            this.filterConferences(needle);
            this.filterBroatcast(needle);
        }
    }


    protected void filterContacts(String needle) {
        this.contacts.clear();
        this.usercontactlistP.clear();
        this.Phonecontactlist.clear();
        String accountOwner = null;
        String contactlisttemp = null;
        List sourceList = new ArrayList();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {
                for (Contact contact : account.getRoster().getContacts()) {
                    if (contact.showInRoster() && contact.match(needle)
                            && (!this.mHideOfflineContacts
                            || contact.getPresences().getMostAvailableStatus() < Presences.OFFLINE)) {
                        //Added By Elumalai for Removing account from contact list
                        accountOwner = account.getJid().toBareJid().getLocalpart();
                        String usercontactlist = contact.getJid().toBareJid().getLocalpart();
                        String tempcontactlist = usercontactlist;
                        if (accountOwner.contains(tempcontactlist)) {
                        } else {
                            if (tempcontactlist.contains("+")) {
                                usercontactlistP.add(tempcontactlist);
                                this.contacts.add(contact);
                            }
                        }
                    }
                }
                Collections.sort(this.contacts);
                Jid jid = null;
                String contactlist[];
                contactlist = XmppConnectionService.nonusers.split(",");
                String contactss = null;

                //Added by Elumalai Removed duplicate contacts for nonuser.
                for (int i = 0; i < contactlist.length; i++) {
                    String temp = contactlist[i].toString();
                    sourceList.add(temp);
                }
                List newList = new ArrayList(new HashSet(sourceList));
                Iterator it = newList.iterator();
                while (it.hasNext()) {
                    String temp = String.valueOf(it.next());
                    try {
                        final String[] contactJidNick = temp.split("\\|");
                        String contactno = contactJidNick[1].replaceAll("\\s+", "");
                            if (contactJidNick[1] != null) {
                                if (contactJidNick[0] != null) {
                                    contactss = contactJidNick[0] + "|" + contactno;
                                }
                            }
                            Phonecontactlist.add(contactss);
                    } catch (ArrayIndexOutOfBoundsException e) {
                        e.printStackTrace();
                    }
                }
                String palscontactnumber = null;
                String phonecontacts = null;
                // Adding By Elumalai for comparing palscom user list with phone contacts user
                // and same contacts are removed from phone contacts.
                for (int j = 0; j < usercontactlistP.size(); j++) {
                    for (int b = 0; b < Phonecontactlist.size(); b++) {
                        try {
                            palscontactnumber = usercontactlistP.get(j);
                            final String[] contactJidNick = Phonecontactlist.get(b).split("\\|");
                            if (contactJidNick[1] != null) {
                                phonecontacts = contactJidNick[1].replaceAll("\\s+", "");
                            }
                            if (phonecontacts.contains("+")) {
                                if (palscontactnumber.equals(phonecontacts)) {
                                    Phonecontactlist.remove(b);
                                }
                            }
                        } catch (ArrayIndexOutOfBoundsException e) {
                            e.printStackTrace();
                        }
                    }
                }
                // Phone contacts user are mergered with contacts list.
                for (int b = 0; b < Phonecontactlist.size(); b++) {
                    contactlisttemp = Phonecontactlist.get(b);
                    if (contactlisttemp != null && accountOwner != null) {
                        if (contactlisttemp.contains(accountOwner)) {
                            contactlisttemp = null;
                        }
                    }
                    if (contactlisttemp != null) {
                        final String[] contactJidNick = contactlisttemp.split("\\|");
                        String contactjid = contactJidNick[1].replaceAll("\\s+", "");
                        int len = contactJidNick.length;
                        if (len == 2) {
                            try {
                                String contactno = contactjid;
                                if (contactno.contains("+")) {
                                    jid = Jid.fromString("NEW_" + contactno + "@" + getString(R.string.server_name));
                                    Contact tempid = account.getRoster().getContact(jid);
                                    tempid.setServerName(contactJidNick[0]);
                                    if (tempid.match(needle))
                                        this.contacts.add(tempid);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                }//    Collections.sort(this.contacts);
            }
        }
        mContactsAdapter.notifyDataSetChanged();
    }


   /* protected void filterContacts(String needle) {
        this.contacts.clear();
        String accountOwner = null;
        List<String> usercontactlistP = new ArrayList<String>();
        List<String> Phonecontactlist = new ArrayList<String>();
        String contactlisttemp = null;
        List sourceList = new ArrayList();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {
                for (Contact contact : account.getRoster().getContacts()) {
                    if (contact.showInRoster() && contact.match(needle)
                            && (!this.mHideOfflineContacts
                            || contact.getPresences().getMostAvailableStatus() < Presences.OFFLINE)) {
                        //Added By Elumalai for Removing account from contact list
                        accountOwner = account.getJid().toBareJid().getLocalpart();
                        String usercontactlist = contact.getJid().toBareJid().getLocalpart();
                        String tempcontactlist = usercontactlist.substring(3);
//                        Log.i("contactfilter", "account Ower --"+accountOwner);
//                        Log.i("contactfilter", "user Contact --"+tempcontactlist);
//                        Log.i("contactfilter", "accountOwner.contains(tempcontactlist) --"+accountOwner.contains(tempcontactlist));
                        if (accountOwner.contains(tempcontactlist)) {
//                           Log.i("contactfilter", "i'm the Owner ---"+accountOwner);
                        } else {
                            usercontactlistP.add(tempcontactlist);
                            this.contacts.add(contact);
                        }
                    }
                }
                Collections.sort(this.contacts);

                Jid jid = null;
                String contactlist[];
                contactlist = XmppConnectionService.nonusers.split(",");
                String contactss = null;

                //Added by Elumalai Removed duplicate contacts for nonuser.
                for (int i = 0; i < contactlist.length; i++) {
                    String temp = contactlist[i].toString();
                    sourceList.add(temp);
                }
                List newList = new ArrayList(new HashSet(sourceList));
                Iterator it = newList.iterator();
                while (it.hasNext()) {
                    String temp = String.valueOf(it.next());
                    try {
                        final String[] contactJidNick = temp.split("\\|");
                        String contactno = contactJidNick[1].replaceAll("\\s+", "");
                        if (contactno.length() >= 10) {
                            if (contactJidNick[1] != null) {
                                if (contactJidNick[0] != null) {
                                    contactss = contactJidNick[0] + "|" + contactno;
                                }
                            }
                            Phonecontactlist.add(contactss);
                        } else {
                            Log.i("contactfilter", "i'm not a 10 digit contact");
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {
                        e.printStackTrace();
                    }
                }
                String palscontactnumber = null;
                String phonecontacts = null;
                // Adding By Elumalai for comparing palscom user list with phone contacts user
                // and same contacts are removed from phone contacts.
                for (int j = 0; j < usercontactlistP.size(); j++) {
                    for (int b = 0; b < Phonecontactlist.size(); b++) {
                        try {
                            palscontactnumber = usercontactlistP.get(j);
                            final String[] contactJidNick = Phonecontactlist.get(b).split("\\|");
                            if (contactJidNick[1] != null) {
                                phonecontacts = contactJidNick[1].replaceAll("\\s+", "");
                            }
                            if (phonecontacts.length() > 10 && phonecontacts.contains("+")) {
                                phonecontacts = phonecontacts.substring(3);
                            }
                        } catch (ArrayIndexOutOfBoundsException e) {
                            e.printStackTrace();
                        }
//                          Log.i("contactfilter", "phone Contacts --"+phonecontacts + "-- Palscom Contacts --"+palscontactnumber);
                        if (palscontactnumber.contains(phonecontacts)) {
//                            if (accountOwner.contains(phonecontacts)) {
                            Phonecontactlist.remove(b);
//                            }
                        }
                    }
                }
                // Phone contacts user are mergered with contacts list.
                for (int b = 0; b < Phonecontactlist.size(); b++) {
                    contactlisttemp = Phonecontactlist.get(b);
//                        Log.i("contactfilter","accountOwner --"+accountOwner+"--phonecontacts--"+contactlisttemp);
                    Log.i("contactfilter", "accountOwner.contains(phonecontacts) --" + contactlisttemp.contains(accountOwner));
                    if (contactlisttemp.contains(accountOwner)) {
                        contactlisttemp = null;
                    }
                    if (contactlisttemp != null) {
                        final String[] contactJidNick = contactlisttemp.split("\\|");
                        String contactjid = contactJidNick[1].replaceAll("\\s+", "");
                        int len = contactJidNick.length;
                        if (len == 2) {
                            try {
                                String contactno = contactjid;
                                if (contactno.contains("+")) {
                                    jid = Jid.fromString("NEW_" + contactno + "@" + getString(R.string.server_name));
                                    Contact tempid = account.getRoster().getContact(jid);
//                                        Log.i("contactfilter", "Tempid ---" + tempid);
//								          Log.i("contactfilter", "contactJidNick[0]) ---"+contactJidNick[0]);
                                    tempid.setServerName(contactJidNick[0]);
                                    if (tempid.match(needle))
                                        this.contacts.add(tempid);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }

                }
            }
        }
        mContactsAdapter.notifyDataSetChanged();
    }
*/
    protected void filterConferences(String needle) {
        this.conferences.clear();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {
                for (Bookmark bookmark : account.getBookmarks()) {
                    if (bookmark.match(needle)) {
                        try {

                            if (bookmark.getJid() != null) {
                                int intIndex = bookmark.getJid().toString().indexOf("_bc_");
                                int intIndex2 = bookmark.getJid().toString().indexOf("_ev_");
                                if (intIndex == -1 && intIndex2 == -1) {
                                    this.conferences.add(bookmark);
                                    // System.out.println("Hello not found");
                                } else {
                                    //System.out.println("Found Hello at index "+ intIndex);
                                }
                                //this.conferences.add(bookmark);
                            }
                        } catch (Exception e) {
                            System.out.println("filterConferences Exception" + e.getMessage().toString());
                        }
                    }
                }
            }
        }
        Collections.sort(this.conferences);
        mConferenceAdapter.notifyDataSetChanged();
    }

    protected void filterBroatcast(String needle) {
        this.broadcast.clear();
        for (Account account : xmppConnectionService.getAccounts()) {
            if (account.getStatus() != Account.State.DISABLED) {

                for (Bookmark bookmark : account.getBookmarks()) {
                    if (bookmark.match(needle)) {
                        //System.out.printlnn("bookmark::"+bookmark.getJid());
                        if (bookmark.getJid() != null) {
                            try {

                                int intIndex = bookmark.getJid().toString().indexOf("_bc_");
                                if (intIndex == -1) {
                                    //System.out.printlnln("Hello not found");
                                } else {
                                    this.broadcast.add(bookmark);
                                    //System.out.printlntln("Found Hello at index "+ intIndex);
                                }
                            } catch (Exception e) {
                                System.out.println("filterConferences Exception" + e.getMessage().toString());
                            }
                        }
                    }
                }
            }
        }
        Collections.sort(this.broadcast);
        mBroadcastAdapter.notifyDataSetChanged();
    }

    private void onTabChanged() {
        invalidateOptionsMenu();
    }

    @Override
    public void OnUpdateBlocklist(final Status status) {
        refreshUi();
    }

    @Override
    protected void refreshUiReal() {
        if (mSearchEditText != null) {
            filter(mSearchEditText.getText().toString());
        }
    }

    public static class MyListFragment extends ListFragment {
        private AdapterView.OnItemClickListener mOnItemClickListener;
        private int mResContextMenu;

        public void setContextMenu(final int res) {
            this.mResContextMenu = res;
        }

        @Override
        public void onListItemClick(final ListView l, final View v, final int position, final long id) {
            if (mOnItemClickListener != null) {
                mOnItemClickListener.onItemClick(l, v, position, id);
            }
        }

        public void setOnListItemClickListener(AdapterView.OnItemClickListener l) {
            this.mOnItemClickListener = l;
        }

        @Override
        public void onViewCreated(final View view, final Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);
            registerForContextMenu(getListView());
            getListView().setFastScrollEnabled(false);
        }

        @Override
        public void onCreateContextMenu(final ContextMenu menu, final View v,
                                        final ContextMenuInfo menuInfo) {
            super.onCreateContextMenu(menu, v, menuInfo);
            final StartConversationActivity activity = (StartConversationActivity) getActivity();
            activity.getMenuInflater().inflate(mResContextMenu, menu);
            final AdapterView.AdapterContextMenuInfo acmi = (AdapterContextMenuInfo) menuInfo;
            if (mResContextMenu == R.menu.conference_context) {
                activity.conference_context_id = acmi.position;
            } else if (mResContextMenu == R.menu.broadcast_context) {
                activity.broadcast_context_id = acmi.position;

            } else if (mResContextMenu == R.menu.contact_context) {
                activity.contact_context_id = acmi.position;
                final Blockable contact = (Contact) activity.contacts.get(acmi.position);
                final MenuItem blockUnblockItem = menu.findItem(R.id.context_contact_block_unblock);
                XmppConnection xmpp = contact.getAccount().getXmppConnection();
                if (xmpp != null && xmpp.getFeatures().blocking()) {
                    if (contact.isBlocked()) {
                        blockUnblockItem.setTitle(R.string.unblock_contact);
                    } else {
                        blockUnblockItem.setTitle(R.string.block_contact);
                    }
                } else {
                    blockUnblockItem.setVisible(false);
                }
            }
        }

        @Override
        public boolean onContextItemSelected(final MenuItem item) {
            StartConversationActivity activity = (StartConversationActivity) getActivity();
            switch (item.getItemId()) {
                //Added by Elumalai for start chats
                case R.id.context_start_conversation_contact:
                    activity.openConversationForContact();
                    break;
                case R.id.context_start_broadcast:
                    activity.openBroadcastForBookmark();
                    break;
                case R.id.context_start_conversation_group:
                    activity.openConversationForBookmark();
                    break;
                //Added by Elumalai for details of contact and Groups
                case R.id.context_contact_details:
                    activity.openDetailsForContact();
                    break;
                case R.id.context_info_conference:
                    activity.openDetailsForGroup();
                    break;
                case R.id.context_broadcast_details:
                    activity.openDetailsForBroadcast();
                    break;
                // Added by Elumalai for creating New Groups
                case R.id.context_join_conference:
                    activity.showJoinConferenceDialog(null);
                    break;
                case R.id.context_join_broadcast:
                    activity.showJoinBroadcastDialog(null);
                    break;
                case R.id.context_delete_contact:
                    activity.deleteContact();
                    break;
                case R.id.context_contact_block_unblock:
                    activity.toggleContactBlock();
                    break;
                //this code is commanded by Elumalai for deleting Groups
                /*case R.id.context_delete_conference:
                    activity.deleteConference();
                    break;
                case R.id.context_delete_broadcast:
                    activity.deleteBroadcast();*/
            }
            return true;
        }
    }

    private class Invite extends XmppUri {

        public Invite(final Uri uri) {
            super(uri);
        }

        public Invite(final String uri) {
            super(uri);
        }

        boolean invite() {
            if (jid != null) {
                if (muc) {
                    showJoinConferenceDialog(jid);
                } else {
                    return handleJid(this);
                }
            }
            return false;
        }
    }

    @Override
    public void onPushSucceeded() {
        //System.out.printlnntln("Push success");
    }

    @Override
    public void onPushFailed() {
        //System.out.printlnintln("Push fail");
    }

    public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(message);

        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);


        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }
}