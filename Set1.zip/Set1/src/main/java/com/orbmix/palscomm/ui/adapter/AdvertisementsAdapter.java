package com.orbmix.palscomm.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.ui.RowItem1;

import java.util.List;

/**
 * Created by Elumalai on 8/20/2015.
 */
public class AdvertisementsAdapter extends ArrayAdapter<RowItem1> {

    Context context;

    public AdvertisementsAdapter(Context context, int resourceId,
                                 List<RowItem1> items) {
        super(context, resourceId, items);
        this.context = context;
    }

    /*private view holder class*/
    private class ViewHolder {
        ImageView imageView;
        TextView txtTitle;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        final RowItem1 rowItem = getItem(position);

        LayoutInflater mInflater = (LayoutInflater) context
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.advertisements, null);
            holder = new ViewHolder();
            holder.txtTitle = (TextView) convertView.findViewById(R.id.ads_text);
            holder.imageView = (ImageView) convertView.findViewById(R.id.ads_imageView);
            ViewGroup.LayoutParams layoutParams = holder.imageView.getLayoutParams();
          /*layoutParams.width = 400;
            layoutParams.height = 300;*/
            holder.imageView.setLayoutParams(layoutParams);
            convertView.setTag(holder);
        } else
        holder = (ViewHolder) convertView.getTag();
        holder.txtTitle.setText(rowItem.getAdsname());
        holder.imageView.setImageBitmap(rowItem.getAdsimage());
        holder.imageView.setOnClickListener(new View.OnClickListener() {
                         String s = rowItem.getCompanyurl();
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://" + s));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        return convertView;
    }

}