package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.orbmix.palscomm.R;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by Elumalai on 12/11/2015.
 */
public class ShareContact extends Activity{

    private static final String TAG = ShareContact.class.getSimpleName();
    private static final int REQUEST_CODE_PICK_CONTACTS = 147852;
    private Uri uriContact;
    private String contactID;

    String email = "";
    String contactName = null;
    String contactNumber = null;
    Bitmap photo = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Toast.makeText(getBaseContext(), "OnCreate method", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_sharecontact);
        startActivityForResult(new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI), REQUEST_CODE_PICK_CONTACTS);
        Button sharebutton = (Button) findViewById(R.id.share_button);
        Button cancelbutton = (Button) findViewById(R.id.cancel_button);
        final Intent intent = new Intent();

        sharebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.putExtra("name", contactName);
                intent.putExtra("number", contactNumber);
                intent.putExtra("email", email);
                if (photo == null) {
                    intent.putExtra("contactimage", photo);
                } else {
                    final String contactimage = BitMapToString(photo);
                    intent.putExtra("contactimage", contactimage);
                }
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        cancelbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShareContact.this.finish();
            }
        });

    }

    public void ContactlistView(){

    }

   /* @Override
    protected void onResume() {
        super.onResume();
      *//*  Toast.makeText(getBaseContext(),"OnResume method ",Toast.LENGTH_SHORT).show();
        Log.i("OnResume method ","OnResume method ");*//*
            }*/

  /*  @Override
    protected void onPause() {
        super.onPause();
       *//* Toast.makeText(getBaseContext(),"OnPause method ",Toast.LENGTH_SHORT).show();
        Log.i("OnPause method","OnPause method");*//*
    }
*/
    @Override
    protected void onRestart() {
        super.onRestart();
       /* Toast.makeText(getBaseContext(),"OnRestart method ",Toast.LENGTH_SHORT).show();
        Log.i("OnRestart method","OnRestart method");*/
          if(contactNumber == null | contactNumber == ""){
            ShareContact.this.finish();
        }
    }

  /*  @Override
    protected void onStart() {
        super.onStart();
        *//*Toast.makeText(getBaseContext(),"OnStart method ",Toast.LENGTH_SHORT).show();
        Log.i("OnStart method", "OnStart method");*//*
    }*/

  /*  @Override
    protected void onDestroy() {
        super.onDestroy();
     *//*   Toast.makeText(getBaseContext(),"OnDestroy method ",Toast.LENGTH_SHORT).show();
        Log.i("OnDestroy method","OnDestroy method");*//*
    }*/

  /*  @Override
    protected void onStop() {
        super.onStop();
     *//*   Toast.makeText(getBaseContext(),"OnStop method ",Toast.LENGTH_SHORT).show();
        Log.i( "OnStop method","OnStop method");*//*
    }*/

    public String BitMapToString(Bitmap bitmap){
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte [] b=baos.toByteArray();
        String temp=Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_PICK_CONTACTS && resultCode == RESULT_OK) {
            Log.d(TAG, "Response: " + data.toString());
            uriContact = data.getData();

            Log.d(TAG, "Response:  UriContact" + data.getData().toString());

            retrieveContactName();
            retrieveContactNumber();
            contactimage();
            retrieveemail(uriContact);


        }
    }

    private void contactimage(){
        Cursor cursorID = getContentResolver().query(uriContact,
                new String[]{ContactsContract.Contacts._ID},
                null, null, null);
        if (cursorID.moveToFirst()) {

            contactID = cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID));
        }
        cursorID.close();
//        Log.d(TAG, "Contact ID: " + contactID);
        long id = Long.parseLong(contactID);
        InputStream inputStream = openPhoto(id);
        photo = BitmapFactory.decodeStream(inputStream);

        ImageView imageView = (ImageView) findViewById(R.id.img_contact);
        imageView.setImageBitmap(photo);
    }

    public InputStream openPhoto(long contactId) {
        Uri contactUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId);
        Uri photoUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
        Cursor cursor = getContentResolver().query(photoUri,
                new String[] {ContactsContract.Contacts.Photo.PHOTO}, null, null, null);
        if (cursor == null) {
            return null;
        }
        try {
            if (cursor.moveToFirst()) {
                byte[] data = cursor.getBlob(0);
                if (data != null) {
                    return new ByteArrayInputStream(data);
                }
            }
        } finally {
            cursor.close();
        }
        return null;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void retrieveemail(Uri result){
        Cursor cursor = null;

        try {
            Log.v(TAG, "Got a contact result: "
                    + result.toString());

            // get the contact id from the Uri
            String id = result.getLastPathSegment();

            // query for everything email
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    null, ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=?", new String[] { id },
                    null);

            int emailIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA);

            // let's just get the first email
            if (cursor.moveToFirst()) {
                email = cursor.getString(emailIdx);
                Log.v(TAG, "Got email: " + email);
            } else {
                Log.w(TAG, "No results");
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to get email data", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            TextView emailEntry = (TextView) findViewById(R.id.contact_email);
            emailEntry.setText(email);
            if (email.length() == 0) {
//                Toast.makeText(this, "No email found for contact.", Toast.LENGTH_LONG).show();
            }
        }
    }


    private void retrieveContactNumber() {

        // getting contacts ID
        Cursor cursorID = getContentResolver().query(uriContact,
                new String[]{ContactsContract.Contacts._ID},
                null, null, null);

        if (cursorID.moveToFirst()) {

            contactID = cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID));
        }
        cursorID.close();
        Log.d(TAG, "Contact ID: " + contactID);

        // Using the contact ID now we will get contact phone number
        Cursor cursorPhone = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},

                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? AND " +
                        ContactsContract.CommonDataKinds.Phone.TYPE + " = " +
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,

                new String[]{contactID},
                null);

        if (cursorPhone.moveToFirst()) {
            contactNumber = cursorPhone.getString(cursorPhone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
        }
        cursorPhone.close();
//        Log.d(TAG, "Contact Phone Number: " + contactNumber);
        TextView textView = (TextView) findViewById(R.id.contact_no);
        if(contactNumber == null){
            textView.setText("");
        }else {
            textView.setText(contactNumber);
        }
    }

    private void retrieveContactName() {
        // querying contact data store
        Cursor cursor = getContentResolver().query(uriContact, null, null, null, null);

        if (cursor.moveToFirst()) {

            // DISPLAY_NAME = The display name for the contact.
            // HAS_PHONE_NUMBER =   An indicator of whether this contact has at least one phone number.
            contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
        }
        cursor.close();
        Log.d(TAG, "Contact Name: " + contactName);
        TextView textView1 = (TextView) findViewById(R.id.contact_name);

        if(contactName == null || contactName.isEmpty()){
            textView1.setText("");
        }else {
            textView1.setText(contactName);
        }
    }
}
