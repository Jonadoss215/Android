package com.orbmix.palscomm.ui;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.R;

/**
 * Created by Alvin on 8/3/2015.
 */
public class AdsWebView extends Activity {
    WebView webView;
    String category;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adswebview);

        webView = (WebView) findViewById(R.id.webview);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            category = extras.getString("category");
            gotoPage(category);
        }
        else
        {
            Toast.makeText(AdsWebView.this,
                    "There is no Ads available for this category in the server!",
                    Toast.LENGTH_LONG).show();
        }
        actionBarSetup();
        getActionBar().setDisplayHomeAsUpEnabled(true);
    }
    private void actionBarSetup() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            ActionBar ab = getActionBar();
            ab.setSubtitle(category);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void gotoPage(String page){


//        String url = "http://palscom.com/pals/index.php/ads-categorie/"+page;
        String url = Config.ADVERTISEMENTS_CATEGORIES_URI+page;

        WebSettings webSettings = webView.getSettings();
        webSettings.setBuiltInZoomControls(true);

        webView.setWebViewClient(new Callback());  //HERE IS THE MAIN CHANGE
        webView.loadUrl(url);

    }

    private class Callback extends WebViewClient {  //HERE IS THE MAIN CHANGE.

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return (false);
        }

    }
}
