package com.orbmix.palscomm.xmpp;

/**
 * Created by Elumalai on 12/30/2015.
 */
public interface OnUpdateFavoritelist {

        // Use an enum instead of a boolean to make sure we don't run into the boolean trap
        // (`onUpdateBlocklist(true)' doesn't read well, and could be confusing).
        public static enum Status {
            FAVORITE,
            UNFAVORITE,
        }

        @SuppressWarnings("MethodNameSameAsClassName")
        public void OnUpdateFavoritelist(final Status status);
    }


