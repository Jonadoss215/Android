package com.orbmix.palscomm.ui;

import android.graphics.Bitmap;

/**
 * Created by Elumalai on 8/20/2015.
 */
public class RowItem1 {
    private Bitmap adsimage;
    private String adsname;
    private String companyurl;

    public RowItem1(Bitmap adsimage, String adsname, String companyurl) {
        this.adsimage = adsimage;
        this.adsname = adsname;
        this.companyurl = companyurl;
    }

    public Bitmap getAdsimage() {
        return adsimage;
    }

    public void setAdsimage(Bitmap adsimage) {
        this.adsimage = adsimage;
    }

    public String getCompanyurl() {
        return companyurl;
    }

    public void setCompanyurl(String companyurl) {
        this.companyurl = companyurl;
    }

    public String getAdsname() {
        return adsname;
    }

    public void setAdsname(String adsname) {
        this.adsname = adsname;
    }

    @Override
    public String toString() {
        return adsname + "\n" + companyurl;
    }
}