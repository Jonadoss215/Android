package com.orbmix.palscomm.http;

import android.os.AsyncTask;
import android.util.Log;

import com.orbmix.palscomm.Config;
import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.entities.Conversation;
import com.orbmix.palscomm.entities.DownloadableFile;
import com.orbmix.palscomm.entities.Message;
import com.orbmix.palscomm.services.XmppConnectionService;
import com.orbmix.palscomm.xmpp.stanzas.MessagePacket;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created 13.09.14 21:33.
 *
 * @author Jose
 * @version 2014-09-13-001
 */
public class ImageUploader {

	private XmppConnectionService xmppConnectionService;
	private Message message;
	private DownloadableFile file;
	
	

	long imageSize = 0; // kb

	public ImageUploader(XmppConnectionService service) {
		xmppConnectionService = service;
	}

	public void init(Message message) {
		this.message = message;
		this.file = xmppConnectionService.getFileBackend().getFile(message);
		imageSize = file.getSize()/1024;
		//System.out.println"Hey.. Image size::"+imageSize);
		// EXECUTED ASYNCTASK TO UPLOAD IMAGE
		new FileUploader().execute();
		/*new Thread(new Runnable() {
			@Override
			public void run() {
				uploadThread();
			}
		}).start();*/

	}

	private void uploadThread() {
		final HttpUploader twajax = new HttpUploader();
		if(message.getType() == Message.TYPE_IMAGE)
		{
			twajax.addPostFile(new HttpUploader.PostFile("fileToUpload", message.getConversationUuid()+".webp", "image/webp", file));
		}
		else
			twajax.addPostFile(new HttpUploader.PostFile("fileToUpload", message.getRelativeFilePath(), "image/webp", file));
		twajax.postData(Config.HTTP_UPLOAD_ENDPOINT, new Runnable() {
			@Override
			public void run() {
				try {
					Log.d(Config.LOGTAG, "ImageUploader http status: "+ String.valueOf(twajax.getHttpCode()) +", result: "+twajax.getResult(), twajax.getError());
					/*JSONObject result = (JSONObject)twajax.getJsonResult();
					String hash = result.getString("hash");*/
					
					//String url = Config.HTTP_UPLOAD_ENDPOINT + "/" + hash + ".webp";
					String url = twajax.getResult();

					Account account = message.getConversation().getAccount();
					MessagePacket packet = xmppConnectionService.getMessageGenerator().generateChat(message);
					packet.setBody(url);
					if (!account.getXmppConnection().getFeatures().sm()
							&& message.getConversation().getMode() != Conversation.MODE_MULTI) {
						xmppConnectionService.markMessage(message, Message.STATUS_SEND);
					}
					xmppConnectionService.sendMessagePacket(account, packet);

				} catch(Exception ex) {
					ex.printStackTrace();
					xmppConnectionService.markMessage(message, Message.STATUS_SEND_FAILED);
				}
			}
		});

	}
	
	 private class FileUploader extends AsyncTask<Void, Integer, Boolean> implements UploadProgressListener {

			@Override
			protected Boolean doInBackground(Void... params) {
							
		        try{
		        	
		        	InputStream inputStream = new FileInputStream(file);
		            
		            //*** CONVERT INPUTSTREAM TO BYTE ARRAY
		             
		            byte[] data = this.convertToByteArray(inputStream);
		                 
		            HttpClient httpClient = new DefaultHttpClient();
		            httpClient.getParams().setParameter(CoreProtocolPNames.USER_AGENT,System.getProperty("http.agent"));
		           
		            HttpPost httpPost = new HttpPost(Config.HTTP_UPLOAD_ENDPOINT);
		           
		            // STRING DATA
		            StringBody dataString = new StringBody("This is the sample image");
		           
		            // FILE DATA OR IMAGE DATA
		            String fileName="";
		            if(message.getType() == Message.TYPE_IMAGE)
		            	fileName =  message.getConversationUuid()+".webp";
		            else
		            	fileName =  message.getRelativeFilePath();
		            
		            InputStreamBody inputStreamBody = new InputStreamBody(new ByteArrayInputStream(data),fileName);
		            
		           // MultipartEntity multipartEntity = new MultipartEntity();
		            CustomMultiPartEntity  multipartEntity = new CustomMultiPartEntity();
		            
		            // SET UPLOAD LISTENER
		            multipartEntity.setUploadProgressListener(this);
		           
		            //*** ADD THE FILE
		            multipartEntity.addPart("fileToUpload", inputStreamBody);
		                
		            //*** ADD STRING DATA
		            multipartEntity.addPart("description",dataString);   
		            
		            httpPost.setEntity(multipartEntity);
		            httpPost.setEntity(multipartEntity);
		            
		            // EXECUTE HTTPPOST
		            HttpResponse httpResponse = httpClient.execute(httpPost);
		            
		            // THE RESPONSE FROM SERVER
		            String stringResponse =  EntityUtils.toString(httpResponse.getEntity());
		            
		            // DISPLAY RESPONSE OF THE SERVER
		            Log.d("data from server",stringResponse);
		            
		        	Account account = message.getConversation().getAccount();
					MessagePacket packet = xmppConnectionService.getMessageGenerator().generateChat(message);
					packet.setBody(stringResponse);
					if (!account.getXmppConnection().getFeatures().sm()
							&& message.getConversation().getMode() != Conversation.MODE_MULTI) {
						xmppConnectionService.markMessage(message, Message.STATUS_SEND);
					}
					xmppConnectionService.sendMessagePacket(account, packet);
		           
		           
		        } catch (FileNotFoundException e1) {
		            e1.printStackTrace();
		            
		            return false;
		            
		        } catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					return false;
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					return false;
				}
			
				 return true;
			}
			
			/**
			 * 
			 */
			@Override
			public void transferred(long num) {
				
				// COMPUTE DATA UPLOADED BY PERCENT
				
				
				long dataUploaded = ((num / 1024) * 100 ) / imageSize;
				 
				//System.out.println("Transferred:::%"+dataUploaded);
				// PUBLISH PROGRESS
				
				this.publishProgress((int)dataUploaded);
				
			}
			
			/**
			 * Convert the InputStream to byte[]
			 * @param inputStream
			 * @return
			 * @throws java.io.IOException
			 */
			private byte[] convertToByteArray(InputStream inputStream) throws IOException{
				
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
	               
             int next = inputStream.read();
             while (next > -1) {
                 bos.write(next);
                 next = inputStream.read();
             }
             
             bos.flush();
             
             return bos.toByteArray();
			}
			
			
			
			@Override
			protected void onProgressUpdate(Integer... values) {
				super.onProgressUpdate(values);
				
				// UPDATE THE PROGRESS DIALOG
				
				//System.out.println("Jose:: File upload progress::"+values[0]);
				

				message.setStatus(Message.STATUS_UNSEND);
				message.setFileProgress(values[0]>100?100:values[0]);
				xmppConnectionService.updateConversationUi();
				//progressDialog.setProgress(values[0]);
				
				
				
			}

			@Override
			protected void onPostExecute(Boolean uploaded) {
				// TODO Auto-generated method stub
				super.onPostExecute(uploaded);
				
				
				if( uploaded){
					
					// UPLOADING DATA SUCCESS
					
					//progressDialog.dismiss();
					xmppConnectionService.markMessage(message, Message.STATUS_SEND);
					
				
				}else{
					
					// UPLOADING DATA FAILED
					//System.out.println"Jose:: file upload failed");
					xmppConnectionService.markMessage(message, Message.STATUS_SEND_FAILED);
					//progressDialog.setMessage("Uploading Failed");
					//progressDialog.setCancelable(true);
					
					
				}
				
				
			}

			

		}


}
