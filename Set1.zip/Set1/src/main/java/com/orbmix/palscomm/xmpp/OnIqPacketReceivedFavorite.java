package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.xmpp.stanzas.IqPacket;

/**
 * Created by Elumalai on 12/31/2015.
 */
public interface OnIqPacketReceivedFavorite extends PacketReceived {

    public void OnIqPacketReceivedFavorite(Account account, IqPacket packet);
}
