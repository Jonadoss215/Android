package com.orbmix.palscomm.ui;

import android.content.Intent;
import android.os.Bundle;

import com.orbmix.palscomm.R;

/**
 * Created by Elumalai on 7/17/2015.
 */
public class ProfileActivity extends XmppActivity {
//private XmppConnectionService xmppConnectionService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

    }
    void onBackendConnected()
    {
        Intent intent = new Intent(getApplicationContext(),
                PublishProfilePictureActivity.class);
        //System.out.println("Elumalai :: profile activity  :"+xmppConnectionService);
        intent.putExtra("account", xmppConnectionService.getAccounts().get(0).getJid().toString());
        startActivity(intent);
        finish();
    }
}
