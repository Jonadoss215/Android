package com.orbmix.palscomm.xmpp;

import com.orbmix.palscomm.entities.Account;
import com.orbmix.palscomm.xmpp.stanzas.MessagePacket;

public interface OnMessagePacketReceived extends PacketReceived {
	public void onMessagePacketReceived(Account account, MessagePacket packet);
}
