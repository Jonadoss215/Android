package com.orbmix.palscomm.xmpp.jingle;

public interface OnTransportConnected {
	public void failed();

	public void established();
}
