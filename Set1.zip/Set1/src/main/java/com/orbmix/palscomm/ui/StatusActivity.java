package com.orbmix.palscomm.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

import com.orbmix.palscomm.R;
import com.orbmix.palscomm.entities.Account;

/**
 * Created by orbmixtech on 13/2/16.
 */
public class StatusActivity extends XmppActivity {


    ListView select_new_status;
    TextView current_status;
    ImageButton Editcurrnet_Status;

    public Account account;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);

        select_new_status = (ListView) findViewById(R.id.new_status);
        current_status = (TextView) findViewById(R.id.current_status);
        Editcurrnet_Status = (ImageButton) findViewById(R.id.edit_current_status_button);

        final String current_Status = getIntent().getStringExtra("currentStatus");
        current_status.setText(current_Status);

      /*Log.i("account status", "-----" + account.getAccountStatusMsg());
        Log.i("account nick name","-----"+account.getAccountNickName());
        Log.i("account status message -----",account.getAccountStatusMsg());*/


        // Defined Array values to show in ListView
        String[] new_status = new String[] {
                "Available",
                "Away",
                "Not Available",
                "Do Not Disturb",
                "In a meeting",
                "At the gym",
                "Sleeping",
                "Urgent calls only"};

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, new_status);


        // Assign adapter to ListView
        select_new_status.setAdapter(adapter);

        // ListView Item Click Listener
        select_new_status.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                // ListView Clicked item index
                int itemPosition     = position;

                // ListView Clicked item value
                String  itemValue    = (String) select_new_status.getItemAtPosition(position);
                Status(itemValue);
                // Show Alert
                Toast.makeText(getApplicationContext(),
                        "Position :"+itemPosition+"  ListItem : " +itemValue , Toast.LENGTH_LONG)
                        .show();

            }

        });

        	Editcurrnet_Status.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				quickEdit(current_Status,
						new XmppActivity.OnValueEdited() {

							@Override
							public void onValueEdited(String value) {
//								xmppConnectionService.renameInMuc(mConversation,value,renameCallback);
                                current_status.setText(value);
                                Status(value);
							}
						});
			}
		});

        if (getActionBar() != null) {
            getActionBar().setHomeButtonEnabled(true);
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    void onBackendConnected() {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
            return super.onOptionsItemSelected(menuItem);
        }

    public void Status(String seletedstatus){
        current_status.setText(seletedstatus);
        Intent returnIntent = new Intent();
        returnIntent.putExtra("result", seletedstatus);
        setResult(23456, returnIntent);
//        finish();
    }
}
